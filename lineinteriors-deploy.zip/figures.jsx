/* eslint-disable */
// Walking figures — uses the figure png with periodic step + sway + breath
// Also exports a static positioned figure with breathing animation only

function WalkingFigure({ src, height = 120, speed = 28, direction = "ltr", style = {}, opacity = 0.85 }) {
  // animated walking across container
  const id = React.useId().replace(/:/g, "");
  return (
    <div style={{
      position: "absolute",
      bottom: 0,
      left: 0, right: 0,
      pointerEvents: "none",
      ...style,
    }}>
      <style>{`
        @keyframes walk-${id} {
          ${direction === "ltr"
            ? `from { transform: translateX(-15%); } to { transform: translateX(115%); }`
            : `from { transform: translateX(115%) scaleX(-1); } to { transform: translateX(-15%) scaleX(-1); }`}
        }
        @keyframes step-${id} {
          0%, 100% { transform: translateY(0px); }
          25%      { transform: translateY(-2px) rotate(-0.8deg); }
          50%      { transform: translateY(0px) rotate(0deg); }
          75%      { transform: translateY(-2px) rotate(0.8deg); }
        }
        .wf-outer-${id} { animation: walk-${id} ${speed}s linear infinite; will-change: transform; }
        .wf-inner-${id} { animation: step-${id} 0.85s ease-in-out infinite; will-change: transform; transform-origin: center bottom; }
      `}</style>
      <div className={`wf-outer-${id}`} style={{ display: "inline-block" }}>
        <div className={`wf-inner-${id}`} style={{ display: "inline-block" }}>
          <img src={src} alt="" style={{ height: `${height}px`, display: "block", opacity }} />
        </div>
      </div>
    </div>
  );
}

function BreathingFigure({ src, height = 120, style = {}, opacity = 0.85, sway = true }) {
  const id = React.useId().replace(/:/g, "");
  return (
    <React.Fragment>
      <style>{`
        @keyframes breathe-${id} {
          0%, 100% { transform: translateY(0px) ${sway ? "rotate(-0.5deg)" : ""}; }
          50%      { transform: translateY(-3px) ${sway ? "rotate(0.5deg)" : ""}; }
        }
        .bf-${id} { animation: breathe-${id} 4.2s ease-in-out infinite; transform-origin: center bottom; will-change: transform; }
      `}</style>
      <img src={src} alt="" className={`bf-${id}`}
        style={{ height: `${height}px`, display: "block", opacity, ...style }} />
    </React.Fragment>
  );
}

// Parallax figure: drifts horizontally based on scroll position
function ParallaxFigure({ src, height = 120, factor = 0.04, baseX = 0, style = {}, opacity = 0.7 }) {
  const [x, setX] = React.useState(baseX);
  React.useEffect(() => {
    const onScroll = () => setX(baseX + window.scrollY * factor);
    window.addEventListener("scroll", onScroll, { passive: true });
    onScroll();
    return () => window.removeEventListener("scroll", onScroll);
  }, [baseX, factor]);
  return (
    <img src={src} alt=""
      style={{
        height: `${height}px`,
        display: "block",
        opacity,
        transform: `translateX(${x}px)`,
        transition: "transform 0.6s cubic-bezier(.2,.7,.1,1)",
        ...style,
      }} />
  );
}

window.WalkingFigure = WalkingFigure;
window.BreathingFigure = BreathingFigure;
window.ParallaxFigure = ParallaxFigure;
