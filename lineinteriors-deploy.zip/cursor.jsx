/* eslint-disable */
// Marker-pen hand-drawn cursor — wide oval matching the reference sketch
// Two overlapping ellipse passes + a small comma-hook at top-left interior

const CURSOR_COLOR = "#38383c";

function SketchCursor() {
  const ringRef = React.useRef(null);
  const lap1Ref = React.useRef(null);
  const lap2Ref = React.useRef(null);
  const hookRef = React.useRef(null);
  const [lens, setLens] = React.useState([0, 0, 0]);
  const [hovering, setHovering] = React.useState(false);
  const [pressed, setPressed] = React.useState(false);
  const [visible, setVisible] = React.useState(false);
  const [stage, setStage] = React.useState("draw");
  const pos = React.useRef({ x: 0, y: 0 });
  const target = React.useRef({ x: 0, y: 0 });

  React.useEffect(() => {
    setLens([
      lap1Ref.current?.getTotalLength() || 0,
      lap2Ref.current?.getTotalLength() || 0,
      hookRef.current?.getTotalLength() || 0,
    ]);
  }, []);

  React.useEffect(() => {
    const cx = window.innerWidth / 2;
    const cy = window.innerHeight / 2;
    pos.current = { x: cx, y: cy };
    target.current = { x: cx, y: cy };
    setVisible(true);
    const t = setTimeout(() => setStage("settle"), 2100);
    return () => clearTimeout(t);
  }, []);

  React.useEffect(() => {
    const onMove = (e) => {
      target.current.x = e.clientX;
      target.current.y = e.clientY;
      const el = e.target;
      const interactive = el && (el.closest("a, button, [data-cursor=\"hover\"], .va-tile, .vb-tile, .vc-tile, .va-pill, .va-cta, .vc-btn, input, textarea"));
      setHovering(!!interactive);
      if (stage === "settle") setStage("follow");
    };
    const onDown = () => setPressed(true);
    const onUp = () => setPressed(false);
    const onLeave = () => setVisible(false);
    const onEnter = () => setVisible(true);
    window.addEventListener("mousemove", onMove);
    window.addEventListener("mousedown", onDown);
    window.addEventListener("mouseup", onUp);
    document.addEventListener("mouseleave", onLeave);
    document.addEventListener("mouseenter", onEnter);
    return () => {
      window.removeEventListener("mousemove", onMove);
      window.removeEventListener("mousedown", onDown);
      window.removeEventListener("mouseup", onUp);
      document.removeEventListener("mouseleave", onLeave);
      document.removeEventListener("mouseenter", onEnter);
    };
  }, [stage]);

  React.useEffect(() => {
    let raf;
    const tick = () => {
      if (stage === "follow") {
        pos.current.x += (target.current.x - pos.current.x) * 0.22;
        pos.current.y += (target.current.y - pos.current.y) * 0.22;
      }
      if (ringRef.current) {
        ringRef.current.style.transform = `translate3d(${pos.current.x}px, ${pos.current.y}px, 0) translate(-50%, -50%)`;
      }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [stage]);

  const [isTouch, setIsTouch] = React.useState(false);
  React.useEffect(() => {
    setIsTouch(window.matchMedia("(hover: none)").matches);
  }, []);

  const [strokeReady, setStrokeReady] = React.useState(false);
  React.useEffect(() => {
    if (stage !== "draw") {
      const t = setTimeout(() => setStrokeReady(true), 50);
      return () => clearTimeout(t);
    }
  }, [stage]);

  if (isTouch) return null;

  const drawingNow = stage === "draw";
  // Wide oval — aspect ~1.85:1 like the reference
  const w = drawingNow ? 260 : (hovering ? 100 : 60);
  const h = drawingNow ? 150 : (hovering ? 58 : 36);
  const scale = pressed ? 0.85 : 1;

  // viewBox 240×130. Ellipse center (120, 65), rx 96, ry 47
  // Two overlapping laps with slightly different radii/centers + a comma hook inside top-left
  // Reference: each lap starts top-left going clockwise around. Second lap slightly outside on right.

  // Lap 1 — outer, starts at upper-left (cx-rx*0.85, cy-ry*0.55), goes CW. Has end overshoot bottom-left.
  const lap1D = `
    M 38 47
    C 56 14, 110 4, 162 12
    C 208 19, 232 42, 224 76
    C 214 110, 158 130, 96 124
    C 42 119, 14 96, 22 70
    C 30 50, 50 32, 80 22
  `.replace(/\s+/g, " ").trim();

  // Lap 2 — slightly tighter on left, slightly outside on right (as in the reference)
  // starts where lap1 ended-ish, goes CW second time, ends just below first start (overshoot)
  const lap2D = `
    M 80 22
    C 110 14, 158 18, 196 36
    C 230 56, 240 84, 218 106
    C 192 128, 130 134, 78 124
    C 28 114, 8 90, 18 64
    C 28 40, 60 24, 96 22
    L 92 24
  `.replace(/\s+/g, " ").trim();

  // Comma hook — small curl inside upper-left quadrant, like the reference
  const hookD = `M 86 28 C 90 38, 86 50, 76 54 C 66 56, 56 54, 50 50`.trim();

  return (
    <React.Fragment>
      <style>{`
        html, body, * { cursor: none !important; }
        @media (hover: none) { html, body, * { cursor: auto !important; } }
        .sk-cursor-svg { display: block; overflow: visible; }
      `}</style>

      <svg width="0" height="0" style={{ position: "absolute" }} aria-hidden="true">
        <defs>
          <filter id="sk-marker" x="-20%" y="-20%" width="140%" height="140%">
            <feTurbulence type="fractalNoise" baseFrequency="0.022" numOctaves="2" seed="7" />
            <feDisplacementMap in="SourceGraphic" scale="3" xChannelSelector="R" yChannelSelector="G" />
          </filter>
        </defs>
      </svg>

      <div
        ref={ringRef}
        style={{
          position: "fixed",
          top: 0, left: 0,
          width: w, height: h,
          pointerEvents: "none",
          zIndex: 9999,
          opacity: visible ? 1 : 0,
          transition: "width .8s cubic-bezier(.2,.7,.1,1), height .8s cubic-bezier(.2,.7,.1,1), opacity .25s",
        }}
      >
        <svg
          className="sk-cursor-svg"
          viewBox="0 0 240 130"
          width={w}
          height={h}
          preserveAspectRatio="xMidYMid meet"
          style={{
            transform: `scale(${scale})`,
            transition: "transform .15s",
            filter: "url(#sk-marker)",
          }}
        >
          {/* Lap 1 — main outer stroke */}
          <path
            ref={lap1Ref}
            d={lap1D}
            fill="none"
            stroke={CURSOR_COLOR}
            strokeWidth="6"
            strokeLinecap="round"
            strokeLinejoin="round"
            style={strokeReady ? {} : {
              strokeDasharray: lens[0] || 1,
              strokeDashoffset: drawingNow ? lens[0] : 0,
              transition: drawingNow ? "stroke-dashoffset 1.0s cubic-bezier(.5,.1,.5,1)" : "none",
            }}
          />
          {/* Lap 2 — second overlapping pass */}
          <path
            ref={lap2Ref}
            d={lap2D}
            fill="none"
            stroke={CURSOR_COLOR}
            strokeWidth="6"
            strokeLinecap="round"
            strokeLinejoin="round"
            style={strokeReady ? {} : {
              strokeDasharray: lens[1] || 1,
              strokeDashoffset: drawingNow ? lens[1] : 0,
              transition: drawingNow ? "stroke-dashoffset 1.0s cubic-bezier(.5,.1,.5,1) 0.7s" : "none",
            }}
          />
          {/* Comma hook — drawn last, inside top-left */}
          <path
            ref={hookRef}
            d={hookD}
            fill="none"
            stroke={CURSOR_COLOR}
            strokeWidth="6"
            strokeLinecap="round"
            strokeLinejoin="round"
            style={strokeReady ? {} : {
              strokeDasharray: lens[2] || 1,
              strokeDashoffset: drawingNow ? lens[2] : 0,
              transition: drawingNow ? "stroke-dashoffset 0.35s cubic-bezier(.5,.1,.5,1) 1.6s" : "none",
            }}
          />
        </svg>
      </div>
    </React.Fragment>
  );
}

window.SketchCursor = SketchCursor;
