/* eslint-disable */
// Scroll-driven animation primitives — pure hooks + components
// All components register on window.* for use across other Babel script files

// === useScrollY — debounced rAF scrollY tracker ===
function useScrollY() {
  const [y, setY] = React.useState(0);
  React.useEffect(() => {
    let raf;
    const onScroll = () => {
      if (raf) return;
      raf = requestAnimationFrame(() => {
        setY(window.scrollY);
        raf = null;
      });
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    onScroll();
    return () => { window.removeEventListener("scroll", onScroll); if (raf) cancelAnimationFrame(raf); };
  }, []);
  return y;
}

// === useElementProgress — 0..1 progress as element scrolls through viewport ===
function useElementProgress(ref) {
  const [p, setP] = React.useState(0);
  React.useEffect(() => {
    if (!ref.current) return;
    let raf;
    const tick = () => {
      raf = null;
      if (!ref.current) return;
      const r = ref.current.getBoundingClientRect();
      const vh = window.innerHeight;
      // 0 when element bottom enters from below, 1 when element top exits to top
      const total = r.height + vh;
      const traveled = vh - r.top;
      setP(Math.max(0, Math.min(1, traveled / total)));
    };
    const onScroll = () => { if (!raf) raf = requestAnimationFrame(tick); };
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll);
    tick();
    return () => {
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onScroll);
      if (raf) cancelAnimationFrame(raf);
    };
  }, [ref]);
  return p;
}

// === ParallaxSection — translates content based on its own scroll progress ===
function ParallaxSection({ children, speed = 0.3, as = "div", style = {}, ...rest }) {
  const ref = React.useRef(null);
  const progress = useElementProgress(ref);
  // progress 0..1 → translate -speed*100 .. +speed*100 px (clamped)
  const translate = (progress - 0.5) * speed * 200;
  const Tag = as;
  return (
    <Tag ref={ref} style={{ ...style, willChange: "transform" }} {...rest}>
      <div style={{ transform: `translate3d(0, ${translate}px, 0)` }}>
        {children}
      </div>
    </Tag>
  );
}

// === ScrollReveal — IntersectionObserver, fade+slide once ===
function ScrollReveal({ children, delay = 0, direction = "up", distance = 40, duration = 900, threshold = 0.15, style = {}, as = "div" }) {
  const ref = React.useRef(null);
  const [visible, setVisible] = React.useState(false);
  React.useEffect(() => {
    if (!ref.current) return;
    const obs = new IntersectionObserver((entries) => {
      entries.forEach(e => {
        if (e.isIntersecting) {
          setVisible(true);
          obs.unobserve(e.target);
        }
      });
    }, { threshold });
    obs.observe(ref.current);
    return () => obs.disconnect();
  }, [threshold]);

  const offset = visible ? "0px" : (
    direction === "up" ? `${distance}px` :
    direction === "down" ? `-${distance}px` :
    direction === "left" ? `${distance}px,0` :
    direction === "right" ? `-${distance}px,0` : "0px"
  );

  const transform = (() => {
    if (!visible) {
      if (direction === "left" || direction === "right") return `translate3d(${direction === "left" ? distance : -distance}px, 0, 0)`;
      return `translate3d(0, ${direction === "up" ? distance : -distance}px, 0)`;
    }
    return "translate3d(0,0,0)";
  })();

  const Tag = as;
  return (
    <Tag ref={ref} style={{
      ...style,
      opacity: visible ? 1 : 0,
      transform,
      transition: `opacity ${duration}ms cubic-bezier(.2,.7,.1,1) ${delay}ms, transform ${duration}ms cubic-bezier(.2,.7,.1,1) ${delay}ms`,
      willChange: "opacity, transform",
    }}>
      {children}
    </Tag>
  );
}

// === SplitTextReveal — word-by-word fade-up reveal of a string or React text ===
function SplitTextReveal({ children, tag = "span", delay = 0, stagger = 80, duration = 800, distance = 30, asLines = false, style = {} }) {
  const ref = React.useRef(null);
  const [visible, setVisible] = React.useState(false);

  React.useEffect(() => {
    if (!ref.current) return;
    const obs = new IntersectionObserver((entries) => {
      entries.forEach(e => {
        if (e.isIntersecting) {
          setVisible(true);
          obs.unobserve(e.target);
        }
      });
    }, { threshold: 0.2 });
    obs.observe(ref.current);
    return () => obs.disconnect();
  }, []);

  // Walk children tree and split text nodes into word spans, leaving React elements intact
  const splitNode = (node, keyPrefix = "") => {
    if (typeof node === "string" || typeof node === "number") {
      const str = String(node);
      const parts = str.split(/(\s+)/);
      return parts.map((p, i) => {
        if (/^\s+$/.test(p)) return p;
        if (p === "") return null;
        return <span key={keyPrefix + i} className="srv-word" style={{ display: "inline-block", overflow: "hidden", verticalAlign: "top" }}>
          <span className="srv-inner" style={{ display: "inline-block" }}>{p}</span>
        </span>;
      });
    }
    if (React.isValidElement(node)) {
      const newChildren = React.Children.map(node.props.children, (c, i) => splitNode(c, keyPrefix + i + "."));
      return React.cloneElement(node, node.props, newChildren);
    }
    if (Array.isArray(node)) {
      return node.map((c, i) => splitNode(c, keyPrefix + i + "."));
    }
    return node;
  };

  const split = React.Children.map(children, (c, i) => splitNode(c, i + "."));

  const Tag = tag;
  return (
    <Tag ref={ref} style={style}>
      <style>{`
        .srv-active .srv-word .srv-inner { transform: translate3d(0,0,0); opacity: 1; }
      `}</style>
      <span
        className={visible ? "srv-active" : ""}
        style={{
          // inject per-word delays via CSS variable; we'll use nth-child via inline transition delays in the spans
        }}
        ref={(el) => {
          if (!el) return;
          const words = el.querySelectorAll(".srv-word .srv-inner");
          words.forEach((w, i) => {
            w.style.transition = `opacity ${duration}ms cubic-bezier(.2,.7,.1,1) ${delay + i * stagger}ms, transform ${duration}ms cubic-bezier(.2,.7,.1,1) ${delay + i * stagger}ms`;
            if (!visible) {
              w.style.opacity = "0";
              w.style.transform = `translate3d(0, ${distance}px, 0)`;
            }
          });
        }}
      >
        {split}
      </span>
    </Tag>
  );
}

// === ScrollProgress — a thin progress bar at the top of viewport ===
function ScrollProgress({ color = "#38383c", height = 2 }) {
  const [p, setP] = React.useState(0);
  React.useEffect(() => {
    let raf;
    const tick = () => {
      const max = document.documentElement.scrollHeight - window.innerHeight;
      setP(max > 0 ? window.scrollY / max : 0);
      raf = null;
    };
    const onScroll = () => { if (!raf) raf = requestAnimationFrame(tick); };
    window.addEventListener("scroll", onScroll, { passive: true });
    onScroll();
    return () => window.removeEventListener("scroll", onScroll);
  }, []);
  return (
    <div style={{
      position: "fixed", top: 0, left: 0, right: 0,
      height, zIndex: 100, pointerEvents: "none",
    }}>
      <div style={{
        height: "100%", background: color,
        width: `${p * 100}%`,
        transformOrigin: "left",
        transition: "width .1s linear",
      }} />
    </div>
  );
}

// === PageTransition — fade out current children, swap, fade in new ===
// Watches `pageKey` (e.g. JSON.stringify(page state)). When it changes, plays exit anim,
// then commits new children, then plays enter anim.
function PageTransition({ children, pageKey, duration = 380 }) {
  const [shown, setShown] = React.useState(children);
  const [state, setState] = React.useState("in"); // "in" | "out"
  const lastKey = React.useRef(pageKey);

  React.useEffect(() => {
    if (pageKey === lastKey.current) return;
    setState("out");
    const t1 = setTimeout(() => {
      setShown(children);
      lastKey.current = pageKey;
      // Force browser to commit the new tree then play "in"
      requestAnimationFrame(() => {
        requestAnimationFrame(() => setState("in"));
      });
      // Reset scroll on page change
      window.scrollTo({ top: 0, behavior: "instant" });
    }, duration);
    return () => clearTimeout(t1);
  }, [pageKey, children, duration]);

  // Keep `shown` in sync if children update but pageKey stays the same
  React.useEffect(() => {
    if (pageKey === lastKey.current) setShown(children);
  }, [children, pageKey]);

  return (
    <div style={{
      opacity: state === "in" ? 1 : 0,
      transform: state === "in" ? "translate3d(0,0,0)" : "translate3d(0,8px,0)",
      transition: `opacity ${duration}ms cubic-bezier(.2,.7,.1,1), transform ${duration}ms cubic-bezier(.2,.7,.1,1)`,
      willChange: "opacity, transform",
    }}>
      {shown}
    </div>
  );
}

Object.assign(window, { useScrollY, useElementProgress, ParallaxSection, ScrollReveal, SplitTextReveal, ScrollProgress, PageTransition });
