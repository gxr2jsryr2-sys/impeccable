/* eslint-disable */
// Variation C — Index Archive
// Monospace-dominant, technical, dense. Project list as the front door.
// Cream paper bg, hairline grid. Hover preview floats in a fixed pane.

const C_PALETTE = {
  bg: "#ece6d8",
  bg2: "#e4ddcc",
  paper: "#f4eee0",
  ink: "#1f1812",
  mid: "#6b5b48",
  rule: "rgba(31,24,18,0.18)",
  accent: "#8a5a32",
};

const C_FONTS = `
@import url('https://fonts.googleapis.com/css2?family=Instrument+Serif:ital@0;1&family=Instrument+Sans:ital,wght@0,400..700;1,400..700&family=JetBrains+Mono:wght@300;400;500;600&display=swap');
`;

function CLayout({ children, page, setPage, lang, setLang, t }) {
  const links = [
    ["index", "00 / " + t.nav.index],
    ["projects", "01 / " + t.nav.projects],
    ["about", "02 / " + t.nav.about],
    ["contact", "03 / " + t.nav.contact],
  ];
  const now = new Date();
  const time = now.toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit", timeZone: "Europe/Istanbul" });
  return (
    <div className="vc-root">
      <style>{C_FONTS}{`
        .vc-root { background: ${C_PALETTE.bg}; color: ${C_PALETTE.ink}; font-family: var(--mono); min-height: 100vh; font-size: 13px; }
        .vc-root a { color: inherit; text-decoration: none; }
        .vc-grid { position: fixed; inset: 0; pointer-events: none; z-index: 1; opacity: 0.5; }
        .vc-grid::before { content: ""; position: absolute; inset: 0; background-image: linear-gradient(${C_PALETTE.rule} 1px, transparent 1px); background-size: 100% 32px; }
        .vc-top { position: sticky; top: 0; z-index: 30; background: ${C_PALETTE.bg}; border-bottom: 1px solid ${C_PALETTE.ink}; }
        .vc-top-inner { display: grid; grid-template-columns: 280px 1fr auto; align-items: center; padding: 14px 24px; gap: 24px; }
        .vc-mark { display: flex; align-items: center; gap: 14px; cursor: pointer; }
        .vc-mark img { height: 24px; }
        .vc-mark-meta { font-family: var(--mono); font-size: 10px; letter-spacing: 0.08em; text-transform: uppercase; color: ${C_PALETTE.mid}; line-height: 1.3; }
        .vc-links { display: flex; gap: 28px; font-size: 11px; letter-spacing: 0.08em; text-transform: uppercase; }
        .vc-links a { cursor: pointer; color: ${C_PALETTE.mid}; padding: 4px 0; border-bottom: 1px dashed transparent; }
        .vc-links a[data-active="true"] { color: ${C_PALETTE.ink}; border-bottom-color: ${C_PALETTE.ink}; }
        .vc-status { display: flex; align-items: center; gap: 16px; font-size: 10px; letter-spacing: 0.08em; text-transform: uppercase; color: ${C_PALETTE.mid}; }
        .vc-status .dot { width: 6px; height: 6px; border-radius: 50%; background: #6a8f3a; box-shadow: 0 0 0 3px rgba(106,143,58,0.15); }
        .vc-lang { display: flex; gap: 2px; }
        .vc-lang button { background: ${C_PALETTE.paper}; border: 1px solid ${C_PALETTE.rule}; color: ${C_PALETTE.mid}; padding: 4px 8px; cursor: pointer; font-family: var(--mono); font-size: 10px; letter-spacing: 0.08em; }
        .vc-lang button[data-active="true"] { background: ${C_PALETTE.ink}; color: ${C_PALETTE.bg}; border-color: ${C_PALETTE.ink}; }
        .vc-container { max-width: 1680px; margin: 0 auto; padding: 0 24px; position: relative; z-index: 2; }
        .vc-h1 { font-family: var(--display); font-weight: 400; font-size: clamp(48px, 7.5vw, 132px); line-height: 0.92; letter-spacing: -0.04em; }
        .vc-h1 em { font-family: var(--serif); font-style: italic; font-weight: 400; }
        .vc-h2 { font-family: var(--display); font-weight: 400; font-size: clamp(28px, 3.2vw, 52px); line-height: 1.02; letter-spacing: -0.025em; }
        .vc-h2 em { font-family: var(--serif); font-style: italic; }
        .vc-lede { font-family: var(--display); font-size: clamp(20px, 1.6vw, 28px); line-height: 1.35; letter-spacing: -0.015em; max-width: 32ch; }
        .vc-body { font-size: 13px; line-height: 1.65; color: ${C_PALETTE.mid}; max-width: 60ch; }
        .vc-mono { font-family: var(--mono); font-size: 11px; letter-spacing: 0.08em; text-transform: uppercase; }
        .vc-tag { display: inline-block; padding: 2px 8px; border: 1px solid ${C_PALETTE.rule}; border-radius: 999px; font-size: 10px; letter-spacing: 0.08em; text-transform: uppercase; color: ${C_PALETTE.mid}; }
        .vc-row { display: grid; align-items: center; padding: 14px 0; border-bottom: 1px solid ${C_PALETTE.rule}; transition: background .15s; cursor: pointer; }
        .vc-row:hover { background: ${C_PALETTE.paper}; }
        .vc-row:hover .vc-rowname { font-style: italic; font-family: var(--serif); }
        .vc-rowname { transition: all .25s; }
        @keyframes vc-fade { from { opacity: 0; transform: translateY(8px); } to { opacity: 1; transform: none; } }
        .vc-anim { /* vc-fade removed */ }
        .vc-btn { display: inline-flex; align-items: center; gap: 10px; padding: 10px 14px; border: 1px solid ${C_PALETTE.ink}; background: ${C_PALETTE.paper}; color: ${C_PALETTE.ink}; cursor: pointer; font-family: var(--mono); font-size: 11px; letter-spacing: 0.1em; text-transform: uppercase; }
        .vc-btn:hover { background: ${C_PALETTE.ink}; color: ${C_PALETTE.bg}; }
        .vc-tile { cursor: pointer; }
        .vc-tile .ph-img > div:first-of-type { transition: transform 1.2s cubic-bezier(.2,.7,.1,1); }
        .vc-tile:hover .ph-img > div:first-of-type { transform: scale(1.06); }
        .vc-hairline { height: 1px; background: ${C_PALETTE.ink}; }
        .vc-rule { height: 1px; background: ${C_PALETTE.rule}; }
      `}</style>

      <div className="vc-grid" />

      <header className="vc-top">
        <div className="vc-top-inner">
          <a className="vc-mark" onClick={() => setPage({ name: "index" })}>
            <img src="assets/wordmark-dark.png" alt="Line Interiors" />
            <div className="vc-mark-meta">
              ID/2017<br />Çankaya · Ankara
            </div>
          </a>
          <nav className="vc-links">
            {links.map(([k, label]) => (
              <a key={k} data-active={page.name === k || (k === "projects" && page.name === "project")} onClick={() => setPage({ name: k.split(" / ")[0] === "01" ? "projects" : k })}>
                {label}
              </a>
            ))}
          </nav>
          <div className="vc-status">
            <span><span className="dot" style={{ display: "inline-block", marginRight: 6, verticalAlign: "middle" }} />ANK · {time}</span>
            <div className="vc-lang">
              <button data-active={lang === "en"} onClick={() => setLang("en")}>EN</button>
              <button data-active={lang === "tr"} onClick={() => setLang("tr")}>TR</button>
            </div>
          </div>
        </div>
      </header>

      {children}
    </div>
  );
}

// Fix the layout link callback (need to pass actual page name, not label)
function CLayoutFixed(props) {
  const links = [
    ["index", props.t.nav.index],
    ["projects", props.t.nav.projects],
    ["about", props.t.nav.about],
    ["contact", props.t.nav.contact],
  ];
  const now = new Date();
  const time = now.toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit", timeZone: "Europe/Istanbul" });
  const { children, page, setPage, lang, setLang, t } = props;
  return (
    <div className="vc-root">
      <style>{C_FONTS}{`
        .vc-root { background: ${C_PALETTE.bg}; color: ${C_PALETTE.ink}; font-family: var(--mono); min-height: 100vh; font-size: 13px; }
        .vc-root a { color: inherit; text-decoration: none; }
        .vc-grid { position: fixed; inset: 0; pointer-events: none; z-index: 1; opacity: 0.4; }
        .vc-grid::before { content: ""; position: absolute; inset: 0; background-image: linear-gradient(${C_PALETTE.rule} 1px, transparent 1px); background-size: 100% 32px; }
        .vc-top { position: sticky; top: 0; z-index: 30; background: ${C_PALETTE.bg}ee; backdrop-filter: blur(8px); border-bottom: 1px solid ${C_PALETTE.ink}; }
        .vc-top-inner { display: grid; grid-template-columns: 260px 1fr auto; align-items: center; padding: 14px 24px; gap: 24px; }
        .vc-mark { display: flex; align-items: center; gap: 14px; cursor: pointer; }
        .vc-mark img { height: 24px; }
        .vc-mark-meta { font-family: var(--mono); font-size: 9px; letter-spacing: 0.1em; text-transform: uppercase; color: ${C_PALETTE.mid}; line-height: 1.35; }
        .vc-links { display: flex; gap: 24px; font-size: 11px; letter-spacing: 0.1em; text-transform: uppercase; }
        .vc-links a { cursor: pointer; color: ${C_PALETTE.mid}; padding: 4px 0; border-bottom: 1px dashed transparent; }
        .vc-links a[data-active="true"] { color: ${C_PALETTE.ink}; border-bottom-color: ${C_PALETTE.ink}; }
        .vc-status { display: flex; align-items: center; gap: 14px; font-size: 10px; letter-spacing: 0.1em; text-transform: uppercase; color: ${C_PALETTE.mid}; }
        .vc-dot { width: 6px; height: 6px; border-radius: 50%; background: #6a8f3a; box-shadow: 0 0 0 3px rgba(106,143,58,0.15); display: inline-block; margin-right: 6px; vertical-align: middle; }
        .vc-lang { display: flex; gap: 2px; }
        .vc-lang button { background: ${C_PALETTE.paper}; border: 1px solid ${C_PALETTE.rule}; color: ${C_PALETTE.mid}; padding: 4px 8px; cursor: pointer; font-family: var(--mono); font-size: 10px; letter-spacing: 0.1em; }
        .vc-lang button[data-active="true"] { background: ${C_PALETTE.ink}; color: ${C_PALETTE.bg}; border-color: ${C_PALETTE.ink}; }
        .vc-container { max-width: 1680px; margin: 0 auto; padding: 0 24px; position: relative; z-index: 2; }
        .vc-h1 { font-family: var(--display); font-weight: 400; font-size: clamp(48px, 7.5vw, 132px); line-height: 0.92; letter-spacing: -0.04em; }
        .vc-h1 em { font-family: var(--serif); font-style: italic; font-weight: 400; }
        .vc-h2 { font-family: var(--display); font-weight: 400; font-size: clamp(28px, 3.2vw, 52px); line-height: 1.02; letter-spacing: -0.025em; }
        .vc-h2 em { font-family: var(--serif); font-style: italic; }
        .vc-lede { font-family: var(--display); font-size: clamp(20px, 1.6vw, 28px); line-height: 1.35; letter-spacing: -0.015em; max-width: 32ch; }
        .vc-body { font-size: 13px; line-height: 1.65; color: ${C_PALETTE.mid}; max-width: 60ch; }
        .vc-mono { font-family: var(--mono); font-size: 11px; letter-spacing: 0.08em; text-transform: uppercase; }
        .vc-tag { display: inline-block; padding: 2px 8px; border: 1px solid ${C_PALETTE.rule}; border-radius: 999px; font-size: 10px; letter-spacing: 0.08em; text-transform: uppercase; color: ${C_PALETTE.mid}; }
        .vc-row { display: grid; align-items: center; padding: 14px 0; border-bottom: 1px solid ${C_PALETTE.rule}; transition: background .15s, padding .15s; cursor: pointer; }
        .vc-row:hover { background: ${C_PALETTE.paper}; padding-left: 8px; padding-right: 8px; }
        .vc-row:hover .vc-rowname { font-style: italic; font-family: var(--serif); letter-spacing: -0.02em; }
        .vc-rowname { transition: all .35s ease; font-family: var(--display); font-size: clamp(20px, 2vw, 32px); letter-spacing: -0.02em; }
        @keyframes vc-fade { from { opacity: 0; transform: translateY(8px); } to { opacity: 1; transform: none; } }
        .vc-anim { /* vc-fade removed */ }
        .vc-btn { display: inline-flex; align-items: center; gap: 10px; padding: 10px 14px; border: 1px solid ${C_PALETTE.ink}; background: ${C_PALETTE.paper}; color: ${C_PALETTE.ink}; cursor: pointer; font-family: var(--mono); font-size: 11px; letter-spacing: 0.1em; text-transform: uppercase; }
        .vc-btn:hover { background: ${C_PALETTE.ink}; color: ${C_PALETTE.bg}; }
        .vc-tile { cursor: pointer; }
        .vc-tile .ph-img > div:first-of-type { transition: transform 1.2s cubic-bezier(.2,.7,.1,1); }
        .vc-tile:hover .ph-img > div:first-of-type { transform: scale(1.06); }
        .vc-hairline { height: 1px; background: ${C_PALETTE.ink}; }
        .vc-rule { height: 1px; background: ${C_PALETTE.rule}; }
        .vc-meta-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 0; border-top: 1px solid ${C_PALETTE.ink}; border-bottom: 1px solid ${C_PALETTE.ink}; }
        .vc-meta-cell { padding: 14px 16px; border-right: 1px solid ${C_PALETTE.rule}; }
        .vc-meta-cell:last-child { border-right: none; }
        .vc-meta-cell .k { font-family: var(--mono); font-size: 10px; letter-spacing: 0.1em; text-transform: uppercase; color: ${C_PALETTE.mid}; margin-bottom: 6px; }
        .vc-meta-cell .v { font-family: var(--display); font-size: 18px; letter-spacing: -0.01em; }
      `}</style>

      <div className="vc-grid" />

      <header className="vc-top">
        <div className="vc-top-inner">
          <a className="vc-mark" onClick={() => setPage({ name: "index" })}>
            <img src="assets/wordmark-dark.png" alt="Line Interiors" />
            <div className="vc-mark-meta">
              ID / 2017<br />Çankaya · Ankara
            </div>
          </a>
          <nav className="vc-links">
            {links.map(([k, label], i) => (
              <a key={k} data-active={page.name === k || (k === "projects" && page.name === "project")}
                onClick={() => setPage({ name: k })}>
                <span style={{ opacity: 0.5, marginRight: 6 }}>0{i + 1}</span>{label}
              </a>
            ))}
          </nav>
          <div className="vc-status">
            <span><span className="vc-dot" />ANK {time}</span>
            <div className="vc-lang">
              <button data-active={lang === "en"} onClick={() => setLang("en")}>EN</button>
              <button data-active={lang === "tr"} onClick={() => setLang("tr")}>TR</button>
            </div>
          </div>
        </div>
      </header>

      {children}
    </div>
  );
}

function CHome({ setPage, t, lang }) {
  const [hovered, setHovered] = React.useState(null);
  const recent = window.PROJECTS.slice().sort((a, b) => b.year - a.year).slice(0, 14);

  return (
    <div className="vc-anim">
      <section className="vc-container" style={{ padding: "60px 24px 40px" }}>
        <div style={{ display: "grid", gridTemplateColumns: "60px 1fr", gap: 24, marginBottom: 40 }}>
          <div className="vc-mono" style={{ color: C_PALETTE.mid }}>§ 00</div>
          <div className="vc-mono" style={{ color: C_PALETTE.mid }}>
            {lang === "tr" ? "İç mimarlık + uygulama + branding stüdyosu, Ankara, 2017'den beri" : "Interior design + execution + branding studio, Ankara, since 2017"}
          </div>
        </div>
        <window.ScrollReveal delay={100} direction="up" distance={50} duration={1100}>
        <h1 className="vc-h1">
          {t.hero.title[0]} <em>{t.hero.title[1]}</em><br />
          {t.hero.title[2]}
        </h1>
        </window.ScrollReveal>

        <window.ScrollReveal delay={300} direction="up" distance={30} duration={900}>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 60, marginTop: 60 }}>
          <p className="vc-body" style={{ fontSize: 14 }}>{t.hero.lede}</p>
          <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", justifyContent: "flex-end", gap: 16 }}>
            <a className="vc-btn" onClick={() => setPage({ name: "projects" })}>{t.hero.cta} →</a>
            <div className="vc-mono" style={{ color: C_PALETTE.mid }}>{window.PROJECTS.length} projects · 2017—2026</div>
          </div>
        </div>
        </window.ScrollReveal>
      </section>

      <section className="vc-container" style={{ padding: "20px 24px 0" }}>
        <div className="vc-hairline" />
      </section>

      {/* Recent works table */}
      <section className="vc-container" style={{ padding: "40px 24px 60px", display: "grid", gridTemplateColumns: "1fr 400px", gap: 40, alignItems: "start" }}>
        <div>
          <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 16 }}>
            <div className="vc-mono">§ 01 · {t.sections.featured}</div>
            <div className="vc-mono" style={{ color: C_PALETTE.mid }}>{recent.length} / {window.PROJECTS.length}</div>
          </div>

          <div className="vc-row" style={{ gridTemplateColumns: "40px 2fr 1.2fr 1.2fr 0.6fr 60px", padding: "10px 0", color: C_PALETTE.mid }}>
            <div className="vc-mono">#</div>
            <div className="vc-mono">{lang === "tr" ? "Proje" : "Project"}</div>
            <div className="vc-mono">{t.sections.location}</div>
            <div className="vc-mono">{t.sections.category}</div>
            <div className="vc-mono">{t.sections.year}</div>
            <div></div>
          </div>

          {recent.map((p, i) => (
            <div key={p.slug} className="vc-row"
              style={{ gridTemplateColumns: "40px 2fr 1.2fr 1.2fr 0.6fr 60px" }}
              onClick={() => setPage({ name: "project", slug: p.slug })}
              onMouseEnter={() => setHovered(p.slug)}
              onMouseLeave={() => setHovered(null)}>
              <div className="vc-mono" style={{ color: C_PALETTE.mid }}>{String(i + 1).padStart(2, "0")}</div>
              <div className="vc-rowname">{p.name}</div>
              <div className="vc-mono" style={{ color: C_PALETTE.mid }}>{p.location}</div>
              <div className="vc-mono" style={{ color: C_PALETTE.mid }}>{p.category[lang]}</div>
              <div className="vc-mono">{p.year}</div>
              <div className="vc-mono" style={{ textAlign: "right", color: C_PALETTE.accent }}>→</div>
            </div>
          ))}

          <div style={{ marginTop: 24 }}>
            <a className="vc-btn" onClick={() => setPage({ name: "projects" })}>{t.sections.all} ({window.PROJECTS.length}) →</a>
          </div>
        </div>

        {/* Hover preview pane (sticky) */}
        <div style={{ position: "sticky", top: 100 }}>
          <div className="vc-mono" style={{ color: C_PALETTE.mid, marginBottom: 10 }}>
            {hovered ? `~ ${hovered}.preview` : "// Hover bir proje üzerinde"}
          </div>
          <div style={{ border: `1px solid ${C_PALETTE.rule}`, background: C_PALETTE.paper, padding: 14 }}>
            {hovered ? (
              <window.Placeholder slug={hovered} ratio="4/5" label={window.PROJECTS.find(p => p.slug === hovered)?.name} />
            ) : (
              <window.Placeholder slug="default" ratio="4/5" label={lang === "tr" ? "[ önizleme ]" : "[ preview ]"} />
            )}
            <div style={{ marginTop: 12, fontFamily: "var(--mono)", fontSize: 11, color: C_PALETTE.mid }}>
              {hovered && (() => {
                const p = window.PROJECTS.find(p => p.slug === hovered);
                return (
                  <div style={{ display: "grid", gap: 4 }}>
                    <div>NAME : <span style={{ color: C_PALETTE.ink }}>{p.name}</span></div>
                    <div>LOC  : {p.location}</div>
                    <div>TYPE : {p.category[lang]}</div>
                    <div>AREA : {p.area}</div>
                    <div>YEAR : {p.year}</div>
                  </div>
                );
              })()}
            </div>
          </div>
        </div>
      </section>

      <section className="vc-container" style={{ padding: "20px 24px 0" }}>
        <div className="vc-hairline" />
      </section>

      {/* Manifesto */}
      <section className="vc-container" style={{ padding: "80px 24px 80px" }}>
        <div style={{ display: "grid", gridTemplateColumns: "60px 1fr 1fr", gap: 40 }}>
          <div className="vc-mono" style={{ color: C_PALETTE.mid }}>§ 02</div>
          <h2 className="vc-h2">
            {lang === "tr"
              ? <>Tasarımı bir <em>ifade</em> değil<br />bir <em>karşılık</em> olarak<br />anlıyoruz.</>
              : <>We understand design<br />as a <em>response</em>,<br />not an <em>expression</em>.</>}
          </h2>
          <div>
            <p className="vc-body">{t.manifesto.body}</p>
            <div style={{ marginTop: 32, display: "grid", gap: 8 }}>
              {t.services.map((s, i) => (
                <div key={i} className="vc-mono" style={{ display: "flex", gap: 12 }}>
                  <span style={{ color: C_PALETTE.mid }}>0{i + 1}</span>
                  <span>{s.t}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="vc-container" style={{ padding: "0 24px" }}>
        <div className="vc-hairline" />
      </section>

      {/* Imagery strip */}
      <section className="vc-container" style={{ padding: "60px 24px 80px" }}>
        <div className="vc-mono" style={{ marginBottom: 24, color: C_PALETTE.mid }}>§ 03 · {lang === "tr" ? "Görüntüler" : "Imagery"}</div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(12, 1fr)", gap: 12 }}>
          {["kayakapi-hotel", "an-headquarter", "line-roastery", "sur-balik-ankara", "if-sokak-tunus"].map((slug, i) => (
            <div key={slug} className="vc-tile"
              style={{ gridColumn: i === 0 ? "span 5" : i === 1 ? "span 3" : i === 2 ? "span 4" : i === 3 ? "span 7" : "span 5" }}
              onClick={() => setPage({ name: "project", slug })}>
              <window.Placeholder slug={slug} ratio={i === 0 ? "4/3" : i === 1 ? "3/4" : i === 2 ? "4/3" : i === 3 ? "16/9" : "16/9"}
                label={window.PROJECTS.find(p => p.slug === slug)?.name} />
              <div className="vc-mono" style={{ marginTop: 8, color: C_PALETTE.mid, display: "flex", justifyContent: "space-between" }}>
                <span>{String(i + 1).padStart(2, "0")} / {window.PROJECTS.find(p => p.slug === slug)?.name}</span>
                <span>{window.PROJECTS.find(p => p.slug === slug)?.year}</span>
              </div>
            </div>
          ))}
        </div>
      </section>

      <CFooter t={t} setPage={setPage} lang={lang} />
    </div>
  );
}

function CProjects({ setPage, t, lang }) {
  const [filter, setFilter] = React.useState("all");
  const [hovered, setHovered] = React.useState(null);
  const cats = ["all", ...new Set(window.PROJECTS.map(p => p.category[lang]))];
  const sorted = [...window.PROJECTS].sort((a, b) => b.year - a.year);
  const filtered = filter === "all" ? sorted : sorted.filter(p => p.category[lang] === filter);

  return (
    <div className="vc-anim">
      <section className="vc-container" style={{ padding: "60px 24px 24px" }}>
        <div style={{ display: "grid", gridTemplateColumns: "60px 1fr 1fr", gap: 24 }}>
          <div className="vc-mono" style={{ color: C_PALETTE.mid }}>§ 01</div>
          <h1 className="vc-h1">
            {lang === "tr" ? <>Index <em>—</em><br />tüm işler</> : <>Index <em>—</em><br />all works</>}
          </h1>
          <div style={{ alignSelf: "end" }}>
            <div className="vc-mono" style={{ color: C_PALETTE.mid, marginBottom: 8 }}>{window.PROJECTS.length} {lang === "tr" ? "proje" : "projects"} · 2017—2026</div>
            <div className="vc-mono" style={{ color: C_PALETTE.mid }}>{lang === "tr" ? "Filtreyle keşfedin" : "Filter to explore"} ↓</div>
          </div>
        </div>
      </section>

      <section className="vc-container" style={{ padding: "20px 24px 16px" }}>
        <div className="vc-hairline" />
        <div style={{ display: "flex", gap: 4, padding: "16px 0", flexWrap: "wrap" }}>
          {cats.map(c => (
            <button key={c} onClick={() => setFilter(c)}
              className="vc-mono"
              style={{
                background: filter === c ? C_PALETTE.ink : C_PALETTE.paper,
                color: filter === c ? C_PALETTE.bg : C_PALETTE.mid,
                border: `1px solid ${filter === c ? C_PALETTE.ink : C_PALETTE.rule}`,
                padding: "6px 12px", cursor: "pointer", fontFamily: "inherit",
              }}>
              {c === "all" ? (lang === "tr" ? "Hepsi" : "All") : c} <span style={{ opacity: 0.6, marginLeft: 6 }}>({c === "all" ? window.PROJECTS.length : window.PROJECTS.filter(p => p.category[lang] === c).length})</span>
            </button>
          ))}
        </div>
        <div className="vc-hairline" />
      </section>

      <section className="vc-container" style={{ padding: "0 24px 60px", display: "grid", gridTemplateColumns: "1fr 400px", gap: 40, alignItems: "start" }}>
        <div>
          <div className="vc-row" style={{ gridTemplateColumns: "40px 2fr 1.2fr 1.2fr 0.8fr 0.6fr 50px", padding: "10px 0", color: C_PALETTE.mid }}>
            <div className="vc-mono">#</div>
            <div className="vc-mono">{lang === "tr" ? "Proje" : "Project"}</div>
            <div className="vc-mono">{t.sections.location}</div>
            <div className="vc-mono">{t.sections.category}</div>
            <div className="vc-mono">{t.sections.area}</div>
            <div className="vc-mono">{t.sections.year}</div>
            <div></div>
          </div>
          {filtered.map((p, i) => (
            <div key={p.slug} className="vc-row"
              style={{ gridTemplateColumns: "40px 2fr 1.2fr 1.2fr 0.8fr 0.6fr 50px" }}
              onClick={() => setPage({ name: "project", slug: p.slug })}
              onMouseEnter={() => setHovered(p.slug)}
              onMouseLeave={() => setHovered(null)}>
              <div className="vc-mono" style={{ color: C_PALETTE.mid }}>{String(i + 1).padStart(2, "0")}</div>
              <div className="vc-rowname">{p.name}</div>
              <div className="vc-mono" style={{ color: C_PALETTE.mid }}>{p.location}</div>
              <div className="vc-mono" style={{ color: C_PALETTE.mid }}>{p.category[lang]}</div>
              <div className="vc-mono" style={{ color: C_PALETTE.mid }}>{p.area}</div>
              <div className="vc-mono">{p.year}</div>
              <div className="vc-mono" style={{ textAlign: "right", color: C_PALETTE.accent }}>→</div>
            </div>
          ))}
        </div>
        <div style={{ position: "sticky", top: 100 }}>
          <div className="vc-mono" style={{ color: C_PALETTE.mid, marginBottom: 10 }}>
            {hovered ? `~ ${hovered}.preview` : `// ${lang === "tr" ? "satır üzerinde gez" : "hover a row"}`}
          </div>
          <div style={{ border: `1px solid ${C_PALETTE.rule}`, background: C_PALETTE.paper, padding: 14 }}>
            {hovered ? (
              <window.Placeholder slug={hovered} ratio="4/5" label={window.PROJECTS.find(p => p.slug === hovered)?.name} />
            ) : (
              <window.Placeholder slug="filter" ratio="4/5" label={lang === "tr" ? "[ önizleme ]" : "[ preview ]"} />
            )}
            {hovered && (() => {
              const p = window.PROJECTS.find(p => p.slug === hovered);
              return (
                <div style={{ marginTop: 12, fontFamily: "var(--mono)", fontSize: 11, color: C_PALETTE.mid, display: "grid", gap: 4 }}>
                  <div>NAME : <span style={{ color: C_PALETTE.ink }}>{p.name}</span></div>
                  <div>LOC  : {p.location}</div>
                  <div>TYPE : {p.category[lang]}</div>
                  <div>AREA : {p.area}</div>
                  <div>YEAR : {p.year}</div>
                </div>
              );
            })()}
          </div>
        </div>
      </section>

      <CFooter t={t} setPage={setPage} lang={lang} />
    </div>
  );
}

function CProject({ slug, setPage, t, lang }) {
  const idx = window.PROJECTS.findIndex(p => p.slug === slug);
  const p = window.PROJECTS[idx];
  if (!p) return null;
  const prev = window.PROJECTS[(idx - 1 + window.PROJECTS.length) % window.PROJECTS.length];
  const next = window.PROJECTS[(idx + 1) % window.PROJECTS.length];

  return (
    <div className="vc-anim">
      <section className="vc-container" style={{ padding: "40px 24px 24px" }}>
        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 20 }}>
          <a className="vc-mono" style={{ cursor: "pointer" }} onClick={() => setPage({ name: "projects" })}>← {t.sections.index}</a>
          <div className="vc-mono" style={{ color: C_PALETTE.mid }}>
            {String(idx + 1).padStart(2, "0")} / {String(window.PROJECTS.length).padStart(2, "0")}
          </div>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "60px 1fr", gap: 24 }}>
          <div className="vc-mono" style={{ color: C_PALETTE.mid }}>{p.slug}</div>
          <h1 className="vc-h1">{p.name}</h1>
        </div>

        <div style={{ marginTop: 32 }} className="vc-meta-grid">
          {[
            [t.sections.year, p.year],
            [t.sections.location, p.location],
            [t.sections.category, p.category[lang]],
            [t.sections.area, p.area],
          ].map(([k, v], i) => (
            <div key={i} className="vc-meta-cell">
              <div className="k">{k}</div>
              <div className="v">{v}</div>
            </div>
          ))}
        </div>
      </section>

      <section className="vc-container" style={{ padding: "20px 24px 0" }}>
        <window.Placeholder slug={p.slug} ratio="16/9" label={`${p.name} · 01`} scale={1.3} />
      </section>

      <section className="vc-container" style={{ padding: "60px 24px 40px" }}>
        <div style={{ display: "grid", gridTemplateColumns: "60px 1fr 1fr", gap: 40 }}>
          <div className="vc-mono" style={{ color: C_PALETTE.mid }}>§ 01</div>
          <div className="vc-lede">
            {lang === "tr"
              ? <>"{p.program.tr}." Programın yere ait olması için yazılmış<br />malzeme dili.</>
              : <>"{p.program.en}." A material vocabulary written<br />to belong to its place.</>}
          </div>
          <div>
            <p className="vc-body">
              {lang === "tr"
                ? `${p.name}, ${p.location}'da ${p.area} alan üzerinde geliştirildi. ${p.client} için tasarlanan projenin programı ${p.program.tr.toLowerCase()} kapsıyor. Stüdyo, tasarım ve uygulamayı tek elden yürüttü.`
                : `${p.name} was developed on ${p.area} in ${p.location}. Designed for ${p.client}, the brief covers ${p.program.en.toLowerCase()}. The studio led design and execution end-to-end.`}
            </p>
            <div style={{ marginTop: 20, display: "flex", gap: 6, flexWrap: "wrap" }}>
              <span className="vc-tag">{p.category[lang]}</span>
              <span className="vc-tag">{p.year}</span>
              <span className="vc-tag">{p.location}</span>
              <span className="vc-tag">{t.sections.completed}</span>
            </div>
          </div>
        </div>
      </section>

      <section className="vc-container" style={{ padding: "20px 24px 0" }}>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(12, 1fr)", gap: 12 }}>
          <div style={{ gridColumn: "span 7" }}>
            <window.Placeholder slug={p.slug} ratio="4/3" label={`${p.name} · 02`} idx={2} />
          </div>
          <div style={{ gridColumn: "span 5" }}>
            <window.Placeholder slug={p.slug} ratio="3/4" label={`${p.name} · 03`} idx={3} />
          </div>
          <div style={{ gridColumn: "span 5" }}>
            <window.Placeholder slug={p.slug} ratio="4/5" label={`${p.name} · 04`} idx={4} />
          </div>
          <div style={{ gridColumn: "span 7" }}>
            <window.Placeholder slug={p.slug} ratio="4/3" label={`${p.name} · 05`} idx={5} />
          </div>
          <div style={{ gridColumn: "span 12" }}>
            <window.Placeholder slug={p.slug} ratio="16/7" label={`${p.name} · 06`} idx={6} scale={1.2} />
          </div>
        </div>
      </section>

      <section className="vc-container" style={{ padding: "80px 24px 60px" }}>
        <div className="vc-hairline" style={{ marginBottom: 24 }} />
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 40 }}>
          <a className="vc-tile" onClick={() => setPage({ name: "project", slug: prev.slug })}>
            <div className="vc-mono" style={{ color: C_PALETTE.mid, marginBottom: 12 }}>← {t.sections.prev}</div>
            <div className="vc-rowname" style={{ fontSize: 28 }}>{prev.name}</div>
            <div className="vc-mono" style={{ color: C_PALETTE.mid, marginTop: 8 }}>{prev.location} · {prev.year}</div>
          </a>
          <a className="vc-tile" style={{ textAlign: "right" }} onClick={() => setPage({ name: "project", slug: next.slug })}>
            <div className="vc-mono" style={{ color: C_PALETTE.mid, marginBottom: 12 }}>{t.sections.next} →</div>
            <div className="vc-rowname" style={{ fontSize: 28 }}>{next.name}</div>
            <div className="vc-mono" style={{ color: C_PALETTE.mid, marginTop: 8 }}>{next.location} · {next.year}</div>
          </a>
        </div>
      </section>

      <CFooter t={t} setPage={setPage} lang={lang} />
    </div>
  );
}

function CAbout({ setPage, t, lang }) {
  const byYear = window.PROJECTS.reduce((acc, p) => { (acc[p.year] = acc[p.year] || []).push(p); return acc; }, {});
  const years = Object.keys(byYear).sort();
  return (
    <div className="vc-anim">
      <section className="vc-container" style={{ padding: "60px 24px 24px" }}>
        <div style={{ display: "grid", gridTemplateColumns: "60px 1fr", gap: 24 }}>
          <div className="vc-mono" style={{ color: C_PALETTE.mid }}>§ 02</div>
          <h1 className="vc-h1">
            {lang === "tr" ? <>Stüdyo <em>—</em><br />Ankara, 2017</> : <>Studio <em>—</em><br />Ankara, 2017</>}
          </h1>
        </div>
      </section>

      <section className="vc-container" style={{ padding: "40px 24px 60px" }}>
        <div className="vc-meta-grid">
          {t.about.facts.map(([k, v], i) => (
            <div key={i} className="vc-meta-cell">
              <div className="k">{k}</div>
              <div className="v">{v}</div>
            </div>
          ))}
        </div>
      </section>

      <section className="vc-container" style={{ padding: "0 24px 60px" }}>
        <div style={{ display: "grid", gridTemplateColumns: "60px 1fr 1fr", gap: 40 }}>
          <div className="vc-mono" style={{ color: C_PALETTE.mid }}>{lang === "tr" ? "Manifesto" : "Manifesto"}</div>
          <div>
            <h2 className="vc-h2" style={{ marginBottom: 32 }}>
              {lang === "tr"
                ? <>Detay süs <em>değil</em>,<br />mekânın <em>nasıl</em><br />yaşlanacağına dair<br />bir taahhüt.</>
                : <>Detail is <em>not</em> ornament,<br />it is a promise <em>about</em><br />how a space<br />will age.</>}
            </h2>
          </div>
          <div>
            {t.about.paras.map((para, i) => (
              <p key={i} className="vc-body" style={{ marginTop: i === 0 ? 0 : 18 }}>{para}</p>
            ))}
          </div>
        </div>
      </section>

      <section className="vc-container" style={{ padding: "0 24px 40px" }}>
        <div className="vc-hairline" />
      </section>

      {/* Timeline / Archive */}
      <section className="vc-container" style={{ padding: "40px 24px 80px" }}>
        <div className="vc-mono" style={{ color: C_PALETTE.mid, marginBottom: 24 }}>§ 03 · {lang === "tr" ? "Arşiv" : "Archive"}</div>
        {years.map((y) => (
          <div key={y} style={{ display: "grid", gridTemplateColumns: "120px 1fr", gap: 32, padding: "20px 0", borderTop: `1px solid ${C_PALETTE.rule}`, alignItems: "baseline" }}>
            <div style={{ fontFamily: "var(--display)", fontSize: 36, letterSpacing: "-0.03em" }}>{y}</div>
            <div style={{ display: "flex", flexWrap: "wrap", gap: 24, rowGap: 8 }}>
              {byYear[y].map(p => (
                <a key={p.slug} className="vc-rowname" style={{ fontSize: 18, cursor: "pointer", fontFamily: "var(--display)" }}
                  onClick={() => setPage({ name: "project", slug: p.slug })}>{p.name}</a>
              ))}
            </div>
          </div>
        ))}
      </section>

      <CFooter t={t} setPage={setPage} lang={lang} />
    </div>
  );
}

function CContact({ setPage, t, lang }) {
  const [sent, setSent] = React.useState(false);
  return (
    <div className="vc-anim">
      <section className="vc-container" style={{ padding: "60px 24px 24px" }}>
        <div style={{ display: "grid", gridTemplateColumns: "60px 1fr", gap: 24 }}>
          <div className="vc-mono" style={{ color: C_PALETTE.mid }}>§ 03</div>
          <h1 className="vc-h1">
            {lang === "tr" ? <>İletişim <em>—</em><br />yazın, arayın.</> : <>Contact <em>—</em><br />write, call.</>}
          </h1>
        </div>
      </section>

      <section className="vc-container" style={{ padding: "40px 24px 60px" }}>
        <div className="vc-meta-grid" style={{ gridTemplateColumns: "1fr 1fr 1fr" }}>
          <div className="vc-meta-cell">
            <div className="k">{t.contact.labels.email}</div>
            <div className="v"><a href={`mailto:${window.CONTACT.email}`} style={{ color: C_PALETTE.accent }}>{window.CONTACT.email}</a></div>
          </div>
          <div className="vc-meta-cell">
            <div className="k">{t.contact.labels.phone}</div>
            <div className="v">{window.CONTACT.phone}</div>
          </div>
          <div className="vc-meta-cell">
            <div className="k">{t.contact.labels.instagram}</div>
            <div className="v">{window.CONTACT.instagram}</div>
          </div>
        </div>
      </section>

      <section className="vc-container" style={{ padding: "0 24px 80px" }}>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 60 }}>
          <div>
            <div className="vc-mono" style={{ color: C_PALETTE.mid, marginBottom: 12 }}>// {t.contact.labels.address}</div>
            <p style={{ fontFamily: "var(--display)", fontSize: 22, lineHeight: 1.35, letterSpacing: "-0.015em", margin: 0 }}>
              {window.CONTACT.address}
            </p>
            <div className="vc-mono" style={{ color: C_PALETTE.mid, marginTop: 24, marginBottom: 8 }}>// {t.contact.labels.hours}</div>
            <p style={{ fontFamily: "var(--display)", fontSize: 18, margin: 0, letterSpacing: "-0.01em" }}>{t.contact.hours}</p>

            <div style={{ marginTop: 32, paddingTop: 24, borderTop: `1px solid ${C_PALETTE.rule}` }}>
              <window.Placeholder slug="map-c" ratio="16/9" label={`Kuzu Effect · Oran · Çankaya`} />
            </div>
          </div>
          <div>
            <div className="vc-mono" style={{ color: C_PALETTE.mid, marginBottom: 12 }}>// {lang === "tr" ? "Yeni proje" : "New project"}</div>
            {sent ? (
              <div style={{ fontFamily: "var(--display)", fontSize: 22, padding: "20px 0", borderTop: `1px solid ${C_PALETTE.ink}` }}>
                ✓ {t.contact.form.thanks}
              </div>
            ) : (
              <form onSubmit={(e) => { e.preventDefault(); setSent(true); }} style={{ display: "grid", gap: 0, border: `1px solid ${C_PALETTE.rule}` }}>
                {["name", "email", "subject"].map((k, i) => (
                  <div key={k} style={{ display: "grid", gridTemplateColumns: "120px 1fr", borderBottom: `1px solid ${C_PALETTE.rule}` }}>
                    <label className="vc-mono" style={{ padding: "14px 16px", background: C_PALETTE.bg2, color: C_PALETTE.mid, borderRight: `1px solid ${C_PALETTE.rule}` }}>
                      {String(i + 1).padStart(2, "0")} {t.contact.form[k]}
                    </label>
                    <input required type={k === "email" ? "email" : "text"}
                      style={{ background: C_PALETTE.paper, border: "none", padding: "14px 16px", fontFamily: "var(--mono)", fontSize: 13, color: C_PALETTE.ink, outline: "none" }} />
                  </div>
                ))}
                <div style={{ display: "grid", gridTemplateColumns: "120px 1fr" }}>
                  <label className="vc-mono" style={{ padding: "14px 16px", background: C_PALETTE.bg2, color: C_PALETTE.mid, borderRight: `1px solid ${C_PALETTE.rule}` }}>04 {t.contact.form.message}</label>
                  <textarea required rows="5"
                    style={{ background: C_PALETTE.paper, border: "none", padding: "14px 16px", fontFamily: "var(--mono)", fontSize: 13, color: C_PALETTE.ink, outline: "none", resize: "vertical" }} />
                </div>
                <button type="submit" className="vc-btn" style={{ borderRadius: 0, borderTop: `1px solid ${C_PALETTE.rule}`, border: "none", justifyContent: "space-between", padding: 16 }}>
                  <span>→ {t.contact.form.send}</span>
                  <span>↵</span>
                </button>
              </form>
            )}
          </div>
        </div>
      </section>

      <CFooter t={t} setPage={setPage} lang={lang} />
    </div>
  );
}

function CFooter({ t, setPage, lang }) {
  return (
    <footer style={{ background: C_PALETTE.bg2, borderTop: `1px solid ${C_PALETTE.ink}`, marginTop: 60, position: "relative", zIndex: 2 }}>
      <div className="vc-container" style={{ padding: "60px 24px 24px" }}>
        <h2 className="vc-h1" style={{ fontSize: "clamp(48px, 8vw, 140px)", marginBottom: 40 }}>
          {lang === "tr" ? <>hello@<em>lineinterior</em>.co</> : <>hello@<em>lineinterior</em>.co</>}
        </h2>
        <div className="vc-hairline" style={{ background: C_PALETTE.rule }} />
        <div style={{ display: "grid", gridTemplateColumns: "repeat(5, 1fr)", gap: 16, padding: "20px 0", borderBottom: `1px solid ${C_PALETTE.rule}` }}>
          <div>
            <div className="vc-mono" style={{ color: C_PALETTE.mid, marginBottom: 6 }}>// EMAIL</div>
            <div>{window.CONTACT.email}</div>
          </div>
          <div>
            <div className="vc-mono" style={{ color: C_PALETTE.mid, marginBottom: 6 }}>// PHONE</div>
            <div>{window.CONTACT.phone}</div>
          </div>
          <div>
            <div className="vc-mono" style={{ color: C_PALETTE.mid, marginBottom: 6 }}>// INSTAGRAM</div>
            <div>{window.CONTACT.instagram}</div>
          </div>
          <div style={{ gridColumn: "span 2" }}>
            <div className="vc-mono" style={{ color: C_PALETTE.mid, marginBottom: 6 }}>// ADDRESS</div>
            <div>{window.CONTACT.address}</div>
          </div>
        </div>
        <div style={{ display: "flex", justifyContent: "space-between", padding: "16px 0", color: C_PALETTE.mid }}>
          <div className="vc-mono">{t.footer.colophon}</div>
          <div className="vc-mono">{window.CONTACT.domain} · v2026.1</div>
        </div>
      </div>
    </footer>
  );
}

function VariationC(props) {
  const { page, ...rest } = props;
  return (
    <CLayoutFixed {...props}>
      {page.name === "index" && <CHome {...rest} setPage={props.setPage} />}
      {page.name === "projects" && <CProjects {...rest} setPage={props.setPage} />}
      {page.name === "project" && <CProject slug={page.slug} {...rest} setPage={props.setPage} />}
      {page.name === "about" && <CAbout {...rest} setPage={props.setPage} />}
      {page.name === "contact" && <CContact {...rest} setPage={props.setPage} />}
    </CLayoutFixed>
  );
}

window.VariationC = VariationC;
