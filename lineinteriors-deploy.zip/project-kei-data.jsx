/* eslint-disable */
// Kei — custom project page with real renders + Japanese-minimalist composition

const KEI = {
  slug: "kei",
  name: "Kei",
  ja: "系",
  year: 2026,
  location: { tr: "Merkez, Ankara", en: "Merkez, Ankara" },
  area: "220 m²",
  capacity: { tr: "İç 75 · Dış 91 kişi", en: "Interior 75 · Exterior 91" },
  client: "Kei",
  program: { tr: "Japon mutfağı · Pastane · Kavurmahane · Bambu bahçesi", en: "Japanese cuisine · Pâtisserie · Coffee roastery · Bamboo garden" },
  status: { tr: "2026 — Tamamlandı", en: "2026 — Completed" },
  // Mottos & manifestos lifted directly from the brief
  mottos: {
    hero: {
      tr: "Estetik, pürüzsüzlükten değil,\ndoğallığın dürüstlüğünden doğar.",
      en: "Beauty is not born of smoothness —\nbut of the honesty of nature.",
    },
    invitation: {
      title: { tr: "Davet", en: "Invitation" },
      body: { tr: "Bambu bahçesi nefes almaksa, iç mekân da o nefesi tutmak.", en: "If the bamboo garden is a breath drawn in, the interior is the breath held still." },
    },
    garden: {
      title: { tr: "Boşluğun Bahçesi", en: "The Garden of Emptiness" },
      sub: { tr: "Ma no Niwa · 間の庭", en: "Ma no Niwa · 間の庭" },
      body: { tr: "Japon minimalizmindeki bilinçli boşluk anlayışını taşıyor; doğa ve yapının birbirine üstün gelmeden birlikte var olduğu sessiz bir merkez.", en: "It carries the deliberate emptiness of Japanese minimalism — a quiet centre where nature and structure exist together, with neither overpowering the other." },
    },
  },
  // Image gallery — paths relative to project root
  images: {
    hero: "assets/projects/kei/01-hero-facade.jpg",
    pair1: ["assets/projects/kei/03-front-umbrellas.jpg", "assets/projects/kei/04-terrace-city.jpg"],
    garden: "assets/projects/kei/06-bamboo-island.jpg",
    garden2: "assets/projects/kei/02-bamboo-garden.jpg",
    columnWide: "assets/projects/kei/08-kei-column.jpg",
    columnAlt: "assets/projects/kei/09-kei-column-2.jpg",
    interiorRow: [
      "assets/projects/kei/11-cafe.jpg",
      "assets/projects/kei/12-sculpt-pendant.jpg",
    ],
    longTable: "assets/projects/kei/14-communal-table.jpg",
    windowSeating: "assets/projects/kei/13-window-seating.jpg",
    pastry: "assets/projects/kei/10-pastry.jpg",
    barDetail: "assets/projects/kei/bar-detail.jpg",
    japanArt: "assets/projects/kei/15-japan-art.jpg",
    tileWall: "assets/projects/kei/tile-wall.jpg",
    materials: "assets/projects/kei/16-materials.jpg",
    bathroom: "assets/projects/kei/17-bathroom.jpg",
    wc: "assets/projects/kei/18-wc.jpg",
    lightDetail: "assets/projects/kei/19-light-detail.jpg",
    terrace: "assets/projects/kei/05-bamboo-outdoor.jpg",
    longTerrace: "assets/projects/kei/07-long-terrace.jpg",
    plan: "assets/projects/kei/plan.jpg",
    section: "assets/projects/kei/section.jpg",
    bubble: "assets/projects/kei/bubble.jpg",
  },
  // Spaces breakdown from PDF
  breakdown: {
    tr: [
      ["Üretim alanı", "53 m²"],
      ["Bulaşıkhane", "5.3 m²"],
      ["Mutfak", "18 m²"],
      ["Fırın", "11.6 m²"],
      ["Pastane", "7.5 m²"],
      ["Soğuk hava deposu", "7 m²"],
      ["Bar ve servis", "27 m²"],
      ["Kahve kavurma", "9 m²"],
      ["Islak hacim", "5 m²"],
      ["İç oturum alanı", "113 m²"],
      ["Dış oturum alanı", "144 m²"],
    ],
    en: [
      ["Production area", "53 m²"],
      ["Dishwash", "5.3 m²"],
      ["Kitchen", "18 m²"],
      ["Bakery oven", "11.6 m²"],
      ["Pâtisserie", "7.5 m²"],
      ["Cold storage", "7 m²"],
      ["Bar & service", "27 m²"],
      ["Coffee roastery", "9 m²"],
      ["Bathrooms", "5 m²"],
      ["Interior seating", "113 m²"],
      ["Exterior seating", "144 m²"],
    ],
  },
};

window.KEI = KEI;
