/* eslint-disable */
// Variation B — Cinematic Dark
// Dominant koyu kahve. Large hero imagery. Sticky left sidebar nav.
// Manifesto hero with marquee. Big stacked tiles.

const B_PALETTE = {
  bg: "#1c160f",
  bg2: "#251d14",
  paper: "#2e2418",
  ink: "#f1e8d5",
  mid: "#a89376",
  rule: "rgba(241,232,213,0.12)",
  accent: "#c89863",
};

const B_FONTS = `
@import url('https://fonts.googleapis.com/css2?family=Instrument+Serif:ital@0;1&family=Instrument+Sans:ital,wght@0,400..700;1,400..700&family=JetBrains+Mono:wght@300;400;500&display=swap');
`;

function BLayout({ children, page, setPage, lang, setLang, t }) {
  const links = [
    ["index", t.nav.index],
    ["projects", t.nav.projects],
    ["about", t.nav.about],
    ["contact", t.nav.contact],
  ];
  return (
    <div className="vb-root">
      <style>{B_FONTS}{`
        .vb-root { background: ${B_PALETTE.bg}; color: ${B_PALETTE.ink}; font-family: var(--display); min-height: 100vh; display: grid; grid-template-columns: 220px 1fr; }
        .vb-root a { color: inherit; text-decoration: none; }
        .vb-side { position: sticky; top: 0; height: 100vh; padding: 32px 28px; border-right: 1px solid ${B_PALETTE.rule}; display: flex; flex-direction: column; gap: 0; align-self: start; background: ${B_PALETTE.bg}; }
        .vb-mark { display: block; margin-bottom: 56px; }
        .vb-mark img { width: 150px; display: block; }
        .vb-mark-meta { font-family: var(--mono); font-size: 10px; letter-spacing: 0.1em; text-transform: uppercase; color: ${B_PALETTE.mid}; margin-top: 12px; line-height: 1.4; }
        .vb-side-nav { display: flex; flex-direction: column; gap: 4px; }
        .vb-side-link { display: flex; align-items: baseline; justify-content: space-between; padding: 10px 0; font-size: 17px; cursor: pointer; color: ${B_PALETTE.mid}; transition: color .25s; border-bottom: 1px solid transparent; }
        .vb-side-link[data-active="true"] { color: ${B_PALETTE.ink}; }
        .vb-side-link:hover { color: ${B_PALETTE.ink}; }
        .vb-side-link .num { font-family: var(--mono); font-size: 10px; letter-spacing: 0.1em; opacity: 0.5; }
        .vb-side-foot { margin-top: auto; font-family: var(--mono); font-size: 10px; letter-spacing: 0.1em; text-transform: uppercase; color: ${B_PALETTE.mid}; line-height: 1.6; }
        .vb-lang { display: flex; gap: 6px; margin-bottom: 14px; }
        .vb-lang button { background: none; border: 1px solid ${B_PALETTE.rule}; color: ${B_PALETTE.mid}; padding: 5px 9px; cursor: pointer; font-family: var(--mono); font-size: 10px; letter-spacing: 0.1em; }
        .vb-lang button[data-active="true"] { background: ${B_PALETTE.accent}; color: ${B_PALETTE.bg}; border-color: ${B_PALETTE.accent}; }
        .vb-main { padding: 0; min-width: 0; }
        .vb-eyebrow { font-family: var(--mono); font-size: 11px; letter-spacing: 0.16em; text-transform: uppercase; color: ${B_PALETTE.mid}; }
        .vb-h1 { font-family: var(--display); font-weight: 400; font-size: clamp(60px, 10vw, 200px); line-height: 0.9; letter-spacing: -0.045em; }
        .vb-h1 em { font-family: var(--serif); font-style: italic; font-weight: 400; color: ${B_PALETTE.accent}; }
        .vb-h2 { font-family: var(--display); font-weight: 400; font-size: clamp(42px, 5.5vw, 92px); line-height: 0.96; letter-spacing: -0.035em; }
        .vb-h2 em { font-family: var(--serif); font-style: italic; color: ${B_PALETTE.accent}; }
        .vb-h3 { font-family: var(--display); font-weight: 500; font-size: 22px; letter-spacing: -0.015em; }
        .vb-lede { font-family: var(--serif); font-style: italic; font-size: clamp(22px, 1.8vw, 28px); line-height: 1.42; max-width: 32ch; color: ${B_PALETTE.mid}; }
        .vb-body { font-size: 16px; line-height: 1.6; color: ${B_PALETTE.mid}; max-width: 60ch; }
        .vb-meta { font-family: var(--mono); font-size: 11px; letter-spacing: 0.14em; text-transform: uppercase; color: ${B_PALETTE.mid}; }
        .vb-rule { height: 1px; background: ${B_PALETTE.rule}; }
        .vb-tile { cursor: pointer; position: relative; }
        .vb-tile .ph-img > div:first-of-type { transition: transform 1.4s cubic-bezier(.2,.7,.1,1); }
        .vb-tile:hover .ph-img > div:first-of-type { transform: scale(1.05); }
        @keyframes vb-fade { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: none; } }
        .vb-anim { /* vb-fade removed */ }
        .vb-marquee { white-space: nowrap; overflow: hidden; padding: 24px 0; border-top: 1px solid ${B_PALETTE.rule}; border-bottom: 1px solid ${B_PALETTE.rule}; }
        .vb-marquee-inner { display: inline-flex; gap: 80px; animation: vb-mar 60s linear infinite; }
        @keyframes vb-mar { from { transform: translateX(0); } to { transform: translateX(-50%); } }
        .vb-mar-item { font-family: var(--display); font-size: 28px; letter-spacing: -0.02em; color: ${B_PALETTE.mid}; display: inline-flex; align-items: center; gap: 80px; }
        .vb-mar-item::after { content: "✦"; color: ${B_PALETTE.accent}; font-size: 16px; }
        .vb-cta { display: inline-flex; align-items: center; gap: 12px; padding: 18px 28px; border: 1px solid ${B_PALETTE.ink}; color: ${B_PALETTE.ink}; cursor: pointer; font-size: 15px; transition: all .25s; }
        .vb-cta:hover { background: ${B_PALETTE.ink}; color: ${B_PALETTE.bg}; }
        .vb-cta .arr { transition: transform .25s; }
        .vb-cta:hover .arr { transform: translateX(4px); }
      `}</style>

      <aside className="vb-side">
        <a className="vb-mark" onClick={() => setPage({ name: "index" })} style={{ cursor: "pointer" }}>
          <img src="assets/wordmark-cream.png" alt="Line Interiors" />
          <div className="vb-mark-meta">
            Design Studio<br />Çankaya, Ankara<br />Est. 2017
          </div>
        </a>
        <nav className="vb-side-nav">
          {links.map(([k, label], i) => (
            <a key={k} className="vb-side-link"
              data-active={page.name === k || (k === "projects" && page.name === "project")}
              onClick={() => setPage({ name: k })}>
              <span>{label}</span>
              <span className="num">0{i + 1}</span>
            </a>
          ))}
        </nav>
        <div className="vb-side-foot">
          <div className="vb-lang">
            <button data-active={lang === "en"} onClick={() => setLang("en")}>EN</button>
            <button data-active={lang === "tr"} onClick={() => setLang("tr")}>TR</button>
          </div>
          <div>{window.CONTACT.email}</div>
          <div>{window.CONTACT.phone}</div>
          <div style={{ marginTop: 14 }}>© 2017—26</div>
        </div>
      </aside>

      <main className="vb-main">{children}</main>
    </div>
  );
}

function BHome({ setPage, t, lang }) {
  const featured = ["kayakapi-hotel", "an-headquarter", "line-roastery", "if-sokak-tunus", "sur-balik-ankara", "kei", "vaa-coffee", "lets-bake-artisan"];
  const fp = featured.map(s => window.PROJECTS.find(p => p.slug === s));

  // Marquee items
  const marItems = window.PROJECTS.slice(0, 14).map(p => p.name);
  const marDoubled = [...marItems, ...marItems];

  return (
    <div className="vb-anim">
      <section style={{ padding: "80px 80px 60px" }}>
        <div className="vb-eyebrow" style={{ marginBottom: 28 }}>{t.hero.eyebrow}</div>
        {window.ScrollReveal ? (
          <window.ScrollReveal delay={100} direction="up" distance={50} duration={1100}>
            <h1 className="vb-h1">
              {t.hero.title[0]}<br />
              <em>{t.hero.title[1]}</em><br />
              {t.hero.title[2]}
            </h1>
          </window.ScrollReveal>
        ) : (
          <h1 className="vb-h1">
            {t.hero.title[0]}<br />
            <em>{t.hero.title[1]}</em><br />
            {t.hero.title[2]}
          </h1>
        )}
        <window.ScrollReveal delay={400} direction="up" distance={30} duration={900}>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 60, marginTop: 80 }}>
          <p className="vb-body" style={{ fontSize: 17, maxWidth: "44ch" }}>{t.hero.lede}</p>
          <div style={{ alignSelf: "end", display: "flex", justifyContent: "flex-end" }}>
            <a className="vb-cta" onClick={() => setPage({ name: "projects" })}>
              {t.hero.cta} <span className="arr">→</span>
            </a>
          </div>
        </div>
        </window.ScrollReveal>
      </section>

      {/* big cinematic hero */}
      <section style={{ padding: "20px 0 0" }}>
        <div className="vb-tile" onClick={() => setPage({ name: "project", slug: fp[0].slug })}>
          <window.Placeholder slug={fp[0].slug} ratio="16/7" label="01 — Kayakapı Hotel · Kapadokya · 2022" scale={1.4} dark />
        </div>
      </section>

      {/* marquee */}
      <section className="vb-marquee" style={{ marginTop: 60 }}>
        <div className="vb-marquee-inner">
          {marDoubled.map((n, i) => <span key={i} className="vb-mar-item">{n}</span>)}
        </div>
      </section>

      {/* manifesto */}
      <section style={{ padding: "120px 80px" }}>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 2fr", gap: 60, alignItems: "start" }}>
          <div className="vb-meta">{t.manifesto.title} / 01</div>
          <div>
            <window.ScrollReveal delay={200} direction="up" distance={40} duration={1000}>
            <h2 className="vb-h2" style={{ marginBottom: 40 }}>
              {lang === "tr"
                ? <>Detay süs <em>değil</em>,<br />mekânın <em>nasıl yaşlanacağına</em><br />dair bir taahhüttür.</>
                : <>Detail is <em>not</em> ornament —<br />it is a promise <em>about how</em><br />a space will age.</>}
            </h2>
            <p className="vb-body" style={{ fontSize: 17, maxWidth: "52ch" }}>{t.manifesto.body}</p>
            </window.ScrollReveal>
          </div>
        </div>
      </section>

      {/* split projects */}
      <section style={{ padding: "0 80px" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", marginBottom: 32 }}>
          <div className="vb-meta">{t.sections.featured} · 06</div>
          <a className="vb-meta" style={{ cursor: "pointer" }} onClick={() => setPage({ name: "projects" })}>
            {t.sections.all} →
          </a>
        </div>
        <div className="vb-rule" style={{ marginBottom: 48 }} />
      </section>

      <section style={{ padding: "0 80px 60px" }}>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 32 }}>
          {fp.slice(1, 5).map((p, i) => (
            <div key={p.slug} className="vb-tile" onClick={() => setPage({ name: "project", slug: p.slug })}
              style={{ paddingTop: i % 2 === 1 ? 80 : 0 }}>
              <window.Placeholder slug={p.slug} ratio={i % 3 === 0 ? "4/5" : "4/3"} label={p.name} dark />
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", marginTop: 16 }}>
                <div>
                  <div className="vb-h3">{p.name}</div>
                  <div className="vb-meta" style={{ marginTop: 6 }}>{p.location} · {p.category[lang]}</div>
                </div>
                <div className="vb-meta">{p.year}</div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* big single again */}
      <section style={{ padding: "60px 0 0" }}>
        <div className="vb-tile" onClick={() => setPage({ name: "project", slug: fp[5].slug })}>
          <window.Placeholder slug={fp[5].slug} ratio="16/9" label={fp[5].name + " · " + fp[5].location} scale={1.3} dark />
        </div>
      </section>

      {/* services */}
      <section style={{ padding: "120px 80px 100px" }}>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 2fr", gap: 60, marginBottom: 60 }}>
          <div className="vb-meta">{t.sections.services} / 02</div>
          <h2 className="vb-h2">
            {lang === "tr" ? <>Tek <em>ekip</em>.<br />Konseptten teslime.</> : <>One <em>team</em>.<br />Concept to handover.</>}
          </h2>
        </div>
        <div className="vb-rule" style={{ marginBottom: 0 }} />
        {t.services.map((s, i) => (
          <window.ScrollReveal key={i} delay={i * 100} direction="up" distance={25} duration={800}>
          <div style={{ display: "grid", gridTemplateColumns: "60px 1fr 2fr", gap: 32, padding: "32px 0", borderBottom: `1px solid ${B_PALETTE.rule}`, alignItems: "baseline" }}>
            <div className="vb-meta">0{i + 1}</div>
            <h3 className="vb-h2" style={{ fontSize: "clamp(28px, 3vw, 42px)" }}>{s.t}</h3>
            <p className="vb-body" style={{ fontSize: 17 }}>{s.d}</p>
          </div>
          </window.ScrollReveal>
        ))}
      </section>

      <BFooter t={t} setPage={setPage} lang={lang} />
    </div>
  );
}

function BProjects({ setPage, t, lang }) {
  const [view, setView] = React.useState("grid");
  return (
    <div className="vb-anim">
      <section style={{ padding: "80px 80px 40px" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline" }}>
          <div>
            <div className="vb-eyebrow" style={{ marginBottom: 24 }}>{t.sections.index} · {window.PROJECTS.length}</div>
            <h1 className="vb-h1">{lang === "tr" ? <>İşler</> : <>Works</>}</h1>
          </div>
          <div className="vb-meta" style={{ display: "flex", gap: 16 }}>
            <button onClick={() => setView("grid")} data-active={view === "grid"}
              style={{ background: "none", border: "none", color: view === "grid" ? B_PALETTE.ink : B_PALETTE.mid, padding: 0, cursor: "pointer", fontFamily: "inherit", fontSize: "inherit", letterSpacing: "inherit", textTransform: "inherit" }}>
              ▦ Grid
            </button>
            <button onClick={() => setView("list")} data-active={view === "list"}
              style={{ background: "none", border: "none", color: view === "list" ? B_PALETTE.ink : B_PALETTE.mid, padding: 0, cursor: "pointer", fontFamily: "inherit", fontSize: "inherit", letterSpacing: "inherit", textTransform: "inherit" }}>
              ☰ List
            </button>
          </div>
        </div>
      </section>

      {view === "grid" ? (
        <section style={{ padding: "40px 80px 0" }}>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: 40, rowGap: 80 }}>
            {window.PROJECTS.map((p, i) => (
              <div key={p.slug} className="vb-tile" onClick={() => setPage({ name: "project", slug: p.slug })}
                style={{ paddingTop: i % 2 === 1 ? 100 : 0 }}>
                <window.Placeholder slug={p.slug} ratio={i % 3 === 0 ? "4/5" : i % 3 === 1 ? "4/3" : "3/4"} label={p.name} dark />
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", marginTop: 18 }}>
                  <div>
                    <div className="vb-h3">{p.name}</div>
                    <div className="vb-meta" style={{ marginTop: 6 }}>{p.location} · {p.category[lang]}</div>
                  </div>
                  <div className="vb-meta">{p.year}</div>
                </div>
              </div>
            ))}
          </div>
        </section>
      ) : (
        <section style={{ padding: "40px 80px 0" }}>
          <div className="vb-rule" />
          {window.PROJECTS.map((p, i) => (
            <a key={p.slug} className="vb-tile vb-list-row" onClick={() => setPage({ name: "project", slug: p.slug })}
              style={{ display: "grid", gridTemplateColumns: "60px 2fr 1fr 1fr 80px", gap: 24, alignItems: "center",
                padding: "20px 0", borderBottom: `1px solid ${B_PALETTE.rule}`, transition: "background .25s" }}>
              <div className="vb-meta">{String(i + 1).padStart(2, "0")}</div>
              <div style={{ fontFamily: "var(--display)", fontSize: "clamp(22px, 2vw, 32px)", letterSpacing: "-0.02em" }}>{p.name}</div>
              <div className="vb-meta">{p.location}</div>
              <div className="vb-meta">{p.category[lang]}</div>
              <div className="vb-meta" style={{ textAlign: "right" }}>{p.year}</div>
            </a>
          ))}
        </section>
      )}

      <BFooter t={t} setPage={setPage} lang={lang} />
    </div>
  );
}

function BProject({ slug, setPage, t, lang }) {
  const idx = window.PROJECTS.findIndex(p => p.slug === slug);
  const p = window.PROJECTS[idx];
  if (!p) return null;
  const next = window.PROJECTS[(idx + 1) % window.PROJECTS.length];

  return (
    <div className="vb-anim">
      <section style={{ padding: "60px 80px 40px" }}>
        <a className="vb-meta" style={{ cursor: "pointer" }} onClick={() => setPage({ name: "projects" })}>← {t.sections.index}</a>
      </section>

      {/* full bleed hero */}
      <section className="vb-tile">
        <window.Placeholder slug={p.slug} ratio="16/9" label={`${p.name} · 01`} scale={1.4} dark />
      </section>

      <section style={{ padding: "60px 80px 40px" }}>
        <div className="vb-eyebrow" style={{ marginBottom: 20 }}>{p.category[lang]} · {p.location} · {p.year}</div>
        <h1 className="vb-h1" style={{ fontSize: "clamp(48px, 7vw, 120px)" }}>{p.name}</h1>
      </section>

      <section style={{ padding: "40px 80px 80px" }}>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 2fr", gap: 80 }}>
          <div>
            <div className="vb-meta" style={{ marginBottom: 24 }}>{t.sections.info}</div>
            {[
              [t.sections.year, p.year],
              [t.sections.location, p.location],
              [t.sections.category, p.category[lang]],
              [t.sections.area, p.area],
              [t.sections.client, p.client],
              [t.sections.program, p.program[lang]],
            ].map(([k, v], i) => (
              <div key={i} style={{ display: "flex", padding: "14px 0", borderTop: `1px solid ${B_PALETTE.rule}` }}>
                <span className="vb-meta" style={{ flex: "0 0 45%" }}>{k}</span>
                <span style={{ fontSize: 14, letterSpacing: "-0.005em" }}>{v}</span>
              </div>
            ))}
          </div>
          <div>
            <p className="vb-lede" style={{ marginBottom: 32 }}>
              {lang === "tr" ? <>"Mekânın kendi malzemesini, kendi ışığını bulmasına izin verdik."</> : <>"We let the space find its own material, its own light."</>}
            </p>
            <p className="vb-body" style={{ fontSize: 17 }}>
              {lang === "tr"
                ? `${p.name}, ${p.location}'da konumlanan bir ${p.category.tr.toLowerCase()} projesi. Program: ${p.program.tr}. Tasarım, malzeme paletinin yere ve programın doğasına ait kılınmasıyla şekillendi.`
                : `${p.name} is a ${p.category.en.toLowerCase()} project located in ${p.location}. The brief — ${p.program.en.toLowerCase()} — was approached by grounding the material palette in place and programme.`}
            </p>
          </div>
        </div>
      </section>

      <section style={{ padding: "0 80px 40px" }}>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 40 }}>
          <window.Placeholder slug={p.slug} ratio="3/4" label={`${p.name} · 02`} idx={2} dark />
          <window.Placeholder slug={p.slug} ratio="3/4" label={`${p.name} · 03`} idx={3} dark />
        </div>
      </section>

      <section>
        <window.Placeholder slug={p.slug} ratio="16/8" label={`${p.name} · 04`} idx={4} scale={1.3} dark />
      </section>

      <section style={{ padding: "60px 80px 40px" }}>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 2fr", gap: 40 }}>
          <window.Placeholder slug={p.slug} ratio="3/4" label={`${p.name} · 05`} idx={5} dark />
          <window.Placeholder slug={p.slug} ratio="4/3" label={`${p.name} · 06`} idx={6} dark />
        </div>
      </section>

      {/* next */}
      <section className="vb-tile" onClick={() => setPage({ name: "project", slug: next.slug })} style={{ marginTop: 80, position: "relative" }}>
        <window.Placeholder slug={next.slug} ratio="16/8" label="" scale={1.3} dark />
        <div style={{ position: "absolute", inset: 0, display: "flex", flexDirection: "column", justifyContent: "center", alignItems: "center", textAlign: "center", padding: 40 }}>
          <div className="vb-meta" style={{ marginBottom: 24, color: B_PALETTE.ink }}>{t.sections.next} →</div>
          <div style={{ fontFamily: "var(--display)", fontSize: "clamp(48px, 7vw, 120px)", letterSpacing: "-0.04em", lineHeight: 0.95 }}>
            {next.name}
          </div>
          <div className="vb-meta" style={{ marginTop: 16, color: B_PALETTE.ink }}>{next.location} · {next.year}</div>
        </div>
      </section>

      <BFooter t={t} setPage={setPage} lang={lang} />
    </div>
  );
}

function BAbout({ setPage, t, lang }) {
  return (
    <div className="vb-anim">
      <section style={{ padding: "80px 80px 60px" }}>
        <div className="vb-eyebrow" style={{ marginBottom: 28 }}>{t.sections.studio} / Est. 2017</div>
        <h1 className="vb-h1">
          {lang === "tr" ? <>Mekân,<br /><em>kullanıldığında</em><br />değer kazanır.</> : <>Space gains<br /><em>its value</em><br />in use.</>}
        </h1>
      </section>

      <section>
        <window.Placeholder slug="studio-b" ratio="16/8" label={lang === "tr" ? "Stüdyo · Çankaya" : "Studio · Çankaya"} scale={1.3} dark />
      </section>

      <section style={{ padding: "100px 80px 80px" }}>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 2fr", gap: 80 }}>
          <div>
            <div className="vb-meta" style={{ marginBottom: 24 }}>{t.about.title}</div>
            <div style={{ display: "grid", gap: 20 }}>
              {t.about.facts.map(([k, v], i) => (
                <div key={i} style={{ paddingTop: 16, borderTop: `1px solid ${B_PALETTE.rule}` }}>
                  <div className="vb-meta" style={{ marginBottom: 8 }}>{k}</div>
                  <div style={{ fontSize: 22, letterSpacing: "-0.015em" }}>{v}</div>
                </div>
              ))}
            </div>
          </div>
          <div>
            {t.about.paras.map((para, i) => (
              <p key={i} className={i === 0 ? "vb-lede" : "vb-body"}
                style={{ marginTop: i === 0 ? 0 : 24, fontSize: i === 0 ? undefined : 18, maxWidth: i === 0 ? "32ch" : "60ch", color: i === 0 ? B_PALETTE.ink : B_PALETTE.mid, fontStyle: i === 0 ? "italic" : "normal", fontFamily: i === 0 ? "var(--serif)" : "var(--display)" }}>
                {para}
              </p>
            ))}
          </div>
        </div>
      </section>

      <section style={{ padding: "40px 80px 80px" }}>
        <div className="vb-meta" style={{ marginBottom: 28 }}>{t.sections.services}</div>
        <div className="vb-rule" />
        {t.services.map((s, i) => (
          <div key={i} style={{ display: "grid", gridTemplateColumns: "60px 1fr 2fr", gap: 32, padding: "32px 0", borderBottom: `1px solid ${B_PALETTE.rule}`, alignItems: "baseline" }}>
            <div className="vb-meta">0{i + 1}</div>
            <h3 className="vb-h2" style={{ fontSize: "clamp(26px, 2.8vw, 40px)" }}>{s.t}</h3>
            <p className="vb-body" style={{ fontSize: 16 }}>{s.d}</p>
          </div>
        ))}
      </section>

      <BFooter t={t} setPage={setPage} lang={lang} />
    </div>
  );
}

function BContact({ setPage, t, lang }) {
  const [sent, setSent] = React.useState(false);
  return (
    <div className="vb-anim">
      <section style={{ padding: "80px 80px 60px" }}>
        <div className="vb-eyebrow" style={{ marginBottom: 28 }}>{t.contact.title}</div>
        <h1 className="vb-h1">
          {lang === "tr"
            ? <>Bir <em>mekân</em>,<br />bir <em>konuşma</em>.</>
            : <>A <em>space</em>,<br />a <em>conversation</em>.</>}
        </h1>
      </section>

      <section style={{ padding: "20px 80px 80px" }}>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1.4fr", gap: 80 }}>
          <div>
            {[
              [t.contact.labels.address, window.CONTACT.address],
              [t.contact.labels.phone, window.CONTACT.phone],
              [t.contact.labels.email, window.CONTACT.email],
              [t.contact.labels.instagram, window.CONTACT.instagram],
              [t.contact.labels.hours, t.contact.hours],
            ].map(([k, v], i) => (
              <div key={i} style={{ paddingTop: 18, paddingBottom: 18, borderTop: `1px solid ${B_PALETTE.rule}` }}>
                <div className="vb-meta" style={{ marginBottom: 8 }}>{k}</div>
                <div style={{ fontSize: 18, letterSpacing: "-0.01em" }}>
                  {k === t.contact.labels.email
                    ? <a href={`mailto:${v}`} style={{ color: B_PALETTE.accent }}>{v}</a>
                    : v}
                </div>
              </div>
            ))}
          </div>
          <div>
            {sent ? (
              <div className="vb-lede" style={{ color: B_PALETTE.ink, fontStyle: "italic" }}>{t.contact.form.thanks}</div>
            ) : (
              <form onSubmit={(e) => { e.preventDefault(); setSent(true); }} style={{ display: "grid", gap: 28 }}>
                {["name", "email", "subject"].map(k => (
                  <div key={k}>
                    <label className="vb-meta" style={{ display: "block", marginBottom: 8 }}>{t.contact.form[k]}</label>
                    <input required type={k === "email" ? "email" : "text"}
                      style={{ width: "100%", background: "none", border: "none", borderBottom: `1px solid ${B_PALETTE.rule}`, padding: "10px 0", fontSize: 18, fontFamily: "inherit", color: B_PALETTE.ink, outline: "none" }} />
                  </div>
                ))}
                <div>
                  <label className="vb-meta" style={{ display: "block", marginBottom: 8 }}>{t.contact.form.message}</label>
                  <textarea required rows="4"
                    style={{ width: "100%", background: "none", border: "none", borderBottom: `1px solid ${B_PALETTE.rule}`, padding: "10px 0", fontSize: 18, fontFamily: "inherit", color: B_PALETTE.ink, outline: "none", resize: "vertical" }} />
                </div>
                <button type="submit" className="vb-cta" style={{ justifySelf: "flex-start", marginTop: 12 }}>
                  {t.contact.form.send} <span className="arr">→</span>
                </button>
              </form>
            )}
          </div>
        </div>
      </section>

      <section>
        <window.Placeholder slug="map-b" ratio="16/5" label="Kuzu Effect AVM · Oran · Çankaya" dark />
      </section>

      <BFooter t={t} setPage={setPage} lang={lang} />
    </div>
  );
}

function BFooter({ t, setPage, lang }) {
  return (
    <footer style={{ padding: "120px 80px 40px", background: B_PALETTE.bg2 }}>
      <h2 className="vb-h2" style={{ marginBottom: 60, maxWidth: "16ch" }}>
        {lang === "tr"
          ? <>Bir sonraki <em style={{ fontStyle: "italic", fontFamily: "var(--serif)", color: B_PALETTE.accent }}>iş</em><br />birlikte.</>
          : <>The next <em style={{ fontStyle: "italic", fontFamily: "var(--serif)", color: B_PALETTE.accent }}>project</em>,<br />together.</>}
      </h2>
      <a className="vb-cta" onClick={() => setPage({ name: "contact" })}>
        {t.contact.title} <span className="arr">→</span>
      </a>
      <div style={{ marginTop: 80, paddingTop: 32, borderTop: `1px solid ${B_PALETTE.rule}`, display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 24 }}>
        <div>
          <div className="vb-meta" style={{ marginBottom: 8 }}>{t.contact.labels.email}</div>
          <div>{window.CONTACT.email}</div>
        </div>
        <div>
          <div className="vb-meta" style={{ marginBottom: 8 }}>{t.contact.labels.phone}</div>
          <div>{window.CONTACT.phone}</div>
        </div>
        <div>
          <div className="vb-meta" style={{ marginBottom: 8 }}>{t.contact.labels.instagram}</div>
          <div>{window.CONTACT.instagram}</div>
        </div>
        <div>
          <div className="vb-meta" style={{ marginBottom: 8 }}>{t.contact.labels.address}</div>
          <div style={{ fontSize: 14, lineHeight: 1.5 }}>{window.CONTACT.address}</div>
        </div>
      </div>
      <div style={{ marginTop: 24, display: "flex", justifyContent: "space-between", color: B_PALETTE.mid, fontFamily: "var(--mono)", fontSize: 11, letterSpacing: "0.14em", textTransform: "uppercase" }}>
        <div>{t.footer.colophon}</div>
        <div>{window.CONTACT.domain}</div>
      </div>
    </footer>
  );
}

function VariationB(props) {
  const { page, ...rest } = props;
  return (
    <BLayout {...props}>
      {page.name === "index" && <BHome {...rest} setPage={props.setPage} />}
      {page.name === "projects" && <BProjects {...rest} setPage={props.setPage} />}
      {page.name === "project" && <BProject slug={page.slug} {...rest} setPage={props.setPage} />}
      {page.name === "about" && <BAbout {...rest} setPage={props.setPage} />}
      {page.name === "contact" && <BContact {...rest} setPage={props.setPage} />}
    </BLayout>
  );
}

window.VariationB = VariationB;
