/* eslint-disable */
// Variation A — Editorial Gallery
// Warm cream + stone. Big editorial display sans. Lots of whitespace.
// Generous index grid. Hover-zoom on imagery.

const A_PALETTES = {
  "cool-brown": {
    bg: "#342626",
    bg2: "#2a1e1e",
    paper: "#3d2e2e",
    ink: "#c7d2dd",
    mid: "#8a94a0",
    rule: "rgba(199,210,221,0.18)",
    accent: "#c7d2dd",
    footerInk: "#c7d2dd",
    footerMid: "rgba(199,210,221,0.55)",
    footerRule: "rgba(199,210,221,0.18)",
    wordmark: "assets/wordmark-sky.png",
    placeholders: [
      ["#c7d2dd", "#5a4646"], ["#dbe2eb", "#342626"], ["#a8b6c4", "#1c1414"],
      ["#e4ebf1", "#473535"], ["#b8c5d1", "#342626"], ["#9aaab9", "#2a1e1e"],
      ["#cdd6df", "#3f2e2e"], ["#c7d2dd", "#2a1e1e"],
    ],
  },
  "ocean": {
    bg: "#e0e6ea",
    bg2: "#22282c",
    paper: "#ffffff",
    ink: "#22282c",
    mid: "#929fa7",
    rule: "rgba(34,40,44,0.15)",
    accent: "#22282c",
    footerInk: "#e0e6ea",
    footerMid: "rgba(224,230,234,0.62)",
    footerRule: "rgba(224,230,234,0.20)",
    wordmark: "assets/wordmark-midnight.png",
    // Blue-led placeholders with Earth as warm complement
    placeholders: [
      ["#929fa7", "#22282c"],  // ocean → midnight
      ["#c4ced5", "#22282c"],  // pale ocean → midnight
      ["#e0e6ea", "#929fa7"],  // dust → ocean
      ["#7c8a93", "#22282c"],  // deep ocean
      ["#b3bfc6", "#22282c"],  // mid ocean
      ["#e9e7e1", "#929fa7"],  // earth → ocean (warm break)
      ["#929fa7", "#3a4248"],  // ocean → soft midnight
      ["#c4ced5", "#22282c"],
    ],
  },
  "stone": {
    bg: "#e0d8d0",
    bg2: "#38383c",
    paper: "#ece5dd",
    ink: "#38383c",
    mid: "#57646c",
    rule: "rgba(56,56,60,0.18)",
    accent: "#57646c",
    footerInk: "#e0d8d0",
    footerMid: "rgba(224,216,208,0.60)",
    footerRule: "rgba(224,216,208,0.20)",
    wordmark: "assets/wordmark-charcoal.png",
    // Coastal mineral placeholders — slate, taupe, stone
    placeholders: [
      ["#57646c", "#38383c"],  // slate → charcoal
      ["#7f878a", "#38383c"],  // grey → charcoal
      ["#b3aba1", "#57646c"],  // taupe → slate
      ["#e0d8d0", "#57646c"],  // stone → slate
      ["#57646c", "#7f878a"],  // slate gradient
      ["#b3aba1", "#38383c"],  // taupe → charcoal
      ["#7f878a", "#b3aba1"],  // grey → taupe
      ["#9aa3a8", "#38383c"],  // mid slate → charcoal
    ],
  },
};

let A_PALETTE = A_PALETTES["cool-brown"];

const A_FONTS = `
@import url('https://fonts.googleapis.com/css2?family=Instrument+Serif:ital@0;1&family=Instrument+Sans:ital,wght@0,400..700;1,400..700&family=JetBrains+Mono:wght@300;400;500&display=swap');
:root {
  --display: "Instrument Sans", system-ui, sans-serif;
  --serif: "Instrument Serif", Georgia, serif;
  --mono: "JetBrains Mono", ui-monospace, monospace;
}
`;

function ALayout({ children, page, setPage, lang, setLang, t }) {
  const links = [
    ["index", t.nav.index],
    ["projects", t.nav.projects],
    ["shop", t.nav.shop],
    ["playlist", t.nav.playlist],
    ["journal", t.nav.journal],
    ["about", t.nav.about],
    ["contact", t.nav.contact],
  ];
  const [mobileOpen, setMobileOpen] = React.useState(false);
  // Close drawer when route changes
  React.useEffect(() => { setMobileOpen(false); }, [page.name, page.slug]);
  React.useEffect(() => {
    // Lock body scroll when drawer open
    document.body.style.overflow = mobileOpen ? "hidden" : "";
    return () => { document.body.style.overflow = ""; };
  }, [mobileOpen]);
  return (
    <div className="va-root">
      <style>{A_FONTS}{`
        .va-root { background: ${A_PALETTE.bg}; color: ${A_PALETTE.ink}; font-family: var(--display); font-feature-settings: "ss01","ss02"; min-height: 100vh; }
        .va-root a { color: inherit; text-decoration: none; }
        .va-nav { position: sticky; top: 0; z-index: 30; backdrop-filter: blur(8px); background: ${A_PALETTE.bg}cc; border-bottom: 1px solid ${A_PALETTE.rule}; }
        .va-nav-inner { max-width: 1680px; margin: 0 auto; padding: 22px 40px; display: flex; align-items: center; gap: 32px; }
        .va-mark { display: flex; align-items: center; gap: 18px; cursor: pointer; }
        .va-mark img { height: 52px; display: block; }
        .va-mark-meta { font-family: var(--mono); font-size: 10px; line-height: 1.3; letter-spacing: 0.1em; text-transform: uppercase; color: ${A_PALETTE.mid}; border-left: 1px solid ${A_PALETTE.rule}; padding-left: 16px; }
        .va-links { display: flex; gap: 28px; margin-left: auto; }
        .va-link { font-size: 14px; letter-spacing: -0.005em; padding: 6px 0; position: relative; cursor: pointer; color: ${A_PALETTE.mid}; transition: color .25s; }
        .va-link[data-active="true"] { color: ${A_PALETTE.ink}; }
        .va-link:hover { color: ${A_PALETTE.ink}; }
        .va-link[data-active="true"]::after { content: ""; position: absolute; left: 0; right: 0; bottom: -2px; height: 1px; background: ${A_PALETTE.ink}; }
        .va-lang { display: flex; gap: 4px; font-family: var(--mono); font-size: 11px; letter-spacing: 0.08em; }
        .va-lang button { background: none; border: 1px solid ${A_PALETTE.rule}; padding: 6px 10px; cursor: pointer; color: ${A_PALETTE.mid}; font: inherit; letter-spacing: inherit; }
        .va-lang button[data-active="true"] { background: ${A_PALETTE.ink}; color: ${A_PALETTE.bg}; border-color: ${A_PALETTE.ink}; }
        .va-container { max-width: 1680px; margin: 0 auto; padding: 0 40px; }
        .va-eyebrow { font-family: var(--mono); font-size: 11px; letter-spacing: 0.14em; text-transform: uppercase; color: ${A_PALETTE.mid}; }
        .va-h1 { font-family: var(--display); font-weight: 400; font-size: clamp(56px, 9.5vw, 168px); line-height: 0.92; letter-spacing: -0.04em; }
        .va-h1 em { font-family: var(--serif); font-style: italic; font-weight: 400; }
        .va-h2 { font-family: var(--display); font-weight: 400; font-size: clamp(36px, 4.5vw, 72px); line-height: 1.02; letter-spacing: -0.03em; }
        .va-h2 em { font-family: var(--serif); font-style: italic; }
        .va-h3 { font-family: var(--display); font-weight: 500; font-size: clamp(22px, 1.8vw, 30px); line-height: 1.18; letter-spacing: -0.02em; }
        .va-lede { font-family: var(--serif); font-size: clamp(20px, 1.6vw, 26px); line-height: 1.42; letter-spacing: -0.005em; color: ${A_PALETTE.ink}; max-width: 60ch; }
        .va-body { font-size: 16px; line-height: 1.55; color: ${A_PALETTE.mid}; max-width: 60ch; }
        .va-rule { height: 1px; background: ${A_PALETTE.rule}; }
        .va-meta { font-family: var(--mono); font-size: 11px; letter-spacing: 0.12em; text-transform: uppercase; color: ${A_PALETTE.mid}; }
        .va-tile { cursor: pointer; }
        .va-tile-img-wrap { position: relative; overflow: hidden; }
        .va-tile .ph-img { position: relative; overflow: hidden; }
        .va-tile .ph-img > div:first-of-type { transition: transform 1.6s cubic-bezier(.2,.7,.1,1), filter 0.8s cubic-bezier(.2,.7,.1,1); }
        .va-tile:hover .ph-img > div:first-of-type { transform: scale(1.08); filter: brightness(0.78) saturate(1.05); }

        /* Overlay info panel — slides up from bottom on hover */
        .va-tile-overlay {
          position: absolute; left: 0; right: 0; bottom: 0;
          padding: 24px 22px 22px;
          color: #f5efe2;
          background: linear-gradient(to top, rgba(20,15,12,0.88) 0%, rgba(20,15,12,0.55) 65%, rgba(20,15,12,0) 100%);
          transform: translateY(40%);
          opacity: 0;
          transition: transform 0.7s cubic-bezier(.2,.7,.1,1), opacity 0.5s cubic-bezier(.2,.7,.1,1);
          pointer-events: none;
        }
        .va-tile:hover .va-tile-overlay { transform: translateY(0); opacity: 1; }
        .va-tile-overlay .ov-num { font-family: var(--mono); font-size: 10px; letter-spacing: 0.18em; opacity: 0.6; }
        .va-tile-overlay .ov-name { font-family: var(--display); font-size: clamp(20px, 2.2vw, 32px); letter-spacing: -0.02em; margin-top: 6px; line-height: 1.05; }
        .va-tile-overlay .ov-name em { font-family: var(--serif); font-style: italic; font-weight: 400; }
        .va-tile-overlay .ov-meta {
          margin-top: 12px; display: flex; gap: 18px; flex-wrap: wrap;
          font-family: var(--mono); font-size: 10px; letter-spacing: 0.12em; text-transform: uppercase;
          opacity: 0.75;
        }
        .va-tile-overlay .ov-cta {
          margin-top: 14px; display: inline-flex; align-items: center; gap: 8px;
          font-family: var(--mono); font-size: 10px; letter-spacing: 0.18em; text-transform: uppercase;
          padding-bottom: 2px; border-bottom: 1px solid rgba(245,239,226,0.5);
          transition: border-color .25s, gap .25s;
        }
        .va-tile:hover .va-tile-overlay .ov-cta { gap: 14px; border-bottom-color: #f5efe2; }

        /* Corner index marker — appears on hover */
        .va-tile-corner {
          position: absolute; top: 14px; left: 14px;
          padding: 5px 9px;
          background: rgba(20,15,12,0.78);
          color: #f5efe2;
          font-family: var(--mono); font-size: 10px; letter-spacing: 0.14em;
          opacity: 0;
          transform: translateY(-6px);
          transition: opacity 0.4s ease, transform 0.4s cubic-bezier(.2,.7,.1,1);
          pointer-events: none;
        }
        .va-tile:hover .va-tile-corner { opacity: 1; transform: translateY(0); transition-delay: 0.1s; }

        /* Below-tile meta still visible — but on hover it becomes lighter (overlay dominates) */
        .va-tile-meta { display: flex; justify-content: space-between; align-items: baseline; margin-top: 14px; font-family: var(--mono); font-size: 11px; letter-spacing: 0.12em; text-transform: uppercase; color: ${A_PALETTE.mid}; transition: opacity .35s; }
        .va-tile:hover .va-tile-meta { opacity: 0.7; }
        .va-tile-meta .name { font-family: var(--display); font-size: 17px; letter-spacing: -0.005em; text-transform: none; color: ${A_PALETTE.ink}; font-weight: 500; }
        .va-footer { background: ${A_PALETTE.bg2}; color: ${A_PALETTE.footerInk || A_PALETTE.bg}; margin-top: 120px; padding: 80px 0 40px; }
        .va-footer a { color: inherit; }
        .va-footer .va-rule { background: ${A_PALETTE.footerRule || "rgba(255,255,255,0.18)"}; }
        .va-footer .va-meta { color: ${A_PALETTE.footerMid || "rgba(255,255,255,0.55)"}; }
        .va-foot-h { font-family: var(--display); font-weight: 400; font-size: clamp(48px, 6vw, 96px); line-height: 0.95; letter-spacing: -0.035em; }
        .va-anim { /* fade animation removed — caused issues in hidden iframes */ }
        .va-pill { display: inline-flex; align-items: center; gap: 8px; border: 1px solid ${A_PALETTE.ink}; padding: 14px 20px; border-radius: 999px; font-size: 14px; cursor: pointer; transition: all .25s; }
        .va-pill:hover { background: ${A_PALETTE.ink}; color: ${A_PALETTE.bg}; }
        .va-pill .arr { transition: transform .25s; }
        .va-pill:hover .arr { transform: translateX(4px); }

        /* === Mobile burger menu === */
        .va-burger { display: none; background: none; border: none; width: 40px; height: 40px; cursor: pointer; padding: 0; align-items: center; justify-content: center; flex-direction: column; gap: 6px; margin-left: auto; }
        .va-burger span { display: block; width: 22px; height: 1.6px; background: ${A_PALETTE.ink}; transition: transform .3s, opacity .3s; }
        .va-burger[data-open="true"] span:nth-child(1) { transform: translateY(7.6px) rotate(45deg); }
        .va-burger[data-open="true"] span:nth-child(2) { opacity: 0; }
        .va-burger[data-open="true"] span:nth-child(3) { transform: translateY(-7.6px) rotate(-45deg); }
        .va-mobile-drawer { position: fixed; inset: 64px 0 0 0; z-index: 25; background: ${A_PALETTE.bg}; padding: 28px 24px 48px; display: none; flex-direction: column; gap: 0; overflow-y: auto; transform: translateY(-100%); transition: transform .4s cubic-bezier(.2,.7,.1,1); }
        .va-search-btn { background: none; border: 1px solid ${A_PALETTE.rule}; padding: 6px 10px 6px 12px; cursor: pointer; display: inline-flex; align-items: center; gap: 8px; font-family: var(--mono); font-size: 11px; letter-spacing: 0.1em; color: ${A_PALETTE.mid}; border-radius: 999px; transition: border-color .2s, color .2s; }
        .va-search-btn:hover { border-color: ${A_PALETTE.ink}; color: ${A_PALETTE.ink}; }
        .va-search-btn .kbd { padding: 2px 6px; background: ${A_PALETTE.paper}; border: 1px solid ${A_PALETTE.rule}; border-radius: 4px; font-size: 9px; letter-spacing: 0.05em; }
        .va-mobile-drawer[data-open="true"] { transform: translateY(0); }
        .va-mobile-drawer a { display: flex; justify-content: space-between; align-items: baseline; padding: 18px 0; border-bottom: 1px solid ${A_PALETTE.rule}; font-family: var(--display); font-size: 28px; letter-spacing: -0.02em; }
        .va-mobile-drawer a sup { font-family: var(--mono); font-size: 11px; letter-spacing: 0.12em; color: ${A_PALETTE.mid}; }
        .va-mobile-drawer .meta-row { display: flex; justify-content: space-between; margin-top: 32px; font-family: var(--mono); font-size: 11px; letter-spacing: 0.12em; text-transform: uppercase; color: ${A_PALETTE.mid}; }

        /* === Responsive breakpoints === */
        @media (max-width: 980px) {
          .va-nav-inner { padding: 14px 20px; }
          .va-mark img { height: 38px; }
          .va-mark-meta { display: none; }
          .va-links { display: none; }
          .va-lang { display: none; }
          .va-burger { display: flex; }
          .va-mobile-drawer { display: flex; }
          .va-container { padding: 0 20px; }
        }
        @media (max-width: 760px) {
          .va-h1 { font-size: clamp(40px, 12vw, 80px); }
          .va-h2 { font-size: clamp(28px, 7vw, 48px); }
          .va-h3 { font-size: 20px; }
          .va-lede { font-size: 18px; }
        }
        /* All grids → single column on mobile */
        @media (max-width: 760px) {
          .va-anim section > div[style*="gridTemplateColumns"],
          .va-anim section > div > div[style*="gridTemplateColumns"] {
            grid-template-columns: 1fr !important;
            gap: 32px !important;
          }
        }
      `}</style>

      <nav className="va-nav">
        <div className="va-nav-inner">
          <a className="va-mark" onClick={() => setPage({ name: "index" })}>
            <img src={A_PALETTE.wordmark} alt="Line Interiors" />
            <div className="va-mark-meta">
              Design Studio<br />Ankara · 2017
            </div>
          </a>
          <div className="va-links">
            {links.map(([k, label]) => (
              <a key={k} className="va-link" data-active={page.name === k || (k === "projects" && page.name === "project")} onClick={() => setPage({ name: k })}>
                {label}
              </a>
            ))}
          </div>
          <div className="va-lang">
            <button data-active={lang === "en"} onClick={() => setLang("en")}>EN</button>
            <button data-active={lang === "tr"} onClick={() => setLang("tr")}>TR</button>
            <button className="va-search-btn" onClick={() => window.dispatchEvent(new CustomEvent("va-open-search"))}
              aria-label={lang === "tr" ? "Ara" : "Search"} title={lang === "tr" ? "Ara (⌘K)" : "Search (⌘K)"}
              style={{ marginLeft: 4 }}>
              <span>{lang === "tr" ? "Ara" : "Search"}</span>
              <span className="kbd">⌘K</span>
            </button>
          </div>
          <button className="va-burger" data-open={mobileOpen}
            aria-label={lang === "tr" ? "Menü" : "Menu"}
            onClick={() => setMobileOpen(o => !o)}>
            <span /><span /><span />
          </button>
        </div>
        <div className="va-mobile-drawer" data-open={mobileOpen}>
          {links.map(([k, label], i) => (
            <a key={k} onClick={() => setPage({ name: k })}
              data-active={page.name === k || (k === "projects" && page.name === "project")}>
              <span style={{
                fontFamily: page.name === k || (k === "projects" && page.name === "project") ? "var(--serif)" : "var(--display)",
                fontStyle: page.name === k || (k === "projects" && page.name === "project") ? "italic" : "normal",
              }}>{label}</span>
              <sup>0{i + 1}</sup>
            </a>
          ))}
          <div className="meta-row">
            <div>
              <button onClick={() => setLang("tr")} style={{
                background: "none", border: "none", padding: 0,
                fontFamily: "inherit", fontSize: "inherit", letterSpacing: "inherit",
                color: lang === "tr" ? A_PALETTE.ink : A_PALETTE.mid, cursor: "pointer",
                textDecoration: lang === "tr" ? "underline" : "none",
              }}>TR</button>
              {" · "}
              <button onClick={() => setLang("en")} style={{
                background: "none", border: "none", padding: 0,
                fontFamily: "inherit", fontSize: "inherit", letterSpacing: "inherit",
                color: lang === "en" ? A_PALETTE.ink : A_PALETTE.mid, cursor: "pointer",
                textDecoration: lang === "en" ? "underline" : "none",
              }}>EN</button>
            </div>
            <a href={`mailto:${window.CONTACT.email}`}>{window.CONTACT.email}</a>
          </div>
        </div>
      </nav>

      {children}
    </div>
  );
}

function AHome({ setPage, t, lang }) {
  const featured = ["kayakapi-hotel", "an-headquarter", "line-roastery", "sur-balik-ankara", "if-sokak-tunus", "kei"];
  const featuredProjects = featured.map(s => window.PROJECTS.find(p => p.slug === s));

  // Scroll-driven hero transforms
  const heroRef = React.useRef(null);
  const [scrollY, setScrollY] = React.useState(0);
  React.useEffect(() => {
    let raf;
    const onScroll = () => {
      if (raf) return;
      raf = requestAnimationFrame(() => { setScrollY(window.scrollY); raf = null; });
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => { window.removeEventListener("scroll", onScroll); if (raf) cancelAnimationFrame(raf); };
  }, []);
  // Up to ~600px scroll, title slowly drifts up + fades
  const heroProgress = Math.min(1, scrollY / 600);
  const titleY = -scrollY * 0.25;       // slower than scroll → parallax up
  const eyebrowY = -scrollY * 0.45;     // faster
  const ledeY = -scrollY * 0.12;        // slower for depth
  const imageY = -scrollY * 0.08;       // very subtle on featured image
  const titleScale = 1 + heroProgress * 0.04;  // slight zoom feel

  return (
    <div className="va-anim">
      {window.ScrollProgress && <window.ScrollProgress color={A_PALETTE.ink} height={2} />}

      {/* === HERO — dramatic, parallax === */}
      <section ref={heroRef} className="va-container va-hero" style={{
        padding: "120px 40px 80px",
        position: "relative",
        minHeight: "92vh",
        display: "flex",
        flexDirection: "column",
        justifyContent: "center",
      }}>
        <div style={{ transform: `translate3d(0, ${eyebrowY}px, 0)`, opacity: Math.max(0, 1 - heroProgress * 1.4) }}>
          {window.SplitTextReveal ? (
            <window.SplitTextReveal tag="div" duration={700} stagger={40} style={{ display: "block" }}>
              <div className="va-eyebrow va-hero-eyebrow">{t.hero.eyebrow}</div>
            </window.SplitTextReveal>
          ) : (
            <div className="va-eyebrow va-hero-eyebrow">{t.hero.eyebrow}</div>
          )}
        </div>

        <div style={{
          transform: `translate3d(0, ${titleY}px, 0) scale(${titleScale})`,
          transformOrigin: "left center",
          opacity: Math.max(0, 1 - heroProgress * 0.9),
          marginTop: 32,
        }}>
          {window.SplitTextReveal ? (
            <h1 className="va-h1 va-hero-h1">
              <window.SplitTextReveal tag="span" duration={1100} stagger={110} delay={150} distance={60}>
                {t.hero.title[0]}
              </window.SplitTextReveal>
              <br />
              <em>
                <window.SplitTextReveal tag="span" duration={1100} stagger={110} delay={420} distance={60}>
                  {t.hero.title[1]}
                </window.SplitTextReveal>
              </em>
              <br />
              <window.SplitTextReveal tag="span" duration={1100} stagger={110} delay={690} distance={60}>
                {t.hero.title[2]}
              </window.SplitTextReveal>
            </h1>
          ) : (
            <h1 className="va-h1 va-hero-h1">
              {t.hero.title[0]}<br />
              <em>{t.hero.title[1]}</em><br />
              {t.hero.title[2]}
            </h1>
          )}
        </div>

        <div style={{
          display: "grid", gridTemplateColumns: "1.2fr 1fr", gap: 60,
          marginTop: 80, alignItems: "end",
          transform: `translate3d(0, ${ledeY}px, 0)`,
          opacity: Math.max(0, 1 - heroProgress * 1.6),
        }}>
          {window.ScrollReveal ? (
            <window.ScrollReveal delay={1100} direction="up" duration={1000}>
              <p className="va-lede">{t.hero.lede}</p>
            </window.ScrollReveal>
          ) : (
            <p className="va-lede">{t.hero.lede}</p>
          )}
          <div style={{ display: "flex", justifyContent: "flex-end" }}>
            {window.ScrollReveal ? (
              <window.ScrollReveal delay={1300} direction="up" duration={900}>
                <a className="va-pill" onClick={() => setPage({ name: "projects" })}>
                  {t.hero.cta} <span className="arr">→</span>
                </a>
              </window.ScrollReveal>
            ) : (
              <a className="va-pill" onClick={() => setPage({ name: "projects" })}>
                {t.hero.cta} <span className="arr">→</span>
              </a>
            )}
          </div>
        </div>

        {/* Scroll hint */}
        <div style={{
          position: "absolute", bottom: 32, left: 40, right: 40,
          display: "flex", justifyContent: "space-between", alignItems: "center",
          opacity: Math.max(0, 1 - heroProgress * 2),
          pointerEvents: heroProgress > 0.4 ? "none" : "auto",
        }}>
          <div className="va-meta" style={{ fontSize: 10 }}>{lang === "tr" ? "↓ KAYDIRIN" : "↓ SCROLL"}</div>
          <div className="va-meta" style={{ fontSize: 10 }}>{lang === "tr" ? "33 PROJE · 2017—2026" : "33 PROJECTS · 2017—2026"}</div>
        </div>

        <style>{`
          .va-hero-h1 {
            font-size: clamp(72px, 13vw, 240px) !important;
            line-height: 0.86 !important;
            letter-spacing: -0.05em !important;
          }
          .va-hero-eyebrow {
            font-size: 13px !important;
            letter-spacing: 0.2em !important;
          }
          @media (max-width: 760px) {
            .va-hero-h1 { font-size: clamp(52px, 16vw, 110px) !important; }
            .va-hero-eyebrow { font-size: 11px !important; }
          }
        `}</style>
      </section>

      {/* Featured single hero image — with subtle parallax */}
      <section className="va-container" style={{ padding: "0 40px" }}>
        <div style={{ transform: `translate3d(0, ${imageY}px, 0)` }}>
          <div className="va-tile" onClick={() => setPage({ name: "project", slug: featuredProjects[0].slug })}>
            <div className="va-tile-img-wrap">
              <window.Placeholder slug={featuredProjects[0].slug} category={featuredProjects[0].category} ratio="16/8" label={"01 — Kayakapı Hotel · Kapadokya · 2022"} scale={1.4} withFigure={true} />
              <window.TileOverlay project={featuredProjects[0]} index={1} lang={lang} />
            </div>
          </div>
        </div>
      </section>

      {/* Manifesto */}
      <section className="va-container" style={{ padding: "120px 40px 100px" }}>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 2fr", gap: 80 }}>
          <div>
            <div className="va-meta">{t.manifesto.title} / 01</div>
            {window.BreathingFigure && (
              <window.BreathingFigure
                src={window.__figureSrc || "assets/figures-charcoal.png"}
                height={130}
                opacity={0.82}
                style={{ marginTop: 40 }}
              />
            )}
          </div>
          <div>
            <h2 className="va-h2" style={{ marginBottom: 40 }}>
              {lang === "tr"
                ? <>Tasarımı bir <em>ifade</em><br />değil bir <em>karşılık</em><br />olarak anlıyoruz.</>
                : <>We understand design<br />as a <em>response</em>,<br />not an <em>expression</em>.</>}
            </h2>
            <p className="va-body" style={{ fontSize: 17 }}>{t.manifesto.body}</p>
          </div>
        </div>
      </section>

      {/* Featured grid */}
      <section className="va-container" style={{ padding: "0 40px 40px" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", marginBottom: 32 }}>
          <h3 className="va-h3">{t.sections.featured}</h3>
          <a className="va-meta" style={{ cursor: "pointer" }} onClick={() => setPage({ name: "projects" })}>
            {t.sections.all} ({window.PROJECTS.length}) →
          </a>
        </div>
        <div className="va-rule" style={{ marginBottom: 32 }} />
        <div style={{ display: "grid", gridTemplateColumns: "repeat(6, 1fr)", gap: 32 }}>
          {/* irregular editorial layout */}
          <div style={{ gridColumn: "1 / span 3" }} className="va-tile" onClick={() => setPage({ name: "project", slug: featuredProjects[1].slug })}>
            <div className="va-tile-img-wrap"><window.Placeholder slug={featuredProjects[1].slug} category={featuredProjects[1].category} ratio="4/3" label={featuredProjects[1].name} /><window.TileOverlay project={featuredProjects[1]} index={2} lang={lang} /></div>
            <div className="va-tile-meta">
              <div>
                <div className="name">{featuredProjects[1].name}</div>
                <div style={{ marginTop: 4 }}>{featuredProjects[1].location}</div>
              </div>
              <div>{featuredProjects[1].year}</div>
            </div>
          </div>
          <div style={{ gridColumn: "4 / span 2", paddingTop: "12%" }} className="va-tile" onClick={() => setPage({ name: "project", slug: featuredProjects[2].slug })}>
            <div className="va-tile-img-wrap"><window.Placeholder slug={featuredProjects[2].slug} category={featuredProjects[2].category} ratio="3/4" label={featuredProjects[2].name} /><window.TileOverlay project={featuredProjects[2]} index={3} lang={lang} /></div>
            <div className="va-tile-meta">
              <div>
                <div className="name">{featuredProjects[2].name}</div>
                <div style={{ marginTop: 4 }}>{featuredProjects[2].location}</div>
              </div>
              <div>{featuredProjects[2].year}</div>
            </div>
          </div>
          <div style={{ gridColumn: "6 / span 1", paddingTop: "40%" }} className="va-tile" onClick={() => setPage({ name: "project", slug: featuredProjects[3].slug })}>
            <div className="va-tile-img-wrap"><window.Placeholder slug={featuredProjects[3].slug} category={featuredProjects[3].category} ratio="3/4" label={featuredProjects[3].name} /><window.TileOverlay project={featuredProjects[3]} index={4} lang={lang} /></div>
            <div className="va-tile-meta" style={{ flexDirection: "column", alignItems: "flex-start", gap: 2 }}>
              <div className="name" style={{ fontSize: 14 }}>{featuredProjects[3].name}</div>
              <div>{featuredProjects[3].year}</div>
            </div>
          </div>
          <div style={{ gridColumn: "1 / span 2", paddingTop: 40 }} className="va-tile" onClick={() => setPage({ name: "project", slug: featuredProjects[4].slug })}>
            <div className="va-tile-img-wrap"><window.Placeholder slug={featuredProjects[4].slug} category={featuredProjects[4].category} ratio="4/5" label={featuredProjects[4].name} /><window.TileOverlay project={featuredProjects[4]} index={5} lang={lang} /></div>
            <div className="va-tile-meta">
              <div>
                <div className="name">{featuredProjects[4].name}</div>
                <div style={{ marginTop: 4 }}>{featuredProjects[4].location}</div>
              </div>
              <div>{featuredProjects[4].year}</div>
            </div>
          </div>
          <div style={{ gridColumn: "3 / span 4", paddingTop: 40 }} className="va-tile" onClick={() => setPage({ name: "project", slug: featuredProjects[5].slug })}>
            <div className="va-tile-img-wrap"><window.Placeholder slug={featuredProjects[5].slug} category={featuredProjects[5].category} ratio="16/9" label={featuredProjects[5].name} /><window.TileOverlay project={featuredProjects[5]} index={6} lang={lang} /></div>
            <div className="va-tile-meta">
              <div>
                <div className="name">{featuredProjects[5].name}</div>
                <div style={{ marginTop: 4 }}>{featuredProjects[5].location}</div>
              </div>
              <div>{featuredProjects[5].year}</div>
            </div>
          </div>
        </div>
      </section>

      {/* === Marquee strip === */}
      <section style={{ overflow: "hidden", padding: "32px 0", borderTop: `1px solid ${A_PALETTE.rule}`, borderBottom: `1px solid ${A_PALETTE.rule}`, marginTop: 60 }}>
        <div style={{
          display: "flex", gap: 60, whiteSpace: "nowrap",
          animation: "va-marquee 60s linear infinite",
        }}>
          {[...t.marquee, ...t.marquee, ...t.marquee].map((m, i) => (
            <span key={i} style={{
              fontFamily: "var(--display)", fontSize: "clamp(28px, 4.5vw, 72px)",
              letterSpacing: "-0.03em", color: A_PALETTE.ink,
              display: "inline-flex", alignItems: "center", gap: 60,
            }}>
              {m}
              <span style={{ fontSize: "0.55em", color: A_PALETTE.mid, fontStyle: "italic", fontFamily: "var(--serif)" }}>✦</span>
            </span>
          ))}
        </div>
        <style>{`@keyframes va-marquee { from { transform: translateX(0); } to { transform: translateX(-33.333%); } }`}</style>
      </section>

      {/* Services strip */}
      <section className="va-container" style={{ padding: "140px 40px 100px" }}>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 2fr", gap: 80, marginBottom: 60 }}>
          <div className="va-meta">{t.sections.services} / 02</div>
          <h2 className="va-h2">
            {lang === "tr"
              ? <>Konseptten<br />son <em>detaya</em> kadar.</>
              : <>From concept<br />to the last <em>detail</em>.</>}
          </h2>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 32 }}>
          {t.services.map((s, i) => (
            <div key={i}>
              <div className="va-meta" style={{ marginBottom: 18 }}>0{i + 1}</div>
              <h3 className="va-h3" style={{ marginBottom: 12 }}>{s.t}</h3>
              <p className="va-body" style={{ fontSize: 14 }}>{s.d}</p>
            </div>
          ))}
        </div>
      </section>

      {/* === Team (homepage) === */}
      <section className="va-container" style={{ padding: "60px 40px 100px" }}>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 2fr", gap: 80, marginBottom: 40 }}>
          <div className="va-meta">{t.team.title} / 03</div>
          <h2 className="va-h2">
            {lang === "tr"
              ? <>Küçük bir ekip,<br />ölçek bağımsız<br /><em>aynı dikkatle.</em></>
              : <>A small team,<br />the same attention<br /><em>at any scale.</em></>}
          </h2>
        </div>
        <div className="va-rule" />
        {t.team.members.map((m, i) => (
          <div key={i} style={{
            display: "grid", gridTemplateColumns: "60px 1.6fr 2fr 0.8fr",
            gap: 24, padding: "22px 0", borderBottom: `1px solid ${A_PALETTE.rule}`,
            alignItems: "baseline",
          }}>
            <div className="va-meta">{String(i + 1).padStart(2, "0")}</div>
            <div style={{ fontFamily: "var(--display)", fontSize: "clamp(22px, 2.2vw, 32px)", letterSpacing: "-0.02em" }}>
              {m.name}
            </div>
            <div className="va-meta">{m.role}</div>
            <div className="va-meta" style={{ textAlign: "right" }}>{lang === "tr" ? "—" : "Since"} {m.since}</div>
          </div>
        ))}
      </section>

      {/* === Press & Awards (homepage) === */}
      <section className="va-container" style={{ padding: "20px 40px 120px" }}>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 2fr", gap: 80, marginBottom: 40 }}>
          <div className="va-meta">{t.press.title} / 04</div>
          <h2 className="va-h2">
            {lang === "tr"
              ? <>Stüdyo,<br />yazılı ve <em>sözlü</em>.</>
              : <>The studio,<br />in <em>print</em>.</>}
          </h2>
        </div>
        <div className="va-rule" />
        {t.press.items.map((p, i) => (
          <a key={i} href={p.url} target="_blank" rel="noreferrer"
            style={{ display: "block" }}
            onMouseEnter={(e) => e.currentTarget.style.background = A_PALETTE.paper}
            onMouseLeave={(e) => e.currentTarget.style.background = "transparent"}>
            <div style={{
              display: "grid", gridTemplateColumns: "60px 1.4fr 2.4fr 1fr 40px",
              gap: 24, padding: "22px 0", borderBottom: `1px solid ${A_PALETTE.rule}`,
              alignItems: "baseline", cursor: "pointer", transition: "background .2s",
            }}>
              <div className="va-meta">{String(i + 1).padStart(2, "0")}</div>
              <div style={{ fontFamily: "var(--serif)", fontStyle: "italic", fontSize: "clamp(20px, 1.9vw, 28px)", letterSpacing: "-0.01em" }}>
                {p.source}
              </div>
              <div style={{ fontFamily: "var(--display)", fontSize: 16, letterSpacing: "-0.005em", lineHeight: 1.4 }}>
                {p.title}
              </div>
              <div className="va-meta">{p.pub}</div>
              <div className="va-meta" style={{ textAlign: "right" }}>↗</div>
            </div>
          </a>
        ))}
      </section>

      <AFooter t={t} setPage={setPage} lang={lang} />
    </div>
  );
}

function AProjects({ setPage, t, lang }) {
  const [filter, setFilter] = React.useState("all");
  const cats = ["all", ...new Set(window.PROJECTS.map(p => p.category[lang]))];
  const filtered = filter === "all" ? window.PROJECTS : window.PROJECTS.filter(p => p.category[lang] === filter);

  return (
    <div className="va-anim">
      <section className="va-container" style={{ padding: "100px 40px 60px" }}>
        <div className="va-eyebrow" style={{ marginBottom: 32 }}>{t.sections.index} · {window.PROJECTS.length}</div>
        <h1 className="va-h1">
          {lang === "tr" ? <>Tüm <em>işler</em></> : <>All <em>works</em></>}
        </h1>
      </section>
      <section className="va-container" style={{ padding: "0 40px 40px" }}>
        <div className="va-rule" style={{ marginBottom: 20 }} />
        <div className="va-meta" style={{ marginBottom: 14 }}>{lang === "tr" ? "Filtre" : "Filter"}</div>
        <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
          {cats.map(c => {
            const active = filter === c;
            const count = c === "all" ? window.PROJECTS.length : window.PROJECTS.filter(p => p.category[lang] === c).length;
            return (
              <button key={c} onClick={() => setFilter(c)}
                style={{
                  background: active ? A_PALETTE.ink : "transparent",
                  color: active ? A_PALETTE.bg : A_PALETTE.mid,
                  border: `1px solid ${active ? A_PALETTE.ink : A_PALETTE.rule}`,
                  padding: "6px 12px",
                  cursor: "pointer",
                  fontFamily: "var(--mono)",
                  fontSize: 11,
                  letterSpacing: "0.12em",
                  textTransform: "uppercase",
                  borderRadius: 999,
                  transition: "background .2s, color .2s, border-color .2s",
                  display: "inline-flex",
                  alignItems: "center",
                  gap: 6,
                }}>
                <span>{c === "all" ? (lang === "tr" ? "Hepsi" : "All") : c}</span>
                <span style={{ opacity: 0.55, fontSize: 10 }}>{String(count).padStart(2, "0")}</span>
              </button>
            );
          })}
        </div>
      </section>

      <section className="va-container" style={{ padding: "20px 40px 0" }}>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 48, rowGap: 80 }}>
          {filtered.map((p, i) => (
            <div key={p.slug} className="va-tile" onClick={() => setPage({ name: "project", slug: p.slug })}
              style={{ paddingTop: i % 3 === 1 ? 64 : 0 }}>
              <div className="va-tile-img-wrap">
                <window.Placeholder slug={p.slug} category={p.category} ratio={i % 3 === 1 ? "3/4" : "4/3"} label={p.name} />
                <window.TileOverlay project={p} index={i + 1} lang={lang} />
              </div>
              <div className="va-tile-meta">
                <div>
                  <div className="name">{p.name}</div>
                  <div style={{ marginTop: 4 }}>{p.location} · {p.category[lang]}</div>
                </div>
                <div>{p.year}</div>
              </div>
            </div>
          ))}
        </div>
      </section>

      <AFooter t={t} setPage={setPage} lang={lang} />
    </div>
  );
}

function AProject({ slug, setPage, t, lang }) {
  const idx = window.PROJECTS.findIndex(p => p.slug === slug);
  const p = window.PROJECTS[idx];
  if (!p) return null;
  const prev = window.PROJECTS[(idx - 1 + window.PROJECTS.length) % window.PROJECTS.length];
  const next = window.PROJECTS[(idx + 1) % window.PROJECTS.length];

  return (
    <div className="va-anim">
      <section className="va-container" style={{ padding: "60px 40px 40px" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", marginBottom: 60 }}>
          <a className="va-meta" style={{ cursor: "pointer" }} onClick={() => setPage({ name: "projects" })}>← {t.sections.index}</a>
          <div className="va-meta">{String(idx + 1).padStart(2, "0")} / {String(window.PROJECTS.length).padStart(2, "0")}</div>
        </div>
        <div className="va-eyebrow" style={{ marginBottom: 24 }}>{p.category[lang]} · {p.year}</div>
        <h1 className="va-h1">{p.name}</h1>
      </section>

      <section className="va-container" style={{ padding: "40px 40px 0" }}>
        <window.Placeholder slug={p.slug} category={p.category} ratio="16/9" label={`${p.name} · 01`} scale={1.3} />
      </section>

      <section className="va-container" style={{ padding: "80px 40px 0" }}>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 2fr", gap: 80, marginBottom: 80 }}>
          <div>
            <div className="va-meta" style={{ marginBottom: 24 }}>{t.sections.info}</div>
            <dl style={{ margin: 0 }}>
              {[
                [t.sections.year, p.year],
                [t.sections.location, p.location],
                [t.sections.category, p.category[lang]],
                [t.sections.area, p.area],
                [t.sections.client, p.client],
                [t.sections.program, p.program[lang]],
              ].map(([k, v], i) => (
                <div key={i} style={{ display: "flex", padding: "12px 0", borderTop: `1px solid ${A_PALETTE.rule}` }}>
                  <dt className="va-meta" style={{ flex: "0 0 40%" }}>{k}</dt>
                  <dd style={{ margin: 0, fontSize: 14, letterSpacing: "-0.005em" }}>{v}</dd>
                </div>
              ))}
            </dl>
          </div>
          <div>
            <p className="va-lede">
              {lang === "tr"
                ? `${p.name}, ${p.location}'da konumlanan bir ${p.category[lang].toLowerCase()} projesidir. ${p.program.tr} programıyla, malzeme dilini yere ait kılma niyetiyle tasarlandı.`
                : `${p.name} is a ${p.category[lang].toLowerCase()} project located in ${p.location}. With a programme of ${p.program.en.toLowerCase()}, it was designed with the intention of grounding its material language in place.`}
            </p>
          </div>
        </div>
      </section>

      <section className="va-container" style={{ padding: "20px 40px 0" }}>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 32 }}>
          <window.Placeholder slug={p.slug} category={p.category} ratio="4/5" label={`${p.name} · 02`} idx={2} />
          <window.Placeholder slug={p.slug} category={p.category} ratio="4/5" label={`${p.name} · 03`} idx={3} />
        </div>
        <div style={{ marginTop: 32 }}>
          <window.Placeholder slug={p.slug} category={p.category} ratio="16/8" label={`${p.name} · 04`} idx={4} />
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr", gap: 32, marginTop: 32 }}>
          <window.Placeholder slug={p.slug} category={p.category} ratio="4/3" label={`${p.name} · 05`} idx={5} />
          <window.Placeholder slug={p.slug} category={p.category} ratio="3/4" label={`${p.name} · 06`} idx={6} />
        </div>
      </section>

      <section className="va-container" style={{ padding: "100px 40px 60px" }}>
        <div className="va-rule" style={{ marginBottom: 40 }} />
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 60 }}>
          <a className="va-tile" onClick={() => setPage({ name: "project", slug: prev.slug })}>
            <div className="va-meta" style={{ marginBottom: 18 }}>← {t.sections.prev}</div>
            <h3 className="va-h3">{prev.name}</h3>
            <div className="va-tile-meta">
              <div>{prev.location}</div>
              <div>{prev.year}</div>
            </div>
          </a>
          <a className="va-tile" style={{ textAlign: "right" }} onClick={() => setPage({ name: "project", slug: next.slug })}>
            <div className="va-meta" style={{ marginBottom: 18 }}>{t.sections.next} →</div>
            <h3 className="va-h3">{next.name}</h3>
            <div className="va-tile-meta" style={{ flexDirection: "row-reverse" }}>
              <div>{next.location}</div>
              <div>{next.year}</div>
            </div>
          </a>
        </div>
      </section>

      <AFooter t={t} setPage={setPage} lang={lang} />
    </div>
  );
}

function AAbout({ setPage, t, lang }) {
  return (
    <div className="va-anim">
      <section className="va-container" style={{ padding: "100px 40px 80px" }}>
        <div className="va-eyebrow" style={{ marginBottom: 32 }}>{t.sections.studio} / 2017—</div>
        <h1 className="va-h1">
          {lang === "tr" ? <>Ankara'da kurulu<br />bir <em>iç mimarlık</em><br />stüdyosu.</> : <>An <em>interior design</em><br />studio based<br />in Ankara.</>}
        </h1>
      </section>

      <section className="va-container" style={{ padding: "40px 40px 100px" }}>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 2fr", gap: 80 }}>
          <div>
            <window.Placeholder slug="studio" category="Ofis" ratio="4/5" label={lang === "tr" ? "Stüdyo · Ankara" : "Studio · Ankara"} withFigure={true} />
          </div>
          <div>
            {t.about.paras.map((para, i) => (
              <p key={i} className={i === 0 ? "va-lede" : "va-body"} style={{ marginTop: i === 0 ? 0 : 24, fontSize: i === 0 ? undefined : 17 }}>
                {para}
              </p>
            ))}
            <div style={{ marginTop: 60, display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: "32px 24px" }}>
              {t.about.facts.map(([k, v], i) => (
                <div key={i} style={{ paddingTop: 16, borderTop: `1px solid ${A_PALETTE.rule}` }}>
                  <div className="va-meta" style={{ marginBottom: 8 }}>{k}</div>
                  <div style={{ fontSize: 22, letterSpacing: "-0.02em" }}>{v}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="va-container" style={{ padding: "40px 40px 80px" }}>
        <div className="va-rule" style={{ marginBottom: 40 }} />
        <div style={{ display: "grid", gridTemplateColumns: "1fr 2fr", gap: 80, marginBottom: 40 }}>
          <div className="va-meta">{t.sections.services}</div>
          <h2 className="va-h2">{lang === "tr" ? <>Dört disiplin,<br />tek <em>ekip</em>.</> : <>Four disciplines,<br />one <em>team</em>.</>}</h2>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: 60 }}>
          {t.services.map((s, i) => (
            <div key={i} style={{ paddingTop: 24, borderTop: `1px solid ${A_PALETTE.rule}` }}>
              <div className="va-meta" style={{ marginBottom: 12 }}>0{i + 1}</div>
              <h3 className="va-h3" style={{ marginBottom: 12 }}>{s.t}</h3>
              <p className="va-body" style={{ fontSize: 16 }}>{s.d}</p>
            </div>
          ))}
        </div>
      </section>

      <AFooter t={t} setPage={setPage} lang={lang} />
    </div>
  );
}

function AShop({ setPage, t, lang }) {
  const [selected, setSelected] = React.useState(null);
  const [inquiry, setInquiry] = React.useState(false);
  const [selFabric, setSelFabric] = React.useState(0);
  const [selFinish, setSelFinish] = React.useState(0);
  const items = window.FURNITURE || [];
  const types = ["all", ...new Set(items.map(i => i.type[lang]))];
  const [filter, setFilter] = React.useState("all");
  const filtered = filter === "all" ? items : items.filter(i => i.type[lang] === filter);

  // Reset selection when opening a new item
  React.useEffect(() => { setSelFabric(0); setSelFinish(0); }, [selected?.slug]);

  return (
    <div className="va-anim">
      <section className="va-container" style={{ padding: "100px 40px 60px" }}>
        <div className="va-eyebrow" style={{ marginBottom: 32 }}>
          {lang === "tr" ? "Stüdyo Edisyonu · Mobilya" : "Studio Edition · Furniture"}
        </div>
        <h1 className="va-h1">
          {lang === "tr"
            ? <>Projeden<br /><em>nesneye.</em></>
            : <>From the project<br />to the <em>object.</em></>}
        </h1>
        <div style={{ display: "grid", gridTemplateColumns: "1.2fr 1fr", gap: 60, marginTop: 60, alignItems: "end" }}>
          <p className="va-lede">
            {lang === "tr"
              ? "Projelerimiz için ürettiğimiz mobilyaların seçili bir bölümünü stüdyo edisyonu olarak sunuyoruz. Her parça Ankara'da, küçük atölye ortağımızla üretilir; isteğe göre malzeme, ölçü ve kaplama uyarlanabilir."
              : "We offer a selected range of the furniture we develop for our projects as a studio edition. Each piece is made in Ankara, with our atelier partner; materials, dimensions and finishes can be adapted on request."}
          </p>
          <div style={{ display: "flex", justifyContent: "flex-end" }}>
            <div className="va-meta">
              {items.length} {lang === "tr" ? "parça · sipariş veya stoktan" : "pieces · made-to-order or in stock"}
            </div>
          </div>
        </div>
      </section>

      {/* Filter row */}
      <section className="va-container" style={{ padding: "0 40px 24px" }}>
        <div className="va-rule" style={{ marginBottom: 20 }} />
        <div className="va-meta" style={{ marginBottom: 14 }}>{lang === "tr" ? "Kategori" : "Category"}</div>
        <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
          {types.map(c => {
            const active = filter === c;
            const count = c === "all" ? items.length : items.filter(i => i.type[lang] === c).length;
            return (
              <button key={c} onClick={() => setFilter(c)}
                style={{
                  background: active ? "var(--ink, #38383c)" : "transparent",
                  color: active ? "var(--bg, #fbf6ec)" : "rgba(0,0,0,0.6)",
                  border: `1px solid ${active ? "var(--ink, #38383c)" : "rgba(0,0,0,0.18)"}`,
                  padding: "6px 12px",
                  cursor: "pointer",
                  fontFamily: "var(--mono)",
                  fontSize: 11,
                  letterSpacing: "0.12em",
                  textTransform: "uppercase",
                  borderRadius: 999,
                  transition: "background .2s, color .2s, border-color .2s",
                  display: "inline-flex",
                  alignItems: "center",
                  gap: 6,
                }}>
                <span>{c === "all" ? (lang === "tr" ? "Hepsi" : "All") : c}</span>
                <span style={{ opacity: 0.55, fontSize: 10 }}>{String(count).padStart(2, "0")}</span>
              </button>
            );
          })}
        </div>
      </section>

      {/* Grid */}
      <section className="va-container" style={{ padding: "20px 40px 40px" }}>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 40, rowGap: 64 }}>
          {filtered.map((it, i) => (
            <div key={it.slug} className="va-tile" onClick={() => setSelected(it)}
              style={{ paddingTop: i % 3 === 1 ? 48 : 0 }}>
              <window.Placeholder
                slug={it.slug}
                category={{ tr: "Mağaza", en: "Retail" }}
                ratio={i % 3 === 1 ? "3/4" : "4/5"}
                label={it.name}
              />
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", marginTop: 16, gap: 12 }}>
                <div>
                  <div style={{ fontFamily: "var(--display)", fontSize: 19, fontWeight: 500, letterSpacing: "-0.015em" }}>{it.name}</div>
                  <div className="va-meta" style={{ marginTop: 4 }}>{it.type[lang]} · {it.year}</div>
                  <div style={{ fontFamily: "var(--mono)", fontSize: 11, color: "rgba(0,0,0,0.55)", marginTop: 6, letterSpacing: "0.04em" }}>
                    {it.materials[lang]}
                  </div>
                  {/* Mini swatch row — combined fabrics + finishes, first 5 */}
                  {(() => {
                    const allSwatches = [...(it.fabrics || []), ...(it.finishes || [])];
                    return allSwatches.length > 0 && (
                      <div style={{ display: "flex", gap: 4, marginTop: 10, alignItems: "center" }}>
                        {allSwatches.slice(0, 5).map((s, j) => (
                          <span key={j} title={s.name[lang]} style={{
                            width: 14, height: 14, background: s.swatch,
                            borderRadius: "50%", border: `1px solid ${A_PALETTE.rule}`,
                          }} />
                        ))}
                        {allSwatches.length > 5 && (
                          <span className="va-meta" style={{ fontSize: 10, marginLeft: 2 }}>+{allSwatches.length - 5}</span>
                        )}
                      </div>
                    );
                  })()}
                </div>
                <div className="va-meta" style={{ textAlign: "right", whiteSpace: "nowrap" }}>{it.edition[lang]}</div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Selected detail overlay */}
      {selected && (
        <div onClick={(e) => { if (e.target === e.currentTarget) setSelected(null); }}
          style={{
            position: "fixed", inset: 0, zIndex: 50,
            background: "rgba(20,15,12,0.6)", backdropFilter: "blur(8px)",
            display: "flex", alignItems: "center", justifyContent: "center", padding: 40,
          }}>
          <div style={{
            background: "var(--bg, #fbf6ec)", color: "var(--ink, #38383c)",
            width: "min(1100px, 100%)", maxHeight: "92vh", overflow: "auto",
            padding: 0, display: "grid", gridTemplateColumns: "1fr 1fr", gap: 0,
            border: "1px solid rgba(0,0,0,0.12)",
          }}>
            <div style={{ background: "rgba(0,0,0,0.04)" }}>
              <window.Placeholder slug={selected.slug} category={{ tr: "Mağaza", en: "Retail" }} ratio="4/5" label={selected.name} />
            </div>
            <div style={{ padding: 40, display: "flex", flexDirection: "column", gap: 18 }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "start" }}>
                <div className="va-meta">{selected.type[lang]} · {selected.year}</div>
                <button onClick={() => setSelected(null)} style={{
                  background: "none", border: "none", padding: 0, cursor: "pointer",
                  fontFamily: "var(--mono)", fontSize: 12, letterSpacing: "0.1em",
                }}>{lang === "tr" ? "KAPAT ✕" : "CLOSE ✕"}</button>
              </div>
              <h2 className="va-h2" style={{ fontSize: "clamp(36px, 4vw, 56px)" }}>{selected.name}</h2>
              <p style={{ fontFamily: "var(--serif)", fontSize: 19, lineHeight: 1.4, margin: 0, fontStyle: "italic" }}>
                {lang === "tr"
                  ? `${selected.name}, ${window.PROJECTS.find(p => p.slug === selected.project)?.name || "stüdyo"} projesi için tasarlandı.`
                  : `${selected.name} was designed for ${window.PROJECTS.find(p => p.slug === selected.project)?.name || "the studio"}.`}
              </p>

              {/* Fabric / upholstery options */}
              {selected.fabrics && selected.fabrics.length > 0 && (
                <div style={{ marginTop: 4 }}>
                  <div className="va-meta" style={{ marginBottom: 10 }}>
                    {lang === "tr" ? "Kumaş / döşeme" : "Fabric / upholstery"}
                    <span style={{ opacity: 0.6, marginLeft: 8 }}>· {selected.fabrics[selFabric].name[lang]}</span>
                  </div>
                  <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
                    {selected.fabrics.map((f, i) => {
                      const active = i === selFabric;
                      return (
                        <button key={i} onClick={() => setSelFabric(i)}
                          title={f.name[lang]}
                          style={{
                            display: "flex", flexDirection: "column", alignItems: "center", gap: 6,
                            background: "none", border: "none", padding: 0, cursor: "pointer",
                            fontFamily: "inherit",
                          }}>
                          <span style={{
                            width: 44, height: 44, background: f.swatch,
                            borderRadius: "50%",
                            border: active ? `2px solid var(--ink, #38383c)` : `1px solid rgba(0,0,0,0.18)`,
                            boxShadow: active ? "0 0 0 2px var(--bg, #fbf6ec) inset" : "none",
                            transition: "border .15s",
                          }} />
                          <span style={{
                            fontFamily: "var(--mono)", fontSize: 9, letterSpacing: "0.06em",
                            color: active ? "var(--ink, #38383c)" : "rgba(0,0,0,0.55)",
                            textTransform: "uppercase", textAlign: "center", maxWidth: 64, lineHeight: 1.2,
                          }}>{f.name[lang]}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Finish / wood / metal options */}
              {selected.finishes && selected.finishes.length > 0 && (
                <div style={{ marginTop: 4 }}>
                  <div className="va-meta" style={{ marginBottom: 10 }}>
                    {lang === "tr" ? "Kaplama / renk" : "Finish / colour"}
                    <span style={{ opacity: 0.6, marginLeft: 8 }}>· {selected.finishes[selFinish].name[lang]}</span>
                  </div>
                  <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
                    {selected.finishes.map((f, i) => {
                      const active = i === selFinish;
                      return (
                        <button key={i} onClick={() => setSelFinish(i)}
                          title={f.name[lang]}
                          style={{
                            display: "flex", flexDirection: "column", alignItems: "center", gap: 6,
                            background: "none", border: "none", padding: 0, cursor: "pointer",
                            fontFamily: "inherit",
                          }}>
                          <span style={{
                            width: 44, height: 44, background: f.swatch,
                            borderRadius: 4,
                            border: active ? `2px solid var(--ink, #38383c)` : `1px solid rgba(0,0,0,0.18)`,
                            boxShadow: active ? "0 0 0 2px var(--bg, #fbf6ec) inset" : "none",
                            transition: "border .15s",
                          }} />
                          <span style={{
                            fontFamily: "var(--mono)", fontSize: 9, letterSpacing: "0.06em",
                            color: active ? "var(--ink, #38383c)" : "rgba(0,0,0,0.55)",
                            textTransform: "uppercase", textAlign: "center", maxWidth: 64, lineHeight: 1.2,
                          }}>{f.name[lang]}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              <dl style={{ margin: "8px 0 0", display: "grid", gap: 0 }}>
                {[
                  [lang === "tr" ? "Ölçü" : "Dimensions", typeof selected.dim === "object" ? selected.dim[lang] : selected.dim],
                  [lang === "tr" ? "Malzeme" : "Materials", selected.materials[lang]],
                  [lang === "tr" ? "Edisyon" : "Edition", selected.edition[lang]],
                  selected.project
                    ? [lang === "tr" ? "Proje" : "From project", window.PROJECTS.find(p => p.slug === selected.project)?.name || "—"]
                    : [lang === "tr" ? "Kategori" : "Category", selected.subtype ? selected.subtype[lang] : selected.type[lang]],
                  [lang === "tr" ? "Üretim süresi" : "Lead time", lang === "tr" ? "4–6 hafta" : "4–6 weeks"],
                ].map(([k, v], i) => (
                  <div key={i} style={{ display: "flex", padding: "12px 0", borderTop: "1px solid rgba(0,0,0,0.12)", fontSize: 14 }}>
                    <dt className="va-meta" style={{ flex: "0 0 40%" }}>{k}</dt>
                    <dd style={{ margin: 0, letterSpacing: "-0.005em" }}>{v}</dd>
                  </div>
                ))}
              </dl>

              <div style={{ display: "flex", gap: 12, marginTop: 8, flexWrap: "wrap" }}>
                <button onClick={() => setInquiry(true)} className="va-pill"
                  style={{ background: "var(--ink, #38383c)", color: "var(--bg, #fbf6ec)" }}>
                  {lang === "tr" ? "Fiyat & sipariş için yaz →" : "Inquire price & order →"}
                </button>
                <a href={(() => {
                    const subj = selected.name + " — " + (lang === "tr" ? "sipariş talebi" : "inquiry");
                    const dimText = typeof selected.dim === "object" ? selected.dim[lang] : selected.dim;
                    const lines = [
                      `${lang === "tr" ? "Parça" : "Piece"}: ${selected.name}`,
                      `${lang === "tr" ? "Ölçü" : "Dimensions"}: ${dimText}`,
                      selected.fabrics ? `${lang === "tr" ? "Kumaş / Renk" : "Fabric / Colour"}: ${selected.fabrics[selFabric].name[lang]}` : null,
                      selected.finishes ? `${lang === "tr" ? "Kaplama" : "Finish"}: ${selected.finishes[selFinish].name[lang]}` : null,
                    ].filter(Boolean).join("\n");
                    return `mailto:${window.CONTACT.email}?subject=${encodeURIComponent(subj)}&body=${encodeURIComponent(lines)}`;
                  })()}
                  className="va-pill" style={{ textDecoration: "none" }}>
                  {window.CONTACT.email}
                </a>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Inquiry sent state */}
      {inquiry && (
        <div onClick={() => { setInquiry(false); setSelected(null); }}
          style={{
            position: "fixed", inset: 0, zIndex: 60,
            background: "rgba(20,15,12,0.85)", backdropFilter: "blur(10px)",
            display: "flex", alignItems: "center", justifyContent: "center", padding: 40,
            color: "var(--bg, #fbf6ec)", textAlign: "center", flexDirection: "column", gap: 16,
          }}>
          <div style={{ fontFamily: "var(--serif)", fontStyle: "italic", fontSize: "clamp(32px, 4vw, 52px)", letterSpacing: "-0.02em" }}>
            {lang === "tr" ? "Talebiniz alındı." : "Your inquiry has arrived."}
          </div>
          <div className="va-meta">{lang === "tr" ? "En kısa sürede dönüş yapacağız" : "We'll get back shortly"} — {window.CONTACT.email}</div>
        </div>
      )}

      <section className="va-container" style={{ padding: "60px 40px 40px" }}>
        <div className="va-rule" />
        <div style={{ display: "grid", gridTemplateColumns: "1fr 2fr", gap: 60, padding: "32px 0" }}>
          <div className="va-meta">{lang === "tr" ? "Sipariş bilgisi" : "Ordering"}</div>
          <div className="va-body">
            {lang === "tr"
              ? "Tüm parçalar Ankara'da üretilir. Üretim süresi seçilen malzemeye göre 4–6 haftadır; özel ölçü ve kaplama talepleri için stüdyoya yazın. Türkiye içi teslimat dahildir; yurtdışı gönderim için ayrı teklif veriyoruz."
              : "All pieces are made in Ankara. Lead time is 4–6 weeks depending on materials; write to the studio for custom sizes and finishes. Delivery within Turkey is included; international shipping is quoted separately."}
          </div>
        </div>
      </section>

      <AFooter t={t} setPage={setPage} lang={lang} />
    </div>
  );
}

function AJournal({ setPage, t, lang }) {
  const J = window.JOURNAL || [];
  const cats = ["all", ...new Set(J.map(p => p.category[lang]))];
  const [cat, setCat] = React.useState("all");
  const filtered = cat === "all" ? J : J.filter(p => p.category[lang] === cat);
  const fmt = (d) => {
    const date = new Date(d);
    return date.toLocaleDateString(lang === "tr" ? "tr-TR" : "en-US", { day: "numeric", month: "long", year: "numeric" });
  };

  return (
    <div className="va-anim">
      <section className="va-container" style={{ padding: "100px 40px 40px" }}>
        <div className="va-eyebrow" style={{ marginBottom: 32 }}>
          {lang === "tr" ? "Stüdyo · Günlük" : "Studio · Journal"} · {J.length}
        </div>
        <h1 className="va-h1">
          {lang === "tr" ? <>Yazılar,<br />kayıtlar, <em>notlar.</em></> : <>Writings,<br />records, <em>notes.</em></>}
        </h1>
        <p className="va-lede" style={{ marginTop: 40 }}>
          {lang === "tr"
            ? "Açılış günleri, malzeme notları, süreç yazıları ve geriye dönüşler. Stüdyonun resmi olmayan defteri."
            : "Opening days, material notes, process writings and retrospects. The unofficial notebook of the studio."}
        </p>
      </section>

      <section className="va-container" style={{ padding: "0 40px 24px" }}>
        <div className="va-rule" style={{ marginBottom: 20 }} />
        <div className="va-meta" style={{ marginBottom: 14 }}>{lang === "tr" ? "Kategori" : "Category"}</div>
        <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
          {cats.map(c => {
            const active = cat === c;
            const count = c === "all" ? J.length : J.filter(p => p.category[lang] === c).length;
            return (
              <button key={c} onClick={() => setCat(c)}
                style={{
                  background: active ? A_PALETTE.ink : "transparent",
                  color: active ? A_PALETTE.bg : A_PALETTE.mid,
                  border: `1px solid ${active ? A_PALETTE.ink : A_PALETTE.rule}`,
                  padding: "6px 12px", cursor: "pointer", fontFamily: "var(--mono)",
                  fontSize: 11, letterSpacing: "0.12em", textTransform: "uppercase",
                  borderRadius: 999, transition: "all .2s",
                  display: "inline-flex", alignItems: "center", gap: 6,
                }}>
                <span>{c === "all" ? (lang === "tr" ? "Hepsi" : "All") : c}</span>
                <span style={{ opacity: 0.55, fontSize: 10 }}>{String(count).padStart(2, "0")}</span>
              </button>
            );
          })}
        </div>
      </section>

      <section className="va-container" style={{ padding: "20px 40px 60px" }}>
        <div className="va-rule" />
        {filtered.map((p, i) => (
          <a key={p.slug} onClick={() => setPage({ name: "journal-post", slug: p.slug })}
            style={{ display: "block", cursor: "pointer" }}
            onMouseEnter={(e) => e.currentTarget.style.background = A_PALETTE.paper}
            onMouseLeave={(e) => e.currentTarget.style.background = "transparent"}>
            <div style={{
              display: "grid", gridTemplateColumns: "80px 140px 1fr 140px 40px",
              gap: 24, padding: "28px 0", borderBottom: `1px solid ${A_PALETTE.rule}`,
              alignItems: "baseline", transition: "background .2s",
            }}>
              <div className="va-meta">{String(i + 1).padStart(2, "0")}</div>
              <div className="va-meta">{fmt(p.date)}</div>
              <div>
                <div style={{ fontFamily: "var(--display)", fontSize: "clamp(22px, 2.4vw, 36px)", letterSpacing: "-0.02em", lineHeight: 1.15, marginBottom: 8 }}>
                  {p.title[lang]}
                </div>
                <div style={{ fontFamily: "var(--serif)", fontStyle: "italic", fontSize: 15, color: A_PALETTE.mid, lineHeight: 1.45, maxWidth: "62ch" }}>
                  {p.excerpt[lang]}
                </div>
              </div>
              <div className="va-meta" style={{ textAlign: "right" }}>
                <div>{p.category[lang]}</div>
                <div style={{ marginTop: 6, opacity: 0.6 }}>{p.readMin} {lang === "tr" ? "dk okuma" : "min read"}</div>
              </div>
              <div className="va-meta" style={{ textAlign: "right" }}>→</div>
            </div>
          </a>
        ))}
      </section>

      <AFooter t={t} setPage={setPage} lang={lang} />
    </div>
  );
}

function AJournalPost({ slug, setPage, t, lang }) {
  const J = window.JOURNAL || [];
  const idx = J.findIndex(p => p.slug === slug);
  const post = J[idx];
  if (!post) return null;
  const next = J[(idx + 1) % J.length];
  const prev = J[(idx - 1 + J.length) % J.length];
  const fmt = (d) => new Date(d).toLocaleDateString(lang === "tr" ? "tr-TR" : "en-US", { day: "numeric", month: "long", year: "numeric" });
  const related = post.related ? window.PROJECTS.find(p => p.slug === post.related) : null;

  // Generate body paragraphs (placeholder editorial text seeded on the excerpt)
  const body = lang === "tr"
    ? [
        post.excerpt.tr,
        "Bir projeyi belirleyen şey çoğu zaman büyük tasarım kararı değil; o kararı taşıyan onlarca küçük detaydır. Bu yazıda, mekânın gündelik kullanımında ortaya çıkan bu detaylar üzerine düşünmek istiyoruz.",
        "Stüdyoda her zaman söyleriz: tasarım, üretim disiplinidir. Bir çizginin kağıtta varlığı, ancak şantiyede o çizginin nasıl çekildiğiyle anlam kazanır.",
        "Bu projede bizi en çok yormuş olan şey, görünmeyen detaylardı. Bir kapının açılış yönü, bir lambanın yüksekliği, bir duvarın bittiği yer — bunların her biri, mekânın günlük ritmini değiştiriyor.",
        "Sonuç olarak — eğer bir proje 'sonuç' kelimesini hak ediyorsa — burada öğrendiğimiz şey, sabırla ilgili. Bir mekânın olgunlaşması zaman alır; bizim işimiz o olgunlaşmaya alan bırakmak.",
      ]
    : [
        post.excerpt.en,
        "What often defines a project is not the big design decision but the dozens of small details that carry it. In this piece we want to think about those details — the ones that surface in the everyday use of a space.",
        "We always say in the studio: design is a discipline of making. A line's existence on paper takes on meaning only by how that line is drawn on site.",
        "What tired us most on this project was the invisible details. The direction a door opens, the height of a lamp, the place where a wall ends — each of these changes the daily rhythm of the space.",
        "In the end — if a project deserves the word 'end' — what we learned here is about patience. A space takes time to mature; our job is to leave room for that maturity.",
      ];

  return (
    <div className="va-anim">
      <section className="va-container" style={{ padding: "60px 40px 40px" }}>
        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 32 }}>
          <a className="va-meta" style={{ cursor: "pointer" }} onClick={() => setPage({ name: "journal" })}>← {lang === "tr" ? "Günlük" : "Journal"}</a>
          <div className="va-meta">{String(idx + 1).padStart(2, "0")} / {String(J.length).padStart(2, "0")}</div>
        </div>
        <div className="va-eyebrow" style={{ marginBottom: 28 }}>{fmt(post.date)} · {post.category[lang]} · {post.readMin} {lang === "tr" ? "dk okuma" : "min read"}</div>
        <h1 className="va-h1" style={{ maxWidth: "20ch" }}>{post.title[lang]}</h1>
      </section>

      {/* Hero image */}
      <section className="va-container" style={{ padding: "20px 40px 0" }}>
        <window.Placeholder slug={post.slug} category={{ tr: "Karma", en: "Mixed-use" }} ratio="16/8" label={post.title[lang]} scale={1.3} />
      </section>

      {/* Body */}
      <section className="va-container" style={{ padding: "80px 40px 40px" }}>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 2fr 1fr", gap: 60 }}>
          <div className="va-meta">{lang === "tr" ? "Yazı" : "Article"} / {String(idx + 1).padStart(2, "0")}</div>
          <div>
            {body.map((para, i) => (
              <p key={i} className={i === 0 ? "va-lede" : ""}
                style={{
                  marginTop: i === 0 ? 0 : 24,
                  marginBottom: 0,
                  fontFamily: i === 0 ? "var(--serif)" : "var(--display)",
                  fontStyle: i === 0 ? "italic" : "normal",
                  fontSize: i === 0 ? undefined : 17,
                  lineHeight: i === 0 ? 1.42 : 1.62,
                  color: i === 0 ? A_PALETTE.ink : A_PALETTE.mid,
                  maxWidth: "64ch",
                }}>
                {para}
              </p>
            ))}

            {related && (
              <div style={{ marginTop: 56, paddingTop: 24, borderTop: `1px solid ${A_PALETTE.rule}` }}>
                <div className="va-meta" style={{ marginBottom: 12 }}>{lang === "tr" ? "İlgili proje" : "Related project"}</div>
                <a onClick={() => setPage({ name: "project", slug: related.slug })}
                  style={{ display: "block", cursor: "pointer" }}>
                  <div style={{ fontFamily: "var(--display)", fontSize: 28, letterSpacing: "-0.02em" }}>{related.name} →</div>
                  <div className="va-meta" style={{ marginTop: 6 }}>{related.location} · {related.year}</div>
                </a>
              </div>
            )}
          </div>
          <div></div>
        </div>
      </section>

      {/* Prev / Next */}
      <section className="va-container" style={{ padding: "60px 40px 40px" }}>
        <div className="va-rule" style={{ marginBottom: 32 }} />
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 40 }}>
          <a onClick={() => setPage({ name: "journal-post", slug: prev.slug })} style={{ cursor: "pointer" }}>
            <div className="va-meta" style={{ marginBottom: 10 }}>← {lang === "tr" ? "Önceki yazı" : "Previous"}</div>
            <div style={{ fontFamily: "var(--display)", fontSize: 24, letterSpacing: "-0.02em" }}>{prev.title[lang]}</div>
          </a>
          <a onClick={() => setPage({ name: "journal-post", slug: next.slug })} style={{ cursor: "pointer", textAlign: "right" }}>
            <div className="va-meta" style={{ marginBottom: 10 }}>{lang === "tr" ? "Sonraki yazı" : "Next"} →</div>
            <div style={{ fontFamily: "var(--display)", fontSize: 24, letterSpacing: "-0.02em" }}>{next.title[lang]}</div>
          </a>
        </div>
      </section>

      <AFooter t={t} setPage={setPage} lang={lang} />
    </div>
  );
}

function ANotFound({ setPage, t, lang }) {
  return (
    <div className="va-anim">
      <section className="va-container" style={{ padding: "120px 40px 80px", textAlign: "center" }}>
        <div className="va-eyebrow" style={{ marginBottom: 32 }}>404</div>
        <div style={{
          fontFamily: "var(--display)", fontSize: "clamp(120px, 22vw, 360px)",
          letterSpacing: "-0.06em", lineHeight: 0.85,
          color: A_PALETTE.ink,
        }}>
          <span style={{ fontFamily: "var(--serif)", fontStyle: "italic" }}>4</span>
          <span>0</span>
          <span style={{ fontFamily: "var(--serif)", fontStyle: "italic" }}>4</span>
        </div>
        <h2 className="va-h2" style={{ marginTop: 32 }}>
          {lang === "tr" ? <>Bu mekân, <em>henüz</em> yok.</> : <>This space <em>doesn't yet</em> exist.</>}
        </h2>
        <p className="va-lede" style={{ marginTop: 28, marginLeft: "auto", marginRight: "auto", maxWidth: "50ch" }}>
          {lang === "tr"
            ? "Aradığınız sayfayı bulamadık. Aşağıdaki yerlerden devam edebilirsiniz."
            : "We couldn't find the page you were looking for. You can continue from one of the places below."}
        </p>
        <div style={{ display: "flex", gap: 12, justifyContent: "center", marginTop: 40, flexWrap: "wrap" }}>
          <a className="va-pill" onClick={() => setPage({ name: "index" })}>{t.nav.index} →</a>
          <a className="va-pill" onClick={() => setPage({ name: "projects" })}>{t.nav.projects} →</a>
          <a className="va-pill" onClick={() => setPage({ name: "contact" })}>{t.nav.contact} →</a>
        </div>
      </section>
      <AFooter t={t} setPage={setPage} lang={lang} />
    </div>
  );
}

function ASearch({ open, onClose, setPage, lang }) {
  const [q, setQ] = React.useState("");
  const inputRef = React.useRef(null);

  React.useEffect(() => {
    if (open) {
      setQ("");
      setTimeout(() => inputRef.current?.focus(), 80);
    }
    document.body.style.overflow = open ? "hidden" : "";
    return () => { document.body.style.overflow = ""; };
  }, [open]);

  React.useEffect(() => {
    const onKey = (e) => {
      if (e.key === "Escape" && open) onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  if (!open) return null;

  const norm = (s) => (s || "").toLocaleLowerCase("tr").trim();
  const Q = norm(q);

  let results = [];
  if (Q.length > 0) {
    // Projects
    for (const p of window.PROJECTS) {
      const hay = norm(`${p.name} ${p.location} ${p.category[lang]} ${p.client} ${p.program[lang]}`);
      if (hay.includes(Q)) {
        results.push({
          kind: lang === "tr" ? "İş" : "Project",
          title: p.name,
          subtitle: `${p.location} · ${p.category[lang]} · ${p.year}`,
          onClick: () => { setPage({ name: "project", slug: p.slug }); onClose(); },
        });
      }
    }
    // Furniture
    for (const it of (window.FURNITURE || [])) {
      const hay = norm(`${it.name} ${it.type[lang]} ${it.materials[lang]} ${it.edition[lang]}`);
      if (hay.includes(Q)) {
        results.push({
          kind: "Store",
          title: it.name,
          subtitle: `${it.type[lang]} · ${it.materials[lang]}`,
          onClick: () => { setPage({ name: "shop" }); onClose(); },
        });
      }
    }
    // Journal
    for (const j of (window.JOURNAL || [])) {
      const hay = norm(`${j.title[lang]} ${j.excerpt[lang]} ${j.category[lang]}`);
      if (hay.includes(Q)) {
        results.push({
          kind: lang === "tr" ? "Günlük" : "Journal",
          title: j.title[lang],
          subtitle: `${j.category[lang]} · ${new Date(j.date).toLocaleDateString(lang === "tr" ? "tr-TR" : "en-US", { day: "numeric", month: "long", year: "numeric" })}`,
          onClick: () => { setPage({ name: "journal-post", slug: j.slug }); onClose(); },
        });
      }
    }
    results = results.slice(0, 18);
  }

  return (
    <div onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
      style={{
        position: "fixed", inset: 0, zIndex: 80,
        background: `${A_PALETTE.bg}f2`, backdropFilter: "blur(14px)",
        display: "flex", justifyContent: "center", alignItems: "flex-start",
        padding: "100px 24px 40px",
        overflowY: "auto",
      }}>
      <div style={{ width: "min(820px, 100%)" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", marginBottom: 18 }}>
          <div className="va-meta">{lang === "tr" ? "Ara" : "Search"}</div>
          <button onClick={onClose}
            style={{ background: "none", border: "none", padding: 0, fontFamily: "var(--mono)", fontSize: 11, letterSpacing: "0.12em", color: A_PALETTE.mid, cursor: "pointer" }}>
            ESC ✕
          </button>
        </div>
        <input
          ref={inputRef}
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder={lang === "tr" ? "Proje, mobilya, yazı… ara" : "Search projects, furniture, writings…"}
          style={{
            width: "100%",
            background: "transparent",
            border: "none",
            borderBottom: `2px solid ${A_PALETTE.ink}`,
            padding: "16px 0",
            fontFamily: "var(--display)",
            fontSize: "clamp(28px, 4vw, 56px)",
            letterSpacing: "-0.025em",
            color: A_PALETTE.ink,
            outline: "none",
          }}
        />
        <div className="va-meta" style={{ marginTop: 8, color: A_PALETTE.mid }}>
          {Q.length === 0
            ? (lang === "tr" ? "Aramaya başlayın · projeler, mobilya, yazılar" : "Start typing · projects, furniture, writings")
            : `${results.length} ${lang === "tr" ? "sonuç" : "results"}`}
        </div>

        <div style={{ marginTop: 32 }}>
          {results.map((r, i) => (
            <a key={i} onClick={r.onClick}
              style={{ display: "block", cursor: "pointer" }}
              onMouseEnter={(e) => e.currentTarget.style.background = A_PALETTE.paper}
              onMouseLeave={(e) => e.currentTarget.style.background = "transparent"}>
              <div style={{
                display: "grid", gridTemplateColumns: "80px 1fr auto",
                gap: 24, padding: "18px 0", borderBottom: `1px solid ${A_PALETTE.rule}`,
                alignItems: "baseline", transition: "background .2s",
              }}>
                <div className="va-meta">{r.kind}</div>
                <div>
                  <div style={{ fontFamily: "var(--display)", fontSize: 22, letterSpacing: "-0.015em" }}>{r.title}</div>
                  <div className="va-meta" style={{ marginTop: 4 }}>{r.subtitle}</div>
                </div>
                <div className="va-meta">↗</div>
              </div>
            </a>
          ))}
          {Q.length > 0 && results.length === 0 && (
            <div style={{ padding: "60px 0", textAlign: "center" }}>
              <div style={{ fontFamily: "var(--serif)", fontStyle: "italic", fontSize: 22, color: A_PALETTE.mid }}>
                {lang === "tr" ? "Sonuç yok." : "No results."}
              </div>
              <div className="va-meta" style={{ marginTop: 12 }}>
                {lang === "tr" ? "Başka kelimeler deneyin" : "Try another search"}
              </div>
            </div>
          )}
        </div>

        <div className="va-meta" style={{ marginTop: 48, opacity: 0.6 }}>
          {lang === "tr" ? "İPUCU · ⌘K veya Ctrl+K ile her sayfadan açabilirsiniz" : "TIP · Open from any page with ⌘K or Ctrl+K"}
        </div>
      </div>
    </div>
  );
}

function APlaylist({ setPage, t, lang }) {
  const PL = window.PLAYLIST;
  const [playingIdx, setPlayingIdx] = React.useState(null);
  return (
    <div className="va-anim">
      <section className="va-container" style={{ padding: "100px 40px 60px" }}>
        <div className="va-eyebrow" style={{ marginBottom: 32 }}>
          {lang === "tr" ? "Stüdyo · Playlist" : "Studio · Playlist"}
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "1.4fr 1fr", gap: 80, alignItems: "end" }}>
          <h1 className="va-h1">{PL.cover[lang]}</h1>
          <p className="va-lede">{PL.subtitle[lang]}</p>
        </div>
      </section>

      {/* Cassette / cover panel */}
      <section className="va-container" style={{ padding: "0 40px 40px" }}>
        <div style={{
          display: "grid", gridTemplateColumns: "1fr 1.6fr", gap: 40,
          background: "var(--bg2, rgba(0,0,0,0.05))",
          padding: 40, border: "1px solid var(--rule, rgba(0,0,0,0.12))",
          alignItems: "stretch",
        }}>
          <div style={{
            aspectRatio: "1/1", position: "relative",
            background: "linear-gradient(135deg, #c7d2dd 0%, #38383c 100%)",
            overflow: "hidden",
          }}>
            <svg viewBox="0 0 100 100" width="100%" height="100%" style={{ position: "absolute", inset: 0 }}>
              {/* concentric circles for a record-disc feel */}
              {[44, 36, 28, 20, 12].map((r, i) => (
                <circle key={i} cx="50" cy="50" r={r} fill="none" stroke="rgba(255,255,255,0.3)" strokeWidth="0.3" />
              ))}
              <circle cx="50" cy="50" r="6" fill="rgba(0,0,0,0.5)" />
              <circle cx="50" cy="50" r="1.5" fill="rgba(255,255,255,0.8)" />
            </svg>
            <div style={{
              position: "absolute", left: 20, top: 20, color: "rgba(255,255,255,0.85)",
              fontFamily: "var(--mono)", fontSize: 11, letterSpacing: "0.2em", textTransform: "uppercase",
            }}>
              Line Interiors<br />Vol. 01 · 2026
            </div>
            <div style={{
              position: "absolute", right: 20, bottom: 20, color: "rgba(255,255,255,0.85)",
              fontFamily: "var(--serif)", fontStyle: "italic", fontSize: 22, letterSpacing: "-0.01em",
            }}>
              Side A
            </div>
          </div>

          <div style={{ display: "flex", flexDirection: "column", justifyContent: "space-between" }}>
            <div>
              <div className="va-meta" style={{ marginBottom: 12 }}>{lang === "tr" ? "Çalma listesi" : "Tracklist"} · {PL.tracks.length}</div>
              <h2 className="va-h2" style={{ fontSize: "clamp(36px, 4.5vw, 72px)" }}>
                {lang === "tr" ? <>Stüdyoda<br /><em>çalan ne.</em></> : <>What plays<br />in the <em>studio.</em></>}
              </h2>
            </div>
            <div className="va-body" style={{ fontSize: 14 }}>
              {lang === "tr"
                ? "Sessizliği seven bir ofisin sesli versiyonu. Piyano, oda müziği, elektronik dokunuşlar."
                : "The audible version of an office that prefers quiet. Piano, chamber, soft electronics."}
            </div>
            <div style={{ display: "flex", gap: 10, marginTop: 18, flexWrap: "wrap" }}>
              <a className="va-pill"
                href={`https://open.spotify.com/search/${encodeURIComponent('Nils Frahm Hania Rani Ludovico Einaudi')}`}
                target="_blank" rel="noreferrer" style={{ textDecoration: "none" }}>
                Spotify'da aç →
              </a>
              <a className="va-pill"
                href={`https://music.apple.com/search?term=${encodeURIComponent('Nils Frahm Hania Rani')}`}
                target="_blank" rel="noreferrer" style={{ textDecoration: "none" }}>
                Apple Music →
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Tracklist */}
      <section className="va-container" style={{ padding: "20px 40px 60px" }}>
        <div className="va-rule" />
        <div style={{
          display: "grid", gridTemplateColumns: "40px 28px 1.6fr 1.2fr 0.8fr 60px",
          gap: 16, padding: "14px 0", borderBottom: "1px solid var(--rule, rgba(0,0,0,0.1))",
          fontFamily: "var(--mono)", fontSize: 10, letterSpacing: "0.14em", textTransform: "uppercase",
          color: "rgba(0,0,0,0.55)",
        }}>
          <div>#</div>
          <div></div>
          <div>{lang === "tr" ? "Parça" : "Track"}</div>
          <div>{lang === "tr" ? "Sanatçı · Albüm" : "Artist · Album"}</div>
          <div>{lang === "tr" ? "Süre" : "Length"}</div>
          <div></div>
        </div>
        {PL.tracks.map((tr, i) => {
          const playing = playingIdx === i;
          return (
            <div key={i}
              onClick={() => setPlayingIdx(playing ? null : i)}
              style={{
                display: "grid", gridTemplateColumns: "40px 28px 1.6fr 1.2fr 0.8fr 60px",
                gap: 16, alignItems: "center",
                padding: "16px 0", borderBottom: "1px solid var(--rule, rgba(0,0,0,0.1))",
                cursor: "pointer", transition: "background .15s",
              }}
              onMouseEnter={(e) => e.currentTarget.style.background = "rgba(0,0,0,0.03)"}
              onMouseLeave={(e) => e.currentTarget.style.background = "transparent"}>
              <div style={{ fontFamily: "var(--mono)", fontSize: 12, color: "rgba(0,0,0,0.5)" }}>
                {String(i + 1).padStart(2, "0")}
              </div>
              <div>
                {playing ? (
                  <div style={{ display: "flex", alignItems: "end", gap: 2, height: 18 }}>
                    {[0, 0.15, 0.3].map((d, j) => (
                      <span key={j} style={{
                        width: 3, background: "var(--ink, #38383c)",
                        animation: `bar 0.9s ease-in-out ${d}s infinite alternate`,
                      }} />
                    ))}
                  </div>
                ) : (
                  <div style={{ fontFamily: "var(--serif)", fontStyle: "italic", fontSize: 18, color: "rgba(0,0,0,0.4)" }}>▷</div>
                )}
              </div>
              <div>
                <div style={{
                  fontFamily: playing ? "var(--serif)" : "var(--display)",
                  fontStyle: playing ? "italic" : "normal",
                  fontSize: 19, letterSpacing: "-0.015em",
                }}>{tr.title}</div>
                {playing && (
                  <div className="va-meta" style={{ marginTop: 4 }}>{tr.note[lang]}</div>
                )}
              </div>
              <div className="va-meta">{tr.artist} · {tr.album} · {tr.year}</div>
              <div style={{ fontFamily: "var(--mono)", fontSize: 13, color: "rgba(0,0,0,0.7)" }}>{tr.dur}</div>
              <div style={{ textAlign: "right" }}>
                <a href={`https://open.spotify.com/search/${encodeURIComponent(tr.title + " " + tr.artist)}`}
                  target="_blank" rel="noreferrer"
                  onClick={(e) => e.stopPropagation()}
                  style={{ fontFamily: "var(--mono)", fontSize: 10, letterSpacing: "0.14em", textTransform: "uppercase", color: "rgba(0,0,0,0.5)", textDecoration: "none" }}>
                  ↗
                </a>
              </div>
            </div>
          );
        })}
        <style>{`@keyframes bar { 0% { height: 4px; } 100% { height: 18px; } }`}</style>
      </section>

      <section className="va-container" style={{ padding: "40px 40px 40px" }}>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 2fr", gap: 60 }}>
          <div className="va-meta">{lang === "tr" ? "Not" : "Note"}</div>
          <p className="va-body" style={{ fontSize: 16 }}>
            {lang === "tr"
              ? "Bu liste, stüdyoda çalışırken dinlediğimiz parçalardan derlendi. Her ay başında yenilenir. Bir sonraki proje için bir öneriniz varsa — yazın."
              : "This playlist is compiled from what we listen to while working in the studio. It is refreshed at the start of each month. If you have a track for the next project — write us."}
          </p>
        </div>
      </section>

      <AFooter t={t} setPage={setPage} lang={lang} />
    </div>
  );
}

function AContact({ setPage, t, lang }) {
  const [sent, setSent] = React.useState(false);
  const [sending, setSending] = React.useState(false);
  const [vals, setVals] = React.useState({ name: "", email: "", subject: "", message: "" });
  const [focusKey, setFocusKey] = React.useState(null);
  const [mapPinHover, setMapPinHover] = React.useState(false);

  const onSubmit = (e) => {
    e.preventDefault();
    setSending(true);
    setTimeout(() => { setSent(true); setSending(false); }, 950);
  };

  const localTimeAnkara = (() => {
    const now = new Date();
    const opt = { hour: "2-digit", minute: "2-digit", timeZone: "Europe/Istanbul", hour12: false };
    return now.toLocaleTimeString(lang === "tr" ? "tr-TR" : "en-US", opt);
  })();

  // Quick actions
  const actions = [
    { key: "email", label: t.contact.labels.email, value: window.CONTACT.email, href: `mailto:${window.CONTACT.email}`, icon: "✉" },
    { key: "phone", label: t.contact.labels.phone, value: window.CONTACT.phone, href: `tel:${window.CONTACT.phone.replace(/\s+/g, "")}`, icon: "☎" },
    { key: "whatsapp", label: "WhatsApp", value: window.CONTACT.phone, href: `https://wa.me/${window.CONTACT.phone.replace(/[^\d]/g, "")}`, icon: "✱" },
    { key: "instagram", label: t.contact.labels.instagram, value: window.CONTACT.instagram, href: `https://instagram.com/${window.CONTACT.instagram.replace(/^@/, "").replace(/^_+/, "")}`, icon: "◐" },
  ];

  return (
    <div className="va-anim">
      <style>{`
        .ac-input-wrap { position: relative; padding-top: 22px; }
        .ac-input-wrap label {
          position: absolute; left: 0; top: 32px;
          font-family: var(--display); font-size: 18px; letter-spacing: -0.01em;
          color: ${A_PALETTE.mid};
          pointer-events: none;
          transition: transform 0.35s cubic-bezier(.2,.7,.1,1), color 0.35s, font-size 0.35s, letter-spacing 0.35s;
          transform-origin: left top;
        }
        .ac-input-wrap[data-active="true"] label {
          transform: translateY(-22px) scale(0.62);
          color: ${A_PALETTE.ink};
          letter-spacing: 0.14em;
          text-transform: uppercase;
          font-family: var(--mono);
        }
        .ac-input-wrap input, .ac-input-wrap textarea {
          width: 100%; background: transparent; border: none;
          border-bottom: 1px solid ${A_PALETTE.rule};
          padding: 10px 0; font-size: 18px;
          font-family: var(--display); color: ${A_PALETTE.ink};
          outline: none;
          letter-spacing: -0.01em;
          transition: border-color 0.3s, padding-bottom 0.3s;
        }
        .ac-input-wrap input:focus, .ac-input-wrap textarea:focus { border-bottom-color: ${A_PALETTE.ink}; }
        .ac-input-wrap textarea { resize: vertical; line-height: 1.5; }
        .ac-input-wrap .ac-underline {
          position: absolute; left: 0; right: 100%; bottom: 0;
          height: 2px; background: ${A_PALETTE.ink};
          transition: right 0.5s cubic-bezier(.2,.7,.1,1);
        }
        .ac-input-wrap[data-focus="true"] .ac-underline { right: 0; }

        .ac-counter { position: absolute; right: 0; bottom: -18px; font-family: var(--mono); font-size: 10px; letter-spacing: 0.1em; color: ${A_PALETTE.mid}; }

        .ac-submit { position: relative; overflow: hidden; }
        .ac-submit-text, .ac-submit-loading, .ac-submit-check {
          display: inline-flex; align-items: center; gap: 8px;
          transition: transform 0.5s cubic-bezier(.2,.7,.1,1), opacity 0.4s;
        }
        .ac-submit[data-state="idle"] .ac-submit-loading,
        .ac-submit[data-state="idle"] .ac-submit-check { display: none; }
        .ac-submit[data-state="sending"] .ac-submit-text,
        .ac-submit[data-state="sending"] .ac-submit-check { display: none; }
        .ac-submit[data-state="sent"] .ac-submit-text,
        .ac-submit[data-state="sent"] .ac-submit-loading { display: none; }
        .ac-submit[data-state="sent"] {
          background: ${A_PALETTE.ink}; color: ${A_PALETTE.bg}; border-color: ${A_PALETTE.ink};
        }

        @keyframes ac-spin { from { transform: rotate(0); } to { transform: rotate(360deg); } }
        .ac-spinner { width: 14px; height: 14px; border: 2px solid currentColor; border-top-color: transparent; border-radius: 50%; animation: ac-spin 0.7s linear infinite; }

        @keyframes ac-check-draw {
          from { stroke-dashoffset: 28; }
          to { stroke-dashoffset: 0; }
        }
        .ac-check-path { stroke-dasharray: 28; stroke-dashoffset: 0; animation: ac-check-draw 0.45s cubic-bezier(.5,.1,.5,1) 0.1s both; }

        .ac-action {
          display: flex; align-items: center; gap: 14px;
          padding: 16px 18px;
          border: 1px solid ${A_PALETTE.rule};
          color: ${A_PALETTE.ink}; text-decoration: none;
          transition: all 0.3s cubic-bezier(.2,.7,.1,1);
          background: transparent;
          position: relative; overflow: hidden;
        }
        .ac-action::before {
          content: "";
          position: absolute; inset: 0;
          background: ${A_PALETTE.ink};
          transform: translateY(101%);
          transition: transform 0.45s cubic-bezier(.2,.7,.1,1);
          z-index: 0;
        }
        .ac-action > * { position: relative; z-index: 1; }
        .ac-action:hover { color: ${A_PALETTE.bg}; border-color: ${A_PALETTE.ink}; }
        .ac-action:hover::before { transform: translateY(0); }
        .ac-action .ac-icon { font-size: 18px; opacity: 0.8; }
        .ac-action .ac-label { font-family: var(--mono); font-size: 10px; letter-spacing: 0.14em; text-transform: uppercase; opacity: 0.7; margin-bottom: 4px; }
        .ac-action .ac-value { font-family: var(--display); font-size: 16px; letter-spacing: -0.005em; }
        .ac-action .ac-arr { margin-left: auto; opacity: 0.5; transition: transform 0.35s, opacity 0.35s; }
        .ac-action:hover .ac-arr { opacity: 1; transform: translateX(4px); }

        .ac-map-wrap { position: relative; }
        .ac-map-pin {
          position: absolute;
          left: 33.5%; top: 51%;
          transform: translate(-50%, -50%);
          z-index: 2;
          width: 56px; height: 56px;
          pointer-events: none;
        }
        .ac-map-pulse {
          position: absolute; inset: 0;
          border-radius: 50%;
          border: 2px solid ${A_PALETTE.ink};
          animation: ac-pulse 2.4s cubic-bezier(.4,0,.2,1) infinite;
        }
        @keyframes ac-pulse {
          0%   { transform: scale(0.35); opacity: 0.9; }
          70%  { transform: scale(1.4); opacity: 0; }
          100% { transform: scale(1.4); opacity: 0; }
        }
        .ac-map-overlay-btn {
          position: absolute; right: 18px; bottom: 18px; z-index: 3;
          padding: 12px 18px; background: ${A_PALETTE.ink}; color: ${A_PALETTE.bg};
          font-family: var(--mono); font-size: 11px; letter-spacing: 0.14em; text-transform: uppercase;
          text-decoration: none; border-radius: 999px;
          display: inline-flex; align-items: center; gap: 8px;
          transition: transform 0.3s cubic-bezier(.2,.7,.1,1), box-shadow 0.3s;
          box-shadow: 0 4px 16px rgba(0,0,0,0.18);
        }
        .ac-map-overlay-btn:hover { transform: translateY(-3px); box-shadow: 0 10px 26px rgba(0,0,0,0.28); }
        .ac-map-overlay-btn .arr { transition: transform 0.3s; }
        .ac-map-overlay-btn:hover .arr { transform: translateX(4px); }
      `}</style>

      <section className="va-container" style={{ padding: "100px 40px 60px" }}>
        <div className="va-eyebrow" style={{ marginBottom: 32 }}>
          {t.contact.title} · ANK {localTimeAnkara}
        </div>
        <h1 className="va-h1">
          {lang === "tr" ? <>Yeni bir <em>iş</em>,<br />bir <em>mekân</em>,<br />bir konuşma.</> : <>A new <em>project</em>,<br />a <em>space</em>,<br />a conversation.</>}
        </h1>
        <p className="va-lede" style={{ marginTop: 40, maxWidth: "48ch" }}>
          {lang === "tr"
            ? "Yazın, arayın, uğrayın. Genelde 24 saat içinde dönüş yapıyoruz."
            : "Write, call, drop by. We usually respond within 24 hours."}
        </p>
      </section>

      {/* Quick actions grid */}
      <section className="va-container" style={{ padding: "0 40px 40px" }}>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 12 }}>
          {actions.map((a) => (
            <a key={a.key} href={a.href} className="ac-action"
              target={a.key === "instagram" || a.key === "whatsapp" ? "_blank" : undefined}
              rel="noreferrer">
              <span className="ac-icon">{a.icon}</span>
              <div>
                <div className="ac-label">{a.label}</div>
                <div className="ac-value">{a.value}</div>
              </div>
              <span className="ac-arr">→</span>
            </a>
          ))}
        </div>
      </section>

      {/* Form + side info */}
      <section className="va-container" style={{ padding: "40px 40px 80px" }}>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1.4fr", gap: 80 }}>
          <div>
            <div className="va-meta" style={{ marginBottom: 18 }}>{lang === "tr" ? "Bilgi" : "Details"}</div>
            <dl style={{ margin: 0 }}>
              {[
                [t.contact.labels.address, window.CONTACT.address],
                [t.contact.labels.hours, t.contact.hours],
                [lang === "tr" ? "Konum" : "Location", "Kuzu Effect AVM · Oran"],
                [lang === "tr" ? "Çankaya · Ankara · TR" : "Çankaya · Ankara · TR", "39.8782° N · 32.8221° E"],
              ].map(([k, v], i) => (
                <div key={i} style={{ paddingTop: 18, paddingBottom: 18, borderTop: `1px solid ${A_PALETTE.rule}` }}>
                  <dt className="va-meta" style={{ marginBottom: 6 }}>{k}</dt>
                  <dd style={{ margin: 0, fontSize: 17, letterSpacing: "-0.01em", lineHeight: 1.4 }}>{v}</dd>
                </div>
              ))}
            </dl>
          </div>
          <div>
            {sent ? (
              <div style={{ paddingTop: 40 }}>
                <div style={{ display: "inline-flex", alignItems: "center", gap: 14, padding: "10px 16px", border: `1px solid ${A_PALETTE.ink}`, borderRadius: 999, marginBottom: 28 }}>
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                    <path className="ac-check-path" d="M 5 13 L 10 18 L 19 7" stroke={A_PALETTE.ink} strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                  <span className="va-meta">{lang === "tr" ? "GÖNDERİLDİ" : "SENT"}</span>
                </div>
                <div className="va-lede" style={{ marginBottom: 16 }}>{t.contact.form.thanks}</div>
                <div className="va-meta">
                  {lang === "tr"
                    ? `Mesajınız ${window.CONTACT.email} adresine iletildi.`
                    : `Your message has been sent to ${window.CONTACT.email}.`}
                </div>
              </div>
            ) : (
              <form onSubmit={onSubmit} style={{ display: "grid", gap: 32 }}>
                <div className="va-meta">{lang === "tr" ? "Yazın" : "Write"}</div>
                {["name", "email", "subject"].map(k => {
                  const filled = vals[k].length > 0;
                  const focused = focusKey === k;
                  return (
                    <div key={k} className="ac-input-wrap" data-active={filled || focused} data-focus={focused}>
                      <label htmlFor={`ac-${k}`}>{t.contact.form[k]}</label>
                      <input id={`ac-${k}`} required
                        type={k === "email" ? "email" : "text"}
                        value={vals[k]}
                        onChange={(e) => setVals(v => ({ ...v, [k]: e.target.value }))}
                        onFocus={() => setFocusKey(k)}
                        onBlur={() => setFocusKey(null)}
                        autoComplete="off"
                      />
                      <div className="ac-underline" />
                    </div>
                  );
                })}

                <div className="ac-input-wrap"
                  data-active={vals.message.length > 0 || focusKey === "message"}
                  data-focus={focusKey === "message"}
                  style={{ paddingBottom: 22 }}>
                  <label htmlFor="ac-message">{t.contact.form.message}</label>
                  <textarea id="ac-message" required rows="4"
                    value={vals.message}
                    onChange={(e) => setVals(v => ({ ...v, message: e.target.value.slice(0, 800) }))}
                    onFocus={() => setFocusKey("message")}
                    onBlur={() => setFocusKey(null)}
                  />
                  <div className="ac-underline" />
                  <div className="ac-counter">
                    {vals.message.length} / 800
                  </div>
                </div>

                <button type="submit" className="va-pill ac-submit"
                  data-state={sending ? "sending" : sent ? "sent" : "idle"}
                  disabled={sending}
                  style={{ justifySelf: "flex-start", marginTop: 4, minWidth: 180, justifyContent: "center" }}>
                  <span className="ac-submit-text">{t.contact.form.send} <span className="arr">→</span></span>
                  <span className="ac-submit-loading"><span className="ac-spinner" /> {lang === "tr" ? "Gönderiliyor" : "Sending"}</span>
                </button>
              </form>
            )}
          </div>
        </div>
      </section>

      {/* Interactive map */}
      <section className="va-container" style={{ padding: "20px 40px 40px" }}>
        <div className="va-meta" style={{ marginBottom: 14, display: "flex", justifyContent: "space-between", alignItems: "baseline" }}>
          <span>{lang === "tr" ? "Yerimiz" : "Where we are"}</span>
          <span style={{ opacity: 0.6 }}>{lang === "tr" ? "El çizimi · ölçeksiz" : "Hand drawn · not to scale"}</span>
        </div>
        <div className="ac-map-wrap"
          onMouseMove={(e) => {
            const r = e.currentTarget.getBoundingClientRect();
            const x = (e.clientX - r.left) / r.width;
            const y = (e.clientY - r.top) / r.height;
            // pin is at ~33.5%, 51% — only show pulse if cursor is reasonably near
            const d = Math.hypot(x - 0.335, y - 0.51);
            setMapPinHover(d < 0.18);
          }}
          onMouseLeave={() => setMapPinHover(false)}>
          {window.OfficeSketchMap ? (
            <window.OfficeSketchMap
              ink={A_PALETTE.ink}
              paper={A_PALETTE.paper}
              mid={A_PALETTE.mid}
              lang={lang}
              wordmark={A_PALETTE.wordmark}
            />
          ) : (
            <window.Placeholder slug="map" ratio="16/6" label="Kuzu Effect AVM · Oran · Çankaya" />
          )}
          <div className="ac-map-pin" style={{ opacity: mapPinHover ? 1 : 0.55, transition: "opacity 0.3s" }}>
            <div className="ac-map-pulse" />
          </div>
          <a className="ac-map-overlay-btn"
            href="https://maps.app.goo.gl/?q=Kuzu+Effect+AVM+Oran+Çankaya"
            target="_blank" rel="noreferrer">
            {lang === "tr" ? "Yol tarifi al" : "Get directions"} <span className="arr">→</span>
          </a>
        </div>
      </section>

      <AFooter t={t} setPage={setPage} lang={lang} />
    </div>
  );
}

function AFooter({ t, setPage, lang }) {
  return (
    <footer className="va-footer">
      <div className="va-container">
        <div style={{ display: "grid", gridTemplateColumns: "1fr auto", gap: 60, alignItems: "end", marginBottom: 60 }}>
          <div className="va-foot-h">
            {lang === "tr" ? <>Bir sonraki <em style={{ fontFamily: "var(--serif)", fontStyle: "italic" }}>mekân</em><br />birlikte.</> : <>The next <em style={{ fontFamily: "var(--serif)", fontStyle: "italic" }}>space</em>,<br />together.</>}
          </div>
          {window.BreathingFigure ? (
            <window.BreathingFigure
              src={window.__figureSrc || "assets/figures-charcoal.png"}
              height={180} opacity={0.88}
            />
          ) : (
            <img src={window.__figureSrc || "assets/figures-charcoal.png"} alt=""
              style={{ height: 180, opacity: 0.85 }} />
          )}
        </div>
        <div style={{ marginTop: 60, display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 24, paddingTop: 24, borderTop: `1px solid ${A_PALETTE.rule}` }}>
          <div>
            <div className="va-meta" style={{ marginBottom: 8 }}>{t.contact.labels.email}</div>
            <a href={`mailto:${window.CONTACT.email}`}>{window.CONTACT.email}</a>
          </div>
          <div>
            <div className="va-meta" style={{ marginBottom: 8 }}>{t.contact.labels.phone}</div>
            <div>{window.CONTACT.phone}</div>
          </div>
          <div>
            <div className="va-meta" style={{ marginBottom: 8 }}>{t.contact.labels.instagram}</div>
            <div>{window.CONTACT.instagram}</div>
          </div>
          <div>
            <div className="va-meta" style={{ marginBottom: 8 }}>{t.contact.labels.address}</div>
            <div style={{ fontSize: 14, lineHeight: 1.45 }}>{window.CONTACT.address}</div>
          </div>
        </div>
        <div style={{ marginTop: 32, display: "flex", justifyContent: "space-between", fontFamily: "var(--mono)", fontSize: 11, letterSpacing: "0.12em", textTransform: "uppercase", color: A_PALETTE.mid }}>
          <div>{t.footer.colophon}</div>
          <div>{window.CONTACT.domain}</div>
        </div>
      </div>
    </footer>
  );
}

function VariationA(props) {
  const { page, paletteKey, ...rest } = props;
  A_PALETTE = A_PALETTES[paletteKey] || A_PALETTES["cool-brown"];
  const palettes = A_PALETTE.placeholders;
  window.paletteFor = function (slug) {
    let h = 0;
    for (let i = 0; i < (slug || "").length; i++) h = (h * 31 + slug.charCodeAt(i)) >>> 0;
    return palettes[h % palettes.length];
  };
  // Figure colorway matching active palette
  window.__figureSrc = paletteKey === "stone" ? "assets/figures-charcoal.png"
    : paletteKey === "ocean" ? "assets/figures-midnight.png"
    : "assets/figures-sky.png";

  // Search overlay
  const [searchOpen, setSearchOpen] = React.useState(false);
  React.useEffect(() => {
    const onKey = (e) => {
      if ((e.metaKey || e.ctrlKey) && e.key === "k") {
        e.preventDefault();
        setSearchOpen(true);
      }
      if (e.key === "/" && document.activeElement && document.activeElement.tagName !== "INPUT" && document.activeElement.tagName !== "TEXTAREA") {
        e.preventDefault();
        setSearchOpen(true);
      }
    };
    const onOpen = () => setSearchOpen(true);
    window.addEventListener("keydown", onKey);
    window.addEventListener("va-open-search", onOpen);
    return () => {
      window.removeEventListener("keydown", onKey);
      window.removeEventListener("va-open-search", onOpen);
    };
  }, []);

  // 404 detection
  const validPages = ["index", "projects", "project", "shop", "playlist", "journal", "journal-post", "about", "contact"];
  const is404 = !validPages.includes(page.name);
  const isUnknownProject = page.name === "project" && !window.PROJECTS.find(p => p.slug === page.slug);
  const isUnknownJournal = page.name === "journal-post" && !(window.JOURNAL || []).find(p => p.slug === page.slug);
  const showNotFound = is404 || isUnknownProject || isUnknownJournal;

  return (
    <ALayout {...props}>
      <window.PageTransition pageKey={`${page.name}/${page.slug || ""}`} duration={380}>
        {showNotFound ? (
          <ANotFound {...rest} setPage={props.setPage} />
        ) : page.name === "index" ? (
          <AHome {...rest} setPage={props.setPage} />
        ) : page.name === "projects" ? (
          <AProjects {...rest} setPage={props.setPage} />
        ) : page.name === "project" && page.slug === "kei" && window.KeiProjectPage ? (
          <div style={{
            "--ink": A_PALETTE.ink, "--mid": A_PALETTE.mid, "--rule": A_PALETTE.rule,
            "--bg": A_PALETTE.bg, "--bg2": A_PALETTE.bg2,
          }}>
            <window.KeiProjectPage {...rest} setPage={props.setPage} palette={paletteKey} />
          </div>
        ) : page.name === "project" ? (
          <AProject slug={page.slug} {...rest} setPage={props.setPage} />
        ) : page.name === "about" ? (
          <AAbout {...rest} setPage={props.setPage} />
        ) : page.name === "shop" ? (
          <AShop {...rest} setPage={props.setPage} />
        ) : page.name === "playlist" ? (
          <APlaylist {...rest} setPage={props.setPage} />
        ) : page.name === "journal" ? (
          <AJournal {...rest} setPage={props.setPage} />
        ) : page.name === "journal-post" ? (
          <AJournalPost slug={page.slug} {...rest} setPage={props.setPage} />
        ) : page.name === "contact" ? (
          <AContact {...rest} setPage={props.setPage} />
        ) : null}
      </window.PageTransition>
      <ASearch open={searchOpen} onClose={() => setSearchOpen(false)} setPage={props.setPage} lang={rest.lang} />
    </ALayout>
  );
}

function TileOverlay({ project, index, lang }) {
  if (!project) return null;
  return (
    <React.Fragment>
      <div className="va-tile-corner">{String(index).padStart(2, "0")}</div>
      <div className="va-tile-overlay">
        <div className="ov-num">{lang === "tr" ? "PROJE" : "PROJECT"} {String(index).padStart(2, "0")}</div>
        <div className="ov-name">{project.name}</div>
        <div className="ov-meta">
          <span>{project.location}</span>
          <span>{project.category[lang]}</span>
          {project.area && <span>{project.area}</span>}
          <span>{project.year}</span>
        </div>
        <div className="ov-cta">{lang === "tr" ? "GÖR" : "VIEW"} →</div>
      </div>
    </React.Fragment>
  );
}
window.TileOverlay = TileOverlay;
