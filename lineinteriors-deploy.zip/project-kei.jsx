/* eslint-disable */
// Kei — custom editorial project page
// Uses real renders from assets/projects/kei + manifesto texts from the brief

function KeiProjectPage({ setPage, t, lang, palette }) {
  const KEI = window.KEI;
  const idx = window.PROJECTS.findIndex(p => p.slug === KEI.slug);
  const all = window.PROJECTS;
  const prev = all[(idx - 1 + all.length) % all.length];
  const next = all[(idx + 1) % all.length];

  // palette colors are already on document; we just use CSS classes from variation A
  // Strong dark + warm gravel palette per render mood
  return (
    <div className="va-anim kei-page">
      <style>{`
        .kei-page { color: var(--ink); }
        .kei-hero { position: relative; width: 100%; height: clamp(580px, 88vh, 1000px); overflow: hidden; }
        .kei-hero img { width: 100%; height: 100%; object-fit: cover; display: block; }
        .kei-hero-overlay {
          position: absolute; inset: 0;
          background: linear-gradient(180deg, rgba(0,0,0,0.10) 0%, rgba(0,0,0,0) 35%, rgba(0,0,0,0) 65%, rgba(0,0,0,0.45) 100%);
          pointer-events: none;
        }
        .kei-hero-meta {
          position: absolute; left: 40px; right: 40px; bottom: 36px;
          display: grid; grid-template-columns: 1fr auto; align-items: end; gap: 24px;
          color: #fbf6ec;
        }
        .kei-glyph {
          position: absolute; right: 56px; top: 56px;
          font-family: "Noto Serif JP", "Hiragino Mincho ProN", serif;
          font-size: clamp(72px, 9vw, 140px);
          line-height: 1; color: rgba(251, 246, 236, 0.92);
          letter-spacing: 0;
        }
        .kei-eyebrow {
          font-family: var(--mono); font-size: 11px; letter-spacing: 0.22em;
          text-transform: uppercase; opacity: 0.85;
        }
        .kei-title {
          font-family: var(--display); font-weight: 400;
          font-size: clamp(80px, 13vw, 220px); line-height: 0.86; letter-spacing: -0.045em;
          margin-top: 12px;
        }
        .kei-title em { font-family: "Noto Serif JP", "Instrument Serif", serif; font-style: normal; font-weight: 400; font-size: 0.55em; vertical-align: 0.4em; opacity: 0.9; margin-left: 0.18em; }
        .kei-hero-right { text-align: right; }
        .kei-hero-right .row { display: flex; gap: 24px; font-family: var(--mono); font-size: 11px; letter-spacing: 0.14em; text-transform: uppercase; }
        .kei-hero-right .row > div { text-align: left; }
        .kei-hero-right .k { opacity: 0.65; margin-bottom: 4px; }

        .kei-section { padding: 100px 40px; max-width: 1680px; margin: 0 auto; }
        .kei-section--tight { padding: 60px 40px; }
        .kei-rule { height: 1px; background: var(--rule); }

        .kei-quote {
          padding: 140px 40px;
          text-align: center;
        }
        .kei-quote .text {
          font-family: var(--serif); font-style: italic; font-weight: 400;
          font-size: clamp(28px, 3.6vw, 56px); line-height: 1.18; letter-spacing: -0.015em;
          max-width: 24ch; margin: 0 auto;
          white-space: pre-line;
        }
        .kei-quote .mono {
          font-family: var(--mono); font-size: 11px; letter-spacing: 0.22em;
          text-transform: uppercase; color: var(--mid); margin-top: 36px;
        }
        .kei-quote .ja {
          font-family: "Noto Serif JP", serif;
          font-size: 14px; letter-spacing: 0.2em; color: var(--mid);
          margin-top: 8px;
        }

        .kei-pair { display: grid; grid-template-columns: 1fr 1fr; gap: 24px; }
        .kei-pair img { width: 100%; height: 100%; object-fit: cover; aspect-ratio: 4/5; }

        .kei-full img { width: 100%; height: auto; display: block; }

        .kei-garden { display: grid; grid-template-columns: 0.9fr 1.1fr; gap: 64px; align-items: center; }
        .kei-garden img { width: 100%; aspect-ratio: 4/5; object-fit: cover; }
        .kei-garden .text { display: flex; flex-direction: column; gap: 24px; }
        .kei-h2 { font-family: var(--display); font-weight: 400; font-size: clamp(40px, 5.5vw, 88px); line-height: 0.96; letter-spacing: -0.035em; }
        .kei-h2 em { font-family: var(--serif); font-style: italic; }
        .kei-h2 .ja { display: block; font-family: "Noto Serif JP", serif; font-size: 0.32em; letter-spacing: 0.16em; color: var(--mid); margin-top: 18px; font-style: normal; }
        .kei-lede { font-family: var(--serif); font-size: clamp(20px, 1.5vw, 24px); line-height: 1.42; letter-spacing: -0.005em; max-width: 38ch; }

        .kei-column-wide { position: relative; }
        .kei-column-wide img { width: 100%; aspect-ratio: 16/8; object-fit: cover; }
        .kei-column-cap {
          position: absolute; left: 40px; bottom: 32px; color: #ece6d8;
          font-family: var(--mono); font-size: 11px; letter-spacing: 0.18em; text-transform: uppercase;
        }
        .kei-column-cap .ja {
          font-family: "Noto Serif JP", serif; font-size: 28px;
          letter-spacing: 0; margin-bottom: 8px; display: block; opacity: 0.92;
          text-transform: none;
        }

        .kei-grid-3 { display: grid; grid-template-columns: 1fr 1fr; gap: 24px; }
        .kei-grid-3 img { width: 100%; height: 100%; object-fit: cover; }

        .kei-side { display: grid; grid-template-columns: 1fr 1fr; gap: 24px; align-items: stretch; }
        .kei-side img { width: 100%; height: 100%; object-fit: cover; aspect-ratio: 4/5; }

        .kei-details {
          display: grid; grid-template-columns: 1fr 1fr; gap: 80px;
        }
        .kei-details dl { margin: 0; }
        .kei-details .row { display: flex; padding: 14px 0; border-top: 1px solid var(--rule); font-size: 14px; }
        .kei-details .row dt { font-family: var(--mono); font-size: 11px; letter-spacing: 0.12em; text-transform: uppercase; color: var(--mid); flex: 0 0 50%; }
        .kei-details .row dd { margin: 0; font-family: var(--display); letter-spacing: -0.005em; }

        .kei-plan { display: grid; grid-template-columns: 1fr 1fr; gap: 32px; align-items: end; }
        .kei-plan img { width: 100%; height: auto; background: #ece6d8; border: 1px solid var(--rule); }
        .kei-cap {
          font-family: var(--mono); font-size: 11px; letter-spacing: 0.14em;
          text-transform: uppercase; color: var(--mid); margin-top: 10px;
        }

        .kei-material { display: grid; grid-template-columns: 1.4fr 1fr; gap: 60px; align-items: center; }
        .kei-material img { width: 100%; aspect-ratio: 16/9; object-fit: cover; }

        .kei-pull {
          padding: 80px 40px;
          display: grid; grid-template-columns: 1fr 1fr; gap: 80px; align-items: center;
          max-width: 1680px; margin: 0 auto;
        }
        .kei-pull img { width: 100%; aspect-ratio: 4/5; object-fit: cover; }

        .kei-next-strip {
          padding: 80px 40px 60px; max-width: 1680px; margin: 0 auto;
          display: grid; grid-template-columns: 1fr 1fr; gap: 40px;
          border-top: 1px solid var(--rule);
        }
        .kei-next-strip a { cursor: pointer; }

        @media (max-width: 900px) {
          .kei-garden, .kei-grid-3, .kei-side, .kei-details, .kei-pair, .kei-plan, .kei-material, .kei-pull, .kei-next-strip {
            grid-template-columns: 1fr; gap: 32px;
          }
          .kei-section { padding: 60px 20px; }
        }
      `}</style>

      <section style={{ padding: "40px 40px 16px", maxWidth: 1680, margin: "0 auto" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline" }}>
          <a className="va-meta" style={{ cursor: "pointer" }} onClick={() => setPage({ name: "projects" })}>← {t.sections.index}</a>
          <div className="va-meta">{String(idx + 1).padStart(2, "0")} / {String(all.length).padStart(2, "0")}</div>
        </div>
      </section>

      {/* Hero */}
      <section className="kei-hero">
        <img src={KEI.images.hero} alt={KEI.name + " — hero"} />
        <div className="kei-hero-overlay" />
        <div className="kei-glyph">{KEI.ja}</div>
        <div className="kei-hero-meta">
          <div>
            <div className="kei-eyebrow">{lang === "tr" ? "Restoran · Pastane · Kavurmahane" : "Restaurant · Pâtisserie · Roastery"} — {KEI.year}</div>
            <div className="kei-title">{KEI.name}<em>{KEI.ja}</em></div>
          </div>
          <div className="kei-hero-right">
            <div className="row">
              <div><div className="k">{t.sections.location}</div>{KEI.location[lang]}</div>
              <div><div className="k">{t.sections.area}</div>{KEI.area}</div>
              <div><div className="k">{lang === "tr" ? "Kapasite" : "Capacity"}</div>{KEI.capacity[lang]}</div>
            </div>
          </div>
        </div>
      </section>

      {/* Manifesto quote */}
      <section className="kei-quote">
        <div className="kei-eyebrow" style={{ marginBottom: 32, color: "var(--mid)" }}>
          {lang === "tr" ? "Manifesto · 01" : "Manifesto · 01"}
        </div>
        <div className="text">{KEI.mottos.hero[lang]}</div>
        <div className="mono">— Kei, {KEI.year}</div>
      </section>

      {/* Pair: front umbrellas + terrace city */}
      <section className="kei-section kei-section--tight">
        <div className="kei-pair">
          <div>
            <img src={KEI.images.pair1[0]} alt="" />
            <div className="kei-cap">{lang === "tr" ? "Ön cephe · Bambu çatı" : "Front facade · Bamboo eaves"}</div>
          </div>
          <div>
            <img src={KEI.images.pair1[1]} alt="" />
            <div className="kei-cap">{lang === "tr" ? "Teras · Şehre açılan görüş" : "Terrace · City view"}</div>
          </div>
        </div>
      </section>

      {/* Boşluğun Bahçesi */}
      <section className="kei-section">
        <div className="kei-garden">
          <div>
            <img src={KEI.images.garden} alt="" />
          </div>
          <div className="text">
            <div className="kei-eyebrow" style={{ color: "var(--mid)" }}>
              02 — {KEI.mottos.garden.sub[lang]}
            </div>
            <h2 className="kei-h2">
              {lang === "tr"
                ? <>Boşluğun<br /><em>Bahçesi.</em></>
                : <>The Garden<br />of <em>Emptiness.</em></>}
              <span className="ja">間の庭 · Ma no Niwa</span>
            </h2>
            <p className="kei-lede">{KEI.mottos.garden.body[lang]}</p>
          </div>
        </div>
      </section>

      {/* Full bleed garden 2 */}
      <section className="kei-full">
        <img src={KEI.images.garden2} alt="" />
      </section>

      {/* Invitation */}
      <section className="kei-quote" style={{ padding: "120px 40px" }}>
        <div className="kei-eyebrow" style={{ marginBottom: 28, color: "var(--mid)" }}>
          03 — {KEI.mottos.invitation.title[lang]}
        </div>
        <div className="text">{KEI.mottos.invitation.body[lang]}</div>
      </section>

      {/* Kei column wide */}
      <section className="kei-column-wide">
        <img src={KEI.images.columnWide} alt="" />
        <div className="kei-column-cap">
          <span className="ja">系 kei</span>
          {lang === "tr" ? "Eksen kolonu · Reeded ahşap · Japon karakteri" : "Axis column · Reeded wood · Japanese character"}
        </div>
      </section>

      {/* Interior pair */}
      <section className="kei-section">
        <div className="kei-pair">
          <div><img src={KEI.images.interiorRow[0]} alt="" /></div>
          <div><img src={KEI.images.interiorRow[1]} alt="" /></div>
        </div>
      </section>

      {/* Full long table */}
      <section className="kei-full">
        <img src={KEI.images.longTable} alt="" />
      </section>

      {/* Pull quote in 2 cols with japan art */}
      <section className="kei-pull">
        <div>
          <div className="kei-eyebrow" style={{ color: "var(--mid)", marginBottom: 24 }}>04 — {lang === "tr" ? "Detay" : "Detail"}</div>
          <h2 className="kei-h2">
            {lang === "tr"
              ? <>Ağaç,<br /><em>taş,</em> kil<br />ve ışık.</>
              : <>Wood,<br /><em>stone,</em> clay<br />and light.</>}
          </h2>
          <p className="kei-lede" style={{ marginTop: 32 }}>
            {lang === "tr"
              ? "Reeded ahşap kolon, kararmış metal raflar, el yapımı seramik karo duvarlar ve dökme taş zemin — palet, mekânın sessizliğini taşıyan dürüst malzemelerden kuruldu."
              : "A reeded timber column, blackened metal shelving, hand-glazed ceramic tile walls and cast stone floors — the palette is built of honest materials that carry the room's silence."}
          </p>
        </div>
        <div>
          <img src={KEI.images.japanArt} alt="" />
        </div>
      </section>

      {/* Tile wall + bar detail */}
      <section className="kei-section">
        <div className="kei-pair">
          <div><img src={KEI.images.tileWall} alt="" style={{ aspectRatio: "1/1" }} /></div>
          <div><img src={KEI.images.barDetail} alt="" style={{ aspectRatio: "1/1" }} /></div>
        </div>
      </section>

      {/* Pastry counter full */}
      <section className="kei-full">
        <img src={KEI.images.pastry} alt="" />
      </section>

      {/* Material palette */}
      <section className="kei-section">
        <div className="kei-material">
          <img src={KEI.images.materials} alt="" />
          <div>
            <div className="kei-eyebrow" style={{ color: "var(--mid)", marginBottom: 24 }}>05 — {lang === "tr" ? "Malzeme paleti" : "Material palette"}</div>
            <h2 className="kei-h2" style={{ fontSize: "clamp(32px, 4vw, 56px)" }}>
              {lang === "tr"
                ? <>Trone · <em>Living</em> Ceramics</>
                : <>Trone · <em>Living</em> Ceramics</>}
            </h2>
            <p className="kei-lede" style={{ marginTop: 24 }}>
              {lang === "tr"
                ? "Soğuk koyu taşın, sıcak ahşabın ve dokunsal kil sırrının yan yana durduğu bir palet. Pürüzsüz değil; dokulu, gerçek."
                : "A palette where cool dark stone, warm timber and tactile glazed clay sit alongside one another. Not smooth — textured, real."}
            </p>
          </div>
        </div>
      </section>

      {/* Bathroom pair */}
      <section className="kei-section kei-section--tight">
        <div className="kei-pair">
          <div><img src={KEI.images.bathroom} alt="" style={{ aspectRatio: "3/4" }} /></div>
          <div><img src={KEI.images.wc} alt="" style={{ aspectRatio: "3/4" }} /></div>
        </div>
      </section>

      {/* Light detail full */}
      <section className="kei-full">
        <img src={KEI.images.lightDetail} alt="" />
      </section>

      {/* Outdoor pair */}
      <section className="kei-section">
        <div className="kei-pair">
          <div>
            <img src={KEI.images.terrace} alt="" />
            <div className="kei-cap">{lang === "tr" ? "Açık alan · Bambu gölgesi" : "Outdoor · Bamboo shade"}</div>
          </div>
          <div>
            <img src={KEI.images.windowSeating} alt="" />
            <div className="kei-cap">{lang === "tr" ? "Cam kenarı · Şehir manzarası" : "By the glass · City view"}</div>
          </div>
        </div>
      </section>

      {/* Long terrace full */}
      <section className="kei-full">
        <img src={KEI.images.longTerrace} alt="" />
      </section>

      {/* Plans */}
      <section className="kei-section">
        <div className="kei-eyebrow" style={{ color: "var(--mid)", marginBottom: 32 }}>06 — {lang === "tr" ? "Çizimler" : "Drawings"}</div>
        <div className="kei-plan">
          <div>
            <img src={KEI.images.plan} alt="Kei plan" />
            <div className="kei-cap">{lang === "tr" ? "Plan · 1/100 · 220 m²" : "Plan · 1/100 · 220 m²"}</div>
          </div>
          <div>
            <img src={KEI.images.section} alt="Kei sections" />
            <div className="kei-cap">{lang === "tr" ? "AA' ve BB' kesitler" : "Sections AA' & BB'"}</div>
          </div>
        </div>
      </section>

      {/* Bubble + breakdown */}
      <section className="kei-section">
        <div className="kei-details">
          <div>
            <img src={KEI.images.bubble} alt="" style={{ width: "100%", aspectRatio: "1/1", objectFit: "cover", background: "#ece6d8", border: "1px solid var(--rule)" }} />
            <div className="kei-cap" style={{ marginTop: 10 }}>{lang === "tr" ? "İlişki şeması · İç & dış mekân" : "Programme diagram · Interior & exterior"}</div>
          </div>
          <div>
            <div className="kei-eyebrow" style={{ color: "var(--mid)", marginBottom: 16 }}>07 — {lang === "tr" ? "Alan dağılımı" : "Area breakdown"}</div>
            <dl style={{ margin: 0 }}>
              {KEI.breakdown[lang].map(([k, v], i) => (
                <div className="row" key={i}>
                  <dt>{k}</dt>
                  <dd>{v}</dd>
                </div>
              ))}
              <div className="row" style={{ borderTopWidth: 2 }}>
                <dt style={{ fontWeight: 500, color: "var(--ink)" }}>{lang === "tr" ? "Toplam" : "Total"}</dt>
                <dd style={{ fontSize: 18 }}>{KEI.area}</dd>
              </div>
            </dl>
          </div>
        </div>
      </section>

      {/* Info */}
      <section className="kei-section">
        <div className="kei-details">
          <div>
            <div className="kei-eyebrow" style={{ color: "var(--mid)", marginBottom: 16 }}>{t.sections.info}</div>
            <dl style={{ margin: 0 }}>
              {[
                [t.sections.year, KEI.year],
                [t.sections.location, KEI.location[lang]],
                [t.sections.category, lang === "tr" ? "Restoran" : "Restaurant"],
                [t.sections.area, KEI.area],
                [lang === "tr" ? "Kapasite" : "Capacity", KEI.capacity[lang]],
                [t.sections.client, KEI.client],
                [t.sections.program, KEI.program[lang]],
                [t.sections.status, KEI.status[lang]],
              ].map(([k, v], i) => (
                <div className="row" key={i}><dt>{k}</dt><dd>{v}</dd></div>
              ))}
            </dl>
          </div>
          <div>
            <h2 className="kei-h2">
              {lang === "tr" ? <>Bir nefes,<br /><em>tutulmuş.</em></> : <>A breath,<br /><em>held still.</em></>}
            </h2>
            <p className="kei-lede" style={{ marginTop: 24 }}>
              {lang === "tr"
                ? "Kei, Ankara Merkez'de bir karma program: pastane, kahve kavurma, mutfak ve bambu bahçesi. Dış ile iç, doğa ile yapı — biri diğerine üstün gelmeden, sessizce bir arada."
                : "Kei is a mixed programme in central Ankara: a pâtisserie, coffee roastery, kitchen and bamboo garden. Inside and outside, nature and structure — quietly together, neither dominant."}
            </p>
          </div>
        </div>
      </section>

      {/* Next / Prev */}
      <section className="kei-next-strip">
        <a onClick={() => setPage({ name: "project", slug: prev.slug })}>
          <div className="kei-eyebrow" style={{ color: "var(--mid)", marginBottom: 12 }}>← {t.sections.prev}</div>
          <div style={{ fontFamily: "var(--display)", fontSize: 32, letterSpacing: "-0.02em" }}>{prev.name}</div>
          <div className="kei-cap" style={{ marginTop: 8 }}>{prev.location} · {prev.year}</div>
        </a>
        <a style={{ textAlign: "right" }} onClick={() => setPage({ name: "project", slug: next.slug })}>
          <div className="kei-eyebrow" style={{ color: "var(--mid)", marginBottom: 12 }}>{t.sections.next} →</div>
          <div style={{ fontFamily: "var(--display)", fontSize: 32, letterSpacing: "-0.02em" }}>{next.name}</div>
          <div className="kei-cap" style={{ marginTop: 8 }}>{next.location} · {next.year}</div>
        </a>
      </section>
    </div>
  );
}

window.KeiProjectPage = KeiProjectPage;
