/* eslint-disable */
// Project data & bilingual copy for Line Interiors

const PROJECTS = [
  { slug: "input", name: "Input", year: 2019, location: "Ankara", category: { tr: "Ofis", en: "Office" }, area: "320 m²", client: "Input Studio", program: { tr: "Açık ofis, toplantı, sosyal alan", en: "Open office, meeting, social" } },
  { slug: "line-bulvar-loft", name: "Line Bulvar Loft", year: 2019, location: "Ankara", category: { tr: "Konut", en: "Residential" }, area: "180 m²", client: "Özel", program: { tr: "Loft konut", en: "Loft residence" } },
  { slug: "lets-bake-artisan", name: "Lets Bake Artisan", year: 2020, location: "Ankara", category: { tr: "Kafe", en: "Café" }, area: "210 m²", client: "Lets Bake", program: { tr: "Fırın, kafe, satış", en: "Bakery, café, retail" } },
  { slug: "line-maidan", name: "Line Maidan", year: 2022, location: "Ankara", category: { tr: "Karma", en: "Mixed-use" }, area: "640 m²", client: "Line", program: { tr: "Showroom, ofis, atölye", en: "Showroom, office, workshop" } },
  { slug: "quick-china-kapadokya", name: "Quick China", year: 2022, location: "Kapadokya", category: { tr: "Restoran", en: "Restaurant" }, area: "260 m²", client: "Quick China", program: { tr: "Restoran ve mutfak", en: "Restaurant & kitchen" } },
  { slug: "emser-mutfak-kapadokya", name: "Emser Mutfak", year: 2022, location: "Kapadokya", category: { tr: "Mağaza", en: "Retail" }, area: "180 m²", client: "Emser", program: { tr: "Mutfak showroom", en: "Kitchen showroom" } },
  { slug: "kayakapi-hotel", name: "Kayakapı Hotel", year: 2022, location: "Kapadokya", category: { tr: "Konaklama", en: "Hospitality" }, area: "1.450 m²", client: "Kayakapı", program: { tr: "Butik otel, restoran, spa", en: "Boutique hotel, restaurant, spa" } },
  { slug: "demars-holding", name: "Demars Holding", year: 2022, location: "Ankara", category: { tr: "Ofis", en: "Office" }, area: "780 m²", client: "Demars", program: { tr: "Kurumsal merkez", en: "HQ office" } },
  { slug: "line-roastery", name: "Line Roastery", year: 2023, location: "Ankara", category: { tr: "Kafe", en: "Café" }, area: "240 m²", client: "Line", program: { tr: "Kahve kavurma, kafe", en: "Roastery, café" } },
  { slug: "sur-balik-ankara", name: "Sur Balık", year: 2023, location: "Ankara", category: { tr: "Restoran", en: "Restaurant" }, area: "520 m²", client: "Sur Balık", program: { tr: "Balık restoranı", en: "Seafood restaurant" } },
  { slug: "if-sokak-tunus", name: "If Sokak Tunus", year: 2023, location: "Ankara", category: { tr: "Karma", en: "Mixed-use" }, area: "1.100 m²", client: "If Sokak", program: { tr: "Sokak konsepti, F&B", en: "Street concept, F&B" } },
  { slug: "if-sokak-tunus-ofis", name: "If Sokak Tunus Ofis", year: 2023, location: "Ankara", category: { tr: "Ofis", en: "Office" }, area: "260 m²", client: "If Sokak", program: { tr: "Yönetim ofisi", en: "Management office" } },
  { slug: "alo-studio", name: "a'lo studio", year: 2023, location: "Ankara", category: { tr: "Mağaza", en: "Retail" }, area: "140 m²", client: "a'lo", program: { tr: "Konsept mağaza", en: "Concept store" } },
  { slug: "gokturk-deri-atolyesi", name: "Göktürk Deri Atölyesi", year: 2023, location: "Göktürk, İstanbul", category: { tr: "Atölye", en: "Workshop" }, area: "320 m²", client: "Özel", program: { tr: "Deri üretim atölyesi ve showroom", en: "Leather workshop and showroom" } },
  { slug: "koroglu-beytepe", name: "Köroğlu Beytepe", year: 2024, location: "Ankara", category: { tr: "Konut", en: "Residential" }, area: "8.400 m²", client: "Köroğlu", program: { tr: "Konut projesi", en: "Residential development" } },
  { slug: "koroglu-satis-ofisi", name: "Köroğlu Satış Ofisi", year: 2024, location: "Beytepe, Ankara", category: { tr: "Ofis", en: "Office" }, area: "190 m²", client: "Köroğlu", program: { tr: "Satış ofisi", en: "Sales office" } },
  { slug: "koroglu-makam-odasi", name: "Köroğlu Makam Odası", year: 2024, location: "Beytepe, Ankara", category: { tr: "Ofis", en: "Office" }, area: "85 m²", client: "Köroğlu", program: { tr: "Yönetici ofisi", en: "Executive office" } },
  { slug: "ayranci-daire", name: "Ayrancı Daire Renovasyon", year: 2024, location: "Ayrancı, Ankara", category: { tr: "Konut", en: "Residential" }, area: "165 m²", client: "Özel", program: { tr: "Daire renovasyonu", en: "Apartment renovation" } },
  { slug: "vaa-coffee", name: "Vaa Coffee", year: 2024, location: "İstanbul", category: { tr: "Kafe", en: "Café" }, area: "120 m²", client: "Vaa", program: { tr: "Specialty kahve", en: "Specialty coffee" } },
  { slug: "grond-coffee", name: "Grond Coffee", year: 2024, location: "Ankara", category: { tr: "Kafe", en: "Café" }, area: "95 m²", client: "Grond", program: { tr: "Kahve dükkanı", en: "Coffee shop" } },
  { slug: "noon-coffee", name: "Noon Coffee", year: 2025, location: "Ankara", category: { tr: "Kafe", en: "Café" }, area: "110 m²", client: "Noon", program: { tr: "Kahve, brunch", en: "Coffee, brunch" } },
  { slug: "line-bilkent", name: "Line Bilkent", year: 2025, location: "Ankara", category: { tr: "Karma", en: "Mixed-use" }, area: "420 m²", client: "Line", program: { tr: "Stüdyo, showroom", en: "Studio, showroom" } },
  { slug: "an-headquarter", name: "Ân Headquarter", year: 2025, location: "Ankara", category: { tr: "Ofis", en: "Office" }, area: "560 m²", client: "Ân", program: { tr: "Marka merkezi", en: "Brand HQ" } },
  { slug: "an-meze", name: "Ân Meze", year: 2025, location: "Ankara", category: { tr: "Restoran", en: "Restaurant" }, area: "320 m²", client: "Ân", program: { tr: "Meze restoranı", en: "Meze restaurant" } },
  { slug: "koroglu-patisserie", name: "Köroğlu Beytepe Patisserie", year: 2025, location: "Beytepe, Ankara", category: { tr: "Kafe", en: "Café" }, area: "180 m²", client: "Köroğlu", program: { tr: "Pastane ve satış alanı", en: "Patisserie and retail" } },
  { slug: "oran-terasevler", name: "Oran Terasevler Daire Renovasyon", year: 2025, location: "Oran, Ankara", category: { tr: "Konut", en: "Residential" }, area: "220 m²", client: "Özel", program: { tr: "Teras daire renovasyonu", en: "Terrace apartment renovation" } },
  { slug: "an-lokal-windy", name: "Ân Lokal Windy", year: 2026, location: "Ankara", category: { tr: "Restoran", en: "Restaurant" }, area: "240 m²", client: "Ân", program: { tr: "Lokanta", en: "Local diner" } },
  { slug: "an-pizza-windy", name: "Ân Pizza Windy", year: 2026, location: "Ankara", category: { tr: "Restoran", en: "Restaurant" }, area: "180 m²", client: "Ân", program: { tr: "Pizza konsepti", en: "Pizza concept" } },
  { slug: "an-dondurma-windy", name: "Ân Dondurma Windy", year: 2026, location: "Ankara", category: { tr: "Mağaza", en: "Retail" }, area: "60 m²", client: "Ân", program: { tr: "Dondurma satış", en: "Ice cream parlor" } },
  { slug: "the-burger-shop", name: "The Burger Shop", year: 2026, location: "Merkez, Ankara", category: { tr: "Restoran", en: "Restaurant" }, area: "210 m²", client: "TBS", program: { tr: "Burger restoranı", en: "Burger restaurant" } },
  { slug: "kei", name: "Kei", year: 2026, location: "Merkez, Ankara", category: { tr: "Restoran", en: "Restaurant" }, area: "340 m²", client: "Kei", program: { tr: "Japon mutfağı", en: "Japanese cuisine" } },
  { slug: "lillian-flower-shop", name: "Lillian Flower Shop", year: 2026, location: "Merkez, Ankara", category: { tr: "Mağaza", en: "Retail" }, area: "120 m²", client: "Lillian", program: { tr: "Çiçekçi konsept mağaza", en: "Florist concept shop" } },
  { slug: "uskup-cadde-daire", name: "Üsküp Cadde Daire Renovasyon", year: 2026, location: "Çankaya, Ankara", category: { tr: "Konut", en: "Residential" }, area: "190 m²", client: "Özel", program: { tr: "Daire renovasyonu", en: "Apartment renovation" } },
];

// Palette index for placeholder swatches — sky-led tones on cool brown ground
const PALETTES = [
  ["#c7d2dd", "#5a4646"],   // clear sky → muted brown
  ["#dbe2eb", "#342626"],   // pale sky → cool brown
  ["#a8b6c4", "#1c1414"],   // deeper sky → deep brown
  ["#e4ebf1", "#473535"],   // very pale sky → soft brown
  ["#b8c5d1", "#342626"],   // sky → cool brown
  ["#9aaab9", "#2a1e1e"],   // saturated sky → deep brown
  ["#cdd6df", "#3f2e2e"],   // sky → warm brown
  ["#c7d2dd", "#2a1e1e"],   // clear sky → deep brown
];

function paletteFor(slug) {
  let h = 0;
  for (let i = 0; i < slug.length; i++) h = (h * 31 + slug.charCodeAt(i)) >>> 0;
  return PALETTES[h % PALETTES.length];
}

const COPY = {
  tr: {
    nav: { index: "Anasayfa", projects: "İşler", shop: "Store", playlist: "Playlist", about: "Stüdyo", contact: "İletişim", journal: "Günlük" },
    marquee: ["Mekân, kullanıldığında değer kazanır", "Detay süs değil, taahhüt", "İç mimarlık · Uygulama · Branding", "Ankara · 2017—2026", "27+ tamamlanmış proje", "Konaklama · F&B · Konut · Retail"],
    press: {
      title: "Basın & Ödüller",
      items: [
        { source: "ArchDaily", pub: "Mart 2025", title: "Ân Headquarter ile çağdaş Türk mimarlığında bir okuma", url: "#" },
        { source: "Maison Française", pub: "Eylül 2024", title: "Köroğlu Beytepe: Konut tasarımında sessiz bir manifesto", url: "#" },
        { source: "Designboom", pub: "Mayıs 2024", title: "Kayakapı Hotel — Kapadokya'nın taşıyla buluşmak", url: "#" },
        { source: "Wallpaper*", pub: "Ocak 2024", title: "Line Roastery: Ankara'nın yeni kahve mekânı", url: "#" },
        { source: "ICON Magazine", pub: "Kasım 2023", title: "If Sokak Tunus: Bir sokak konseptinin yeniden okunması", url: "#" },
        { source: "Türkiye Tasarım Vakfı", pub: "2023", title: "Yılın İç Mimarlık Stüdyosu — Finalist", url: "#" },
        { source: "EMU Architecture", pub: "2022", title: "Genç Ofisler: Line Interiors", url: "#" },
      ],
    },
    team: {
      title: "Ekip",
      lede: "Stüdyo, küçük bir ekiple ölçek bağımsız çalışıyor.",
      members: [
        { name: "Berke Şenkardeş", role: "Kurucu · İç Mimar", since: 2017 },
        { name: "Ekin Demir", role: "İç Mimar · Proje Yöneticisi", since: 2021 },
        { name: "Selin Aydın", role: "İç Mimar · Branding", since: 2022 },
        { name: "Cemre Yıldız", role: "Şantiye Şefi · Uygulama", since: 2020 },
        { name: "Toprak Eren", role: "Mobilya Tasarımı", since: 2023 },
      ],
    },
    hero: {
      eyebrow: "İç Mimarlık Stüdyosu — Ankara",
      title: ["Mekân,", "kullanıldığında", "değer kazanır."],
      lede: "Line Interiors, 2017'den bu yana Ankara merkezli; konut, konaklama, perakende ve yeme-içme projelerinde tasarım ve uygulamayı tek elden yürüten bir iç mimarlık stüdyosudur. Aynı disiplinle marka kimliği üretimini de yürütüyoruz.",
      cta: "Seçili işleri gör",
    },
    sections: {
      featured: "Seçili işler",
      all: "Tüm işler",
      services: "Hizmetler",
      approach: "Yaklaşım",
      studio: "Stüdyo hakkında",
      info: "Bilgi",
      next: "Sonraki proje",
      prev: "Önceki proje",
      index: "Dizin",
      year: "Yıl",
      location: "Konum",
      area: "Alan",
      category: "Tip",
      client: "İşveren",
      program: "Program",
      status: "Durum",
      completed: "Tamamlandı",
      ongoing: "Devam ediyor",
    },
    manifesto: {
      title: "Yaklaşım",
      body: "Tasarımı bir ifade değil bir karşılık olarak anlıyoruz. Her proje yere, programa ve onu kullanacak insana ait özel sorularla başlar; cevaplar malzemenin, ışığın ve oranın diliyle yazılır. Detay bizim için süs değil, mekânın nasıl yaşlanacağına dair bir taahhüttür.",
    },
    services: [
      { t: "İç Mimarlık", d: "Konseptten teslime tam tasarım — konut, konaklama, perakende, ofis ve F&B." },
      { t: "Uygulama", d: "Şantiye yönetimi, taşeron koordinasyonu, bütçe ve zaman çizelgesi." },
      { t: "Marka Kimliği", d: "Mekânla aynı dili konuşan logo, tipografi, basılı materyal ve dijital sistemler." },
      { t: "Mobilya Tasarımı", d: "Projeye özel sabit ve hareketli mobilya, üretim ortağı koordinasyonu." },
    ],
    about: {
      title: "Stüdyo",
      paras: [
        "Line Interiors, 2017 yılında Ankara'da kuruldu. Konut ölçeğinden konaklama ve karma kullanım projelerine kadar, ölçek bağımsız aynı dikkatle çalışıyoruz.",
        "Tasarımın bir uygulama disiplini olduğuna inanıyoruz. Bu nedenle stüdyomuz, projeyi konsept aşamasından şantiyenin son gününe kadar tek bir ekiple yürütür. Marka kimliği danışmanlığını da bu bütünün ayrılmaz bir parçası olarak sunuyoruz.",
        "Bugün stüdyo; konaklama, F&B, perakende ve konut alanlarında ulusal ve uluslararası işverenlerle çalışmaktadır.",
      ],
      facts: [
        ["Kuruluş", "2017"],
        ["Merkez", "Çankaya, Ankara"],
        ["Tamamlanan iş", "27+"],
        ["Disiplin", "İç mimarlık · Uygulama · Branding"],
      ],
    },
    contact: {
      title: "İletişim",
      lead: "Yeni bir iş, bir mekân ya da yalnızca bir konuşma için. Yazın, arayın, uğrayın.",
      labels: { address: "Adres", phone: "Telefon", email: "E-posta", instagram: "Instagram", hours: "Çalışma saatleri" },
      hours: "Pzt — Cum · 09:30 — 18:30",
      form: { name: "Ad Soyad", email: "E-posta", subject: "Konu", message: "Mesaj", send: "Gönder", thanks: "Teşekkürler. En kısa sürede dönüş yapacağız." },
    },
    footer: {
      tagline: "Mekânın diline çevrilmiş tasarım.",
      colophon: "© 2017—2026 Line Interiors. Tüm hakları saklıdır.",
      built: "Stüdyo Ankara'da kuruludur.",
    },
  },
  en: {
    nav: { index: "Index", projects: "Works", shop: "Store", playlist: "Playlist", about: "Studio", contact: "Contact", journal: "Journal" },
    marquee: ["Space gains its value in use", "Detail is a promise, not ornament", "Interior · Execution · Branding", "Ankara · since 2017", "27+ completed projects", "Hospitality · F&B · Residential · Retail"],
    press: {
      title: "Press & Awards",
      items: [
        { source: "ArchDaily", pub: "March 2025", title: "A reading of contemporary Turkish architecture through Ân Headquarter", url: "#" },
        { source: "Maison Française", pub: "September 2024", title: "Köroğlu Beytepe: A quiet manifesto in residential design", url: "#" },
        { source: "Designboom", pub: "May 2024", title: "Kayakapı Hotel — meeting the stone of Cappadocia", url: "#" },
        { source: "Wallpaper*", pub: "January 2024", title: "Line Roastery: Ankara's new coffee place", url: "#" },
        { source: "ICON Magazine", pub: "November 2023", title: "If Sokak Tunus: a re-reading of a street concept", url: "#" },
        { source: "Turkey Design Foundation", pub: "2023", title: "Interior Studio of the Year — Finalist", url: "#" },
        { source: "EMU Architecture", pub: "2022", title: "Young Offices: Line Interiors", url: "#" },
      ],
    },
    team: {
      title: "Team",
      lede: "The studio works with a small team, regardless of project scale.",
      members: [
        { name: "Berke Şenkardeş", role: "Founder · Interior Architect", since: 2017 },
        { name: "Ekin Demir", role: "Interior Architect · Project Lead", since: 2021 },
        { name: "Selin Aydın", role: "Interior Architect · Branding", since: 2022 },
        { name: "Cemre Yıldız", role: "Site Manager · Execution", since: 2020 },
        { name: "Toprak Eren", role: "Furniture Design", since: 2023 },
      ],
    },
    hero: {
      eyebrow: "Interior Design Studio — Ankara",
      title: ["Space gains", "its value", "in use."],
      lede: "Founded in 2017, Line Interiors is an Ankara-based interior design studio working across residential, hospitality, retail and F&B — handling design and execution end-to-end. We also deliver brand identity within the same practice.",
      cta: "See selected works",
    },
    sections: {
      featured: "Selected works",
      all: "All works",
      services: "Services",
      approach: "Approach",
      studio: "About the studio",
      info: "Information",
      next: "Next project",
      prev: "Previous project",
      index: "Index",
      year: "Year",
      location: "Location",
      area: "Area",
      category: "Type",
      client: "Client",
      program: "Programme",
      status: "Status",
      completed: "Completed",
      ongoing: "Ongoing",
    },
    manifesto: {
      title: "Approach",
      body: "We understand design as a response, not an expression. Each project begins with questions specific to its site, programme and user; the answers are written in the language of material, light and proportion. Detail, for us, is not ornament — it is a promise about how a space will age.",
    },
    services: [
      { t: "Interior Design", d: "Full design from concept to handover — residential, hospitality, retail, office and F&B." },
      { t: "Execution", d: "Site supervision, contractor coordination, budget and schedule." },
      { t: "Brand Identity", d: "Logo, typography, print and digital systems that speak the same language as the space." },
      { t: "Furniture Design", d: "Bespoke fixed and loose furniture, coordinated with our production partners." },
    ],
    about: {
      title: "Studio",
      paras: [
        "Line Interiors was founded in Ankara in 2017. From residential to hospitality and mixed-use, we work with the same attention regardless of scale.",
        "We believe design is a discipline of making. Our studio carries a project from concept to the last day on site with a single team. Brand identity consulting is offered as an inseparable part of this whole.",
        "Today the studio works with national and international clients in hospitality, F&B, retail and residential.",
      ],
      facts: [
        ["Founded", "2017"],
        ["Based in", "Çankaya, Ankara"],
        ["Completed", "27+"],
        ["Disciplines", "Interior · Execution · Branding"],
      ],
    },
    contact: {
      title: "Contact",
      lead: "For a new project, a space, or just a conversation. Write, call, drop by.",
      labels: { address: "Address", phone: "Phone", email: "Email", instagram: "Instagram", hours: "Hours" },
      hours: "Mon — Fri · 09:30 — 18:30",
      form: { name: "Full name", email: "Email", subject: "Subject", message: "Message", send: "Send", thanks: "Thank you. We'll get back shortly." },
    },
    footer: {
      tagline: "Design translated into the language of space.",
      colophon: "© 2017—2026 Line Interiors. All rights reserved.",
      built: "Studio is based in Ankara.",
    },
  },
};

const CONTACT = {
  address: "Kuzu Effect AVM, Oran, Zülfü Tiğrel Caddesi, Çankaya / Ankara",
  phone: "+90 530 492 20 90",
  email: "hello@lineinterior.co",
  instagram: "@__lineinterior",
  domain: "lineinterior.co",
};

// Furniture pieces — designed for projects, available as bespoke / commission
// fabrics / finishes are presented as selectable swatches in the store
const FURNITURE = [
  {
    slug: "kei-stool", name: "Kei Stool", project: "kei", year: 2026,
    type: { tr: "Tabure", en: "Stool" },
    materials: { tr: "Reeded ahşap · Kararmış pirinç", en: "Reeded oak · Blackened brass" },
    dim: "Ø 38 × 74 h cm",
    edition: { tr: "Stüdyo edisyonu", en: "Studio edition" },
    finishes: [
      { name: { tr: "Tütsülenmiş meşe", en: "Smoked oak" }, swatch: "#4a3825" },
      { name: { tr: "Doğal meşe", en: "Natural oak" }, swatch: "#c4a880" },
      { name: { tr: "Kararmış meşe", en: "Blackened oak" }, swatch: "#1f1a16" },
      { name: { tr: "Tütsülenmiş ceviz", en: "Smoked walnut" }, swatch: "#3a2a20" },
    ],
  },
  {
    slug: "ma-bench", name: "Ma Bench", project: "kei", year: 2026,
    type: { tr: "Bank", en: "Bench" },
    materials: { tr: "Masif ceviz · Pamuk dolgu", en: "Solid walnut · Cotton fill" },
    dim: "180 × 42 × 46 h cm",
    edition: { tr: "Sipariş üzerine", en: "Made to order" },
    fabrics: [
      { name: { tr: "Saman bouclé", en: "Straw bouclé" }, swatch: "#cdb98c" },
      { name: { tr: "Tütsülü pamuk", en: "Smoke cotton" }, swatch: "#7e7770" },
      { name: { tr: "Bone bouclé", en: "Bone bouclé" }, swatch: "#e9dfcf" },
      { name: { tr: "Charcoal yün", en: "Charcoal wool" }, swatch: "#3a3a3c" },
    ],
    finishes: [
      { name: { tr: "Doğal ceviz", en: "Natural walnut" }, swatch: "#6b4a32" },
      { name: { tr: "Tütsülenmiş ceviz", en: "Smoked walnut" }, swatch: "#3a2a20" },
    ],
  },
  {
    slug: "an-lounge", name: "Ân Lounge", project: "an-headquarter", year: 2025,
    type: { tr: "Koltuk", en: "Lounge chair" },
    materials: { tr: "Bouclé yün · Tütsülenmiş meşe", en: "Bouclé wool · Smoked oak" },
    dim: "76 × 82 × 78 h cm",
    edition: { tr: "Edisyon 12", en: "Edition of 12" },
    fabrics: [
      { name: { tr: "Krem bouclé", en: "Cream bouclé" }, swatch: "#e8dcc5" },
      { name: { tr: "Çakıl bouclé", en: "Pebble bouclé" }, swatch: "#a39785" },
      { name: { tr: "Terracotta yün", en: "Terracotta wool" }, swatch: "#a05a3e" },
      { name: { tr: "Gece bouclé", en: "Midnight bouclé" }, swatch: "#22282c" },
      { name: { tr: "Adaçayı yün", en: "Sage wool" }, swatch: "#7a8068" },
    ],
    finishes: [
      { name: { tr: "Tütsülenmiş meşe", en: "Smoked oak" }, swatch: "#4a3825" },
      { name: { tr: "Beyaz yağlı meşe", en: "White-oiled oak" }, swatch: "#d6c7ac" },
    ],
  },
  {
    slug: "line-coffee-table", name: "Line Coffee Table", project: "line-roastery", year: 2024,
    type: { tr: "Sehpa", en: "Coffee table" },
    materials: { tr: "Travertin · Mat pirinç", en: "Travertine · Matte brass" },
    dim: "120 × 60 × 36 h cm",
    edition: { tr: "Stüdyo edisyonu", en: "Studio edition" },
    finishes: [
      { name: { tr: "Roma travertini", en: "Roman travertine" }, swatch: "#d4c4a8" },
      { name: { tr: "Klasik travertin", en: "Classic travertine" }, swatch: "#b89e7a" },
      { name: { tr: "Tütsülü travertin", en: "Smoked travertine" }, swatch: "#5e4a36" },
      { name: { tr: "Carrara mermer", en: "Carrara marble" }, swatch: "#ebe6da" },
    ],
  },
  {
    slug: "kayakapi-armchair", name: "Kayakapı Armchair", project: "kayakapi-hotel", year: 2022,
    type: { tr: "Berjer", en: "Armchair" },
    materials: { tr: "El dokuma kilim · Ham deri", en: "Hand-woven kilim · Natural leather" },
    dim: "82 × 86 × 84 h cm",
    edition: { tr: "Sipariş üzerine", en: "Made to order" },
    fabrics: [
      { name: { tr: "Toprak kilim", en: "Earth kilim" }, swatch: "#9a6b48" },
      { name: { tr: "Çay kilim", en: "Tea kilim" }, swatch: "#a08956" },
      { name: { tr: "Antrasit kilim", en: "Anthracite kilim" }, swatch: "#3d3530" },
      { name: { tr: "Krem & terracotta", en: "Cream & terracotta" }, swatch: "#e0c4a0" },
    ],
    finishes: [
      { name: { tr: "Naturel saraç deri", en: "Natural saddle leather" }, swatch: "#9b6b3f" },
      { name: { tr: "Tütsülü deri", en: "Smoked leather" }, swatch: "#3a2a20" },
      { name: { tr: "Cognac deri", en: "Cognac leather" }, swatch: "#7a4724" },
    ],
  },
  {
    slug: "if-sokak-dining", name: "If Sokak Dining Chair", project: "if-sokak-tunus", year: 2023,
    type: { tr: "Sandalye", en: "Dining chair" },
    materials: { tr: "Buharla bükülmüş kayın · Saraç deri", en: "Steam-bent beech · Saddle leather" },
    dim: "44 × 48 × 82 h cm",
    edition: { tr: "Stüdyo edisyonu", en: "Studio edition" },
    fabrics: [
      { name: { tr: "Naturel saraç deri", en: "Natural saddle leather" }, swatch: "#9b6b3f" },
      { name: { tr: "Siyah deri", en: "Black leather" }, swatch: "#1a1612" },
      { name: { tr: "Bordeaux deri", en: "Bordeaux leather" }, swatch: "#5a2a26" },
      { name: { tr: "Hasır", en: "Cane" }, swatch: "#c8a06a" },
    ],
    finishes: [
      { name: { tr: "Doğal kayın", en: "Natural beech" }, swatch: "#c9a37e" },
      { name: { tr: "Tütsülü kayın", en: "Smoked beech" }, swatch: "#5a3e2a" },
      { name: { tr: "Mat siyah", en: "Matte black" }, swatch: "#1f1a16" },
    ],
  },
  {
    slug: "demars-desk", name: "Demars Executive Desk", project: "demars-holding", year: 2022,
    type: { tr: "Çalışma masası", en: "Desk" },
    materials: { tr: "Brüt ceviz · Patine bronz", en: "Raw walnut · Patinated bronze" },
    dim: "200 × 90 × 75 h cm",
    edition: { tr: "Sipariş üzerine", en: "Made to order" },
    finishes: [
      { name: { tr: "Brüt ceviz", en: "Raw walnut" }, swatch: "#6b4a32" },
      { name: { tr: "Tütsülenmiş ceviz", en: "Smoked walnut" }, swatch: "#3a2a20" },
      { name: { tr: "Beyaz yağlı meşe", en: "White-oiled oak" }, swatch: "#d6c7ac" },
      { name: { tr: "Patine bronz ayak", en: "Patinated bronze leg" }, swatch: "#7a5a3a" },
      { name: { tr: "Kararmış çelik ayak", en: "Blackened steel leg" }, swatch: "#2a2826" },
    ],
  },
  {
    slug: "lillian-vase", name: "Lillian Vase", project: "lillian-flower-shop", year: 2026,
    type: { tr: "Vazo", en: "Vessel" },
    materials: { tr: "El şekillendirme stoneware", en: "Hand-thrown stoneware" },
    dim: "Ø 22 × 32 h cm",
    edition: { tr: "Tek tek üretim", en: "One-of-a-kind" },
    finishes: [
      { name: { tr: "Sade kil", en: "Plain clay" }, swatch: "#c9a89a" },
      { name: { tr: "Külleme glaze", en: "Ash glaze" }, swatch: "#8a857a" },
      { name: { tr: "Yeşim glaze", en: "Jade glaze" }, swatch: "#6f8a78" },
      { name: { tr: "Krem glaze", en: "Cream glaze" }, swatch: "#e8dcc5" },
      { name: { tr: "Kararmış glaze", en: "Blackened glaze" }, swatch: "#2a2624" },
    ],
  },
  {
    slug: "roastery-shelf", name: "Roastery Shelving", project: "line-roastery", year: 2024,
    type: { tr: "Raf modülü", en: "Shelving module" },
    materials: { tr: "Kararmış çelik · Tütsülenmiş ahşap", en: "Blackened steel · Smoked oak" },
    dim: "90 × 32 × 220 h cm",
    edition: { tr: "Modüler", en: "Modular" },
    finishes: [
      { name: { tr: "Tütsülenmiş meşe", en: "Smoked oak" }, swatch: "#4a3825" },
      { name: { tr: "Doğal meşe", en: "Natural oak" }, swatch: "#c4a880" },
      { name: { tr: "Beyaz yağlı meşe", en: "White-oiled oak" }, swatch: "#d6c7ac" },
      { name: { tr: "Kararmış çelik", en: "Blackened steel" }, swatch: "#1f1a16" },
      { name: { tr: "Patine bronz", en: "Patinated bronze" }, swatch: "#7a5a3a" },
    ],
  },
  {
    slug: "burger-stool", name: "TBS Counter Stool", project: "the-burger-shop", year: 2026,
    type: { tr: "Bar taburesi", en: "Counter stool" },
    materials: { tr: "Beyaz meşe · Ham yün", en: "White oak · Raw wool" },
    dim: "Ø 42 × 78 h cm",
    edition: { tr: "Stüdyo edisyonu", en: "Studio edition" },
    fabrics: [
      { name: { tr: "Ham yün", en: "Raw wool" }, swatch: "#d8cdb6" },
      { name: { tr: "Kahverengi keten", en: "Brown linen" }, swatch: "#7a5a42" },
      { name: { tr: "Toprak yün", en: "Earth wool" }, swatch: "#9a7a5a" },
      { name: { tr: "Charcoal yün", en: "Charcoal wool" }, swatch: "#3a3a3c" },
    ],
    finishes: [
      { name: { tr: "Beyaz meşe", en: "White oak" }, swatch: "#d6c7ac" },
      { name: { tr: "Tütsülenmiş meşe", en: "Smoked oak" }, swatch: "#4a3825" },
    ],
  },

  // — Accessories — Studio merchandise / small goods
  {
    slug: "studio-tshirt", name: "Studio T-shirt", project: null, year: 2026,
    type: { tr: "Aksesuar", en: "Accessory" },
    subtype: { tr: "Tekstil", en: "Apparel" },
    materials: { tr: "240 gr/m² ağır pamuk · Garment dyed", en: "240 gsm heavy cotton · Garment dyed" },
    dim: { tr: "S · M · L · XL · XXL", en: "S · M · L · XL · XXL" },
    edition: { tr: "Stüdyo aksesuarı", en: "Studio merch" },
    fabrics: [
      { name: { tr: "Doğal pamuk", en: "Natural cotton" }, swatch: "#dcd2bf" },
      { name: { tr: "Charcoal", en: "Charcoal" }, swatch: "#38383c" },
      { name: { tr: "Tütsülü kahverengi", en: "Smoked brown" }, swatch: "#5a4838" },
      { name: { tr: "Adaçayı", en: "Sage" }, swatch: "#7a8068" },
      { name: { tr: "Krem", en: "Cream" }, swatch: "#ede4d0" },
    ],
  },
  {
    slug: "studio-journal", name: "Studio Journal", project: null, year: 2026,
    type: { tr: "Aksesuar", en: "Accessory" },
    subtype: { tr: "Kırtasiye", en: "Stationery" },
    materials: { tr: "Tütsülü keten cilt · 80 gr nokta ızgara kağıt · Pirinç köşe", en: "Smoked linen cover · 80 gsm dot-grid paper · Brass corners" },
    dim: { tr: "A5 · 160 sayfa", en: "A5 · 160 pages" },
    edition: { tr: "Edisyon · numaralı", en: "Numbered edition" },
    fabrics: [
      { name: { tr: "Charcoal keten", en: "Charcoal linen" }, swatch: "#38383c" },
      { name: { tr: "Kahverengi keten", en: "Brown linen" }, swatch: "#5a4634" },
      { name: { tr: "Krem keten", en: "Cream linen" }, swatch: "#d6c7ac" },
      { name: { tr: "Sage keten", en: "Sage linen" }, swatch: "#7a8068" },
    ],
  },
  {
    slug: "studio-pen", name: "Studio Pen", project: null, year: 2026,
    type: { tr: "Aksesuar", en: "Accessory" },
    subtype: { tr: "Yazı aleti", en: "Writing instrument" },
    materials: { tr: "Solid pirinç gövde · Doldurulabilir kartuş", en: "Solid brass body · Refillable cartridge" },
    dim: { tr: "Ø 9 mm · 138 mm", en: "Ø 9 mm · 138 mm" },
    edition: { tr: "Stüdyo aksesuarı", en: "Studio object" },
    finishes: [
      { name: { tr: "Patine pirinç", en: "Patinated brass" }, swatch: "#7a5a3a" },
      { name: { tr: "Mat pirinç", en: "Matte brass" }, swatch: "#b89a6a" },
      { name: { tr: "Kararmış pirinç", en: "Blackened brass" }, swatch: "#2a2826" },
      { name: { tr: "Krom", en: "Chrome" }, swatch: "#c5c8cc" },
    ],
  },
  {
    slug: "studio-sketchbook", name: "Sketch Pad", project: null, year: 2026,
    type: { tr: "Aksesuar", en: "Accessory" },
    subtype: { tr: "Kırtasiye", en: "Stationery" },
    materials: { tr: "120 gr krem kağıt · Tel cilt · Karton arka", en: "120 gsm cream paper · Wire-bound · Card back" },
    dim: { tr: "A4 · 80 sayfa", en: "A4 · 80 pages" },
    edition: { tr: "Stüdyo aksesuarı", en: "Studio pad" },
    fabrics: [
      { name: { tr: "Krem", en: "Cream" }, swatch: "#ede4d0" },
      { name: { tr: "Doğal", en: "Natural" }, swatch: "#d8cdb6" },
      { name: { tr: "Charcoal", en: "Charcoal" }, swatch: "#38383c" },
    ],
  },
  {
    slug: "studio-mug", name: "Studio Mug", project: null, year: 2026,
    type: { tr: "Aksesuar", en: "Accessory" },
    subtype: { tr: "Seramik", en: "Ceramic" },
    materials: { tr: "El şekillendirme stoneware · Mat sır", en: "Hand-thrown stoneware · Matte glaze" },
    dim: { tr: "Ø 8.5 × 9 h cm · 320 ml", en: "Ø 8.5 × 9 h cm · 320 ml" },
    edition: { tr: "Stüdyo aksesuarı · 2'li set", en: "Studio object · set of 2" },
    finishes: [
      { name: { tr: "Sade kil", en: "Plain clay" }, swatch: "#c9a89a" },
      { name: { tr: "Külleme glaze", en: "Ash glaze" }, swatch: "#8a857a" },
      { name: { tr: "Yeşim glaze", en: "Jade glaze" }, swatch: "#6f8a78" },
      { name: { tr: "Krem glaze", en: "Cream glaze" }, swatch: "#e8dcc5" },
      { name: { tr: "Kararmış glaze", en: "Blackened glaze" }, swatch: "#2a2624" },
      { name: { tr: "Charcoal glaze", en: "Charcoal glaze" }, swatch: "#3a3a3c" },
    ],
  },
];

// Studio playlist — what plays in the office
const PLAYLIST = {
  cover: { tr: "Stüdyoda Çalan", en: "Now Playing in the Studio" },
  subtitle: { tr: "Çizim masasının arka planında, kahve molasında, geç vakitlerde.", en: "Behind the drafting table, on the coffee break, late into the night." },
  tracks: [
    { title: "Murmuration", artist: "Nils Frahm", album: "All Melody", year: 2018, dur: "5:24", note: { tr: "Pazartesi sabahı, kahve hâlâ sıcakken.", en: "Monday morning, coffee still hot." } },
    { title: "Nuvole Bianche", artist: "Ludovico Einaudi", album: "Una Mattina", year: 2004, dur: "5:51", note: { tr: "Çizim üzerinde uzun düşünmeler için.", en: "For long thinking over drawings." } },
    { title: "Cycle Song", artist: "Hania Rani", album: "Esja", year: 2019, dur: "4:38", note: { tr: "Şantiye dönüşü, geç saat ofis.", en: "After site, late at the office." } },
    { title: "Eyes Closed and Traveling", artist: "Peter Broderick", album: "Float", year: 2008, dur: "3:42", note: { tr: "Konsept aşaması.", en: "Concept phase." } },
    { title: "Lift", artist: "Poppy Ackroyd", album: "Resolve", year: 2018, dur: "4:12", note: { tr: "Detay üzerine kapanmış saatlerde.", en: "When the room narrows to one detail." } },
    { title: "Way Out", artist: "Yann Tiersen", album: "EUSA", year: 2016, dur: "4:08", note: { tr: "Akşamüstü ışık değişirken.", en: "When the afternoon light turns." } },
    { title: "Says", artist: "Nils Frahm", album: "Spaces", year: 2013, dur: "8:25", note: { tr: "Mahal tartışmaları.", en: "Discussing the brief." } },
    { title: "On The Nature of Daylight", artist: "Max Richter", album: "The Blue Notebooks", year: 2004, dur: "6:14", note: { tr: "Bazı kararlar sessiz alınır.", en: "Some decisions arrive in silence." } },
    { title: "Avril 14th", artist: "Aphex Twin", album: "Drukqs", year: 2001, dur: "2:05", note: { tr: "Kısa bir mola.", en: "A short break." } },
    { title: "Spiegel im Spiegel", artist: "Arvo Pärt", album: "Alina", year: 1999, dur: "8:55", note: { tr: "İlk eskizler.", en: "First sketches." } },
    { title: "Reawakening", artist: "Federico Albanese", album: "By the Deep Sea", year: 2016, dur: "4:32", note: { tr: "Malzeme paleti.", en: "Material palette." } },
    { title: "An Ending (Ascent)", artist: "Brian Eno", album: "Apollo", year: 1983, dur: "4:19", note: { tr: "Teslim gecesi.", en: "Handover night." } },
  ],
};

// Studio journal — short editorial articles, project openings, material discoveries
const JOURNAL = [
  {
    slug: "kei-acilis-2026",
    date: "2026-04-12",
    category: { tr: "Açılış", en: "Opening" },
    title: { tr: "Kei açıldı: bambu bahçesi ve sessizlik üzerine", en: "Kei is open: on the bamboo garden and silence" },
    excerpt: { tr: "Ankara Merkez'de açılan Kei, karma program — pastane, kahve kavurmahanesi, restoran — etrafında bir bambu bahçesi kuruyor. Açılış günü notlarımız ve mekânın ilk kullanım izlenimleri.", en: "Kei opened in central Ankara with a mixed programme — pâtisserie, coffee roastery, restaurant — gathered around a bamboo garden. Opening day notes and first impressions of the space in use." },
    readMin: 7,
    related: "kei",
  },
  {
    slug: "malzeme-notlari-trone",
    date: "2026-03-04",
    category: { tr: "Malzeme", en: "Material" },
    title: { tr: "Malzeme notları: Trone karoları üzerine", en: "Material notes: on Trone tiles" },
    excerpt: { tr: "Tütsülenmiş ahşap, kararmış pirinç ve el yapımı seramik karo. Stüdyonun son üç projesinde tekrarlanan bu üçlü, mekâna nasıl bir hafıza kuruyor?", en: "Smoked timber, blackened brass and hand-glazed ceramic tile. What kind of memory does this trio — repeated across the studio's last three projects — build in a space?" },
    readMin: 5,
    related: "kei",
  },
  {
    slug: "an-headquarter-konusu",
    date: "2026-01-22",
    category: { tr: "Süreç", en: "Process" },
    title: { tr: "Ân Headquarter: marka kimliğinin mekâna çevrilmesi", en: "Ân Headquarter: translating a brand identity into space" },
    excerpt: { tr: "Marka kimliği danışmanlığını da yürüttüğümüz Ân için merkez ofis projesi nasıl şekillendi? Logoda olmayan ama mekânda yaşayan detaylar üzerine.", en: "How did the HQ project for Ân — whose brand identity we also developed — take shape? On the details not in the logo but alive in the space." },
    readMin: 8,
    related: "an-headquarter",
  },
  {
    slug: "koroglu-beytepe-teslim",
    date: "2025-11-08",
    category: { tr: "Teslim", en: "Handover" },
    title: { tr: "Köroğlu Beytepe: 8.400 m²'de bir konut hikayesi", en: "Köroğlu Beytepe: a residential story on 8,400 m²" },
    excerpt: { tr: "Üç yıl süren bir sürecin sonunda Köroğlu Beytepe teslim edildi. Plan kararlarından son detaya, bir konut projesinde ölçekle yaşamak.", en: "After three years, Köroğlu Beytepe has been handed over. From plan decisions to the final detail — living with scale in a residential project." },
    readMin: 9,
    related: "koroglu-beytepe",
  },
  {
    slug: "kahve-uclemesi",
    date: "2025-09-15",
    category: { tr: "Süreç", en: "Process" },
    title: { tr: "Üç kahve, üç şehir: Vaa, Grond, Noon", en: "Three coffees, three cities: Vaa, Grond, Noon" },
    excerpt: { tr: "İstanbul ve Ankara'da arka arkaya teslim ettiğimiz üç specialty kahve mekânı. Aynı program, üç farklı dil — kahvenin nereye, nasıl ait olduğu üzerine.", en: "Three specialty coffee places we delivered back-to-back in Istanbul and Ankara. The same brief, three different languages — on where and how coffee belongs." },
    readMin: 6,
    related: "vaa-coffee",
  },
  {
    slug: "mobilya-stuydo-edisyonu",
    date: "2025-06-20",
    category: { tr: "Atölye", en: "Workshop" },
    title: { tr: "Mobilyalarımızı niye satıyoruz?", en: "Why we sell our furniture" },
    excerpt: { tr: "Projeler için tasarlayıp ürettiğimiz parçaları stüdyo edisyonu olarak sunmaya başladık. Karar arkasındaki düşünce: bir tasarım, mekânda kaldığı kadar da elden ele dolaşır.", en: "We have begun offering pieces we design and produce for projects as a studio edition. The thinking behind it: a design lives in a space — but it also passes from hand to hand." },
    readMin: 4,
    related: null,
  },
  {
    slug: "kayakapi-uc-yil",
    date: "2025-04-02",
    category: { tr: "Geriye Dönüş", en: "Retrospect" },
    title: { tr: "Kayakapı'nın üzerinden üç yıl", en: "Three years on from Kayakapı" },
    excerpt: { tr: "2022'de teslim ettiğimiz Kayakapı Hotel, üç yıl sonra nasıl yaşlandı? Misafirlerle, taşıyla, ışığıyla — geri dönüşler.", en: "How has Kayakapı Hotel, delivered in 2022, aged after three years? Returns — with the guests, the stone, the light." },
    readMin: 5,
    related: "kayakapi-hotel",
  },
];

Object.assign(window, { PROJECTS, COPY, CONTACT, paletteFor, FURNITURE, PLAYLIST, JOURNAL });
