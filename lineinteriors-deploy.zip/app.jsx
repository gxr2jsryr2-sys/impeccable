/* eslint-disable */
// Root app — handles variation, page routing, language

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "variation": "A",
  "lang": "en",
  "paletteA": "stone"
}/*EDITMODE-END*/;

function App() {
  const [tweaks, setTweak] = window.useTweaks(TWEAK_DEFAULTS);
  const [page, setPage] = React.useState({ name: "index" });
  const [splashDone, setSplashDone] = React.useState(false);

  // Set CSS vars based on variation
  React.useEffect(() => {
    const root = document.documentElement;
    root.style.setProperty("--display", '"Instrument Sans", system-ui, sans-serif');
    root.style.setProperty("--serif", '"Instrument Serif", Georgia, serif');
    root.style.setProperty("--mono", '"JetBrains Mono", ui-monospace, monospace');
  }, []);

  // Splash bg/ink per palette (only for A; for B & C just skip splash)
  React.useEffect(() => {
    const root = document.documentElement;
    if (tweaks.variation === "A") {
      const map = {
        "cool-brown": ["#342626", "#c7d2dd"],
        "ocean":      ["#e0e6ea", "#22282c"],
        "stone":      ["#e0d8d0", "#38383c"],
      };
      const [bg, ink] = map[tweaks.paletteA] || map["stone"];
      root.style.setProperty("--splash-bg", bg);
      root.style.setProperty("--splash-ink", ink);
    }
  }, [tweaks.variation, tweaks.paletteA]);

  // Cursor color from palette
  const cursorColor = (() => {
    if (tweaks.variation !== "A") return "#f1e8d5";
    const map = { "cool-brown": "#c7d2dd", "ocean": "#22282c", "stone": "#38383c" };
    return map[tweaks.paletteA] || "#38383c";
  })();

  // Reset to index when variation changes for a coherent first-impression
  const prevVar = React.useRef(tweaks.variation);
  React.useEffect(() => {
    if (prevVar.current !== tweaks.variation) {
      setPage({ name: "index" });
      window.scrollTo({ top: 0, behavior: "instant" });
      prevVar.current = tweaks.variation;
    }
  }, [tweaks.variation]);

  // Scroll restore is handled by PageTransition; keep this as a safety net only on initial mount
  React.useEffect(() => {
    window.scrollTo({ top: 0, behavior: "instant" });
  }, []);

  const t = window.COPY[tweaks.lang];
  const lang = tweaks.lang;
  const setLang = (l) => setTweak("lang", l);

  const props = { page, setPage, lang, setLang, t };

  return (
    <React.Fragment>
      {tweaks.variation === "A" && <window.VariationA {...props} paletteKey={tweaks.paletteA} />}
      {tweaks.variation === "B" && <window.VariationB {...props} />}
      {tweaks.variation === "C" && <window.VariationC {...props} />}

      {tweaks.variation === "A" && !splashDone && (
        <window.Splash palette={tweaks.paletteA} lang={lang} onDone={() => setSplashDone(true)} />
      )}

      <window.SketchCursor />

      <window.TweaksPanel title="Tweaks" defaultPosition={{ right: 24, bottom: 24 }}>
        <window.TweakSection title={lang === "tr" ? "Yön" : "Direction"}>
          <window.TweakRadio
            label={lang === "tr" ? "Tasarım yönü" : "Design direction"}
            value={tweaks.variation}
            onChange={(v) => setTweak("variation", v)}
            options={[
              { value: "A", label: "A · Editorial" },
              { value: "B", label: "B · Cinematic" },
              { value: "C", label: "C · Index" },
            ]}
          />
          <div style={{ fontSize: 11, lineHeight: 1.5, color: "rgba(0,0,0,0.55)", marginTop: 6 }}>
            {tweaks.variation === "A" && (lang === "tr"
              ? "Sıcak krem · büyük editöryel tipografi · galeri yerleşimi."
              : "Warm cream · large editorial type · gallery layout.")}
            {tweaks.variation === "B" && (lang === "tr"
              ? "Koyu kahve · sinematik tam ekran görseller · sticky sidebar."
              : "Dark brown · cinematic full-bleed imagery · sticky sidebar.")}
            {tweaks.variation === "C" && (lang === "tr"
              ? "Index/arşiv hissi · monospace ağırlıklı · veri yoğun liste."
              : "Index/archive feel · monospace-led · data-dense list.")}
          </div>
        </window.TweakSection>

        {tweaks.variation === "A" && (
          <window.TweakSection title={lang === "tr" ? "Palet (A)" : "Palette (A)"}>
            <window.TweakRadio
              label={lang === "tr" ? "Renk kombinasyonu" : "Color combination"}
              value={tweaks.paletteA}
              onChange={(v) => setTweak("paletteA", v)}
              options={[
                { value: "cool-brown", label: "Cool Brown" },
                { value: "ocean", label: "Ocean" },
                { value: "stone", label: "Stone" },
              ]}
            />
            <div style={{ display: "flex", gap: 4, marginTop: 8 }}>
              {tweaks.paletteA === "cool-brown"
                ? ["#342626", "#c7d2dd", "#8a94a0", "#2a1e1e"].map((c, i) =>
                    <div key={i} style={{ flex: 1, height: 24, background: c, border: "1px solid rgba(0,0,0,0.08)" }} />)
                : tweaks.paletteA === "ocean"
                ? ["#22282c", "#929fa7", "#e9e7e1", "#e0e6ea", "#ffffff"].map((c, i) =>
                    <div key={i} style={{ flex: 1, height: 24, background: c, border: "1px solid rgba(0,0,0,0.08)" }} />)
                : ["#57646c", "#7f878a", "#b3aba1", "#e0d8d0", "#38383c"].map((c, i) =>
                    <div key={i} style={{ flex: 1, height: 24, background: c, border: "1px solid rgba(0,0,0,0.08)" }} />)}
            </div>
            <div style={{ fontSize: 11, lineHeight: 1.5, color: "rgba(0,0,0,0.55)", marginTop: 8 }}>
              {tweaks.paletteA === "cool-brown"
                ? (lang === "tr" ? "Cool brown zemin · clear sky tipografi." : "Cool brown ground · clear sky type.")
                : tweaks.paletteA === "ocean"
                ? (lang === "tr" ? "Dust + Snow zemin · Midnight tipografi · Ocean orta tonu." : "Dust + Snow ground · Midnight type · Ocean mid.")
                : (lang === "tr" ? "Sahil minerali · stone zemin · slate orta · charcoal tipografi." : "Coastal mineral · stone ground · slate mid · charcoal type.")}
            </div>
          </window.TweakSection>
        )}

        <window.TweakSection title={lang === "tr" ? "Dil" : "Language"}>
          <window.TweakRadio
            label={lang === "tr" ? "İçerik dili" : "Content language"}
            value={tweaks.lang}
            onChange={(v) => setTweak("lang", v)}
            options={[
              { value: "en", label: "English" },
              { value: "tr", label: "Türkçe" },
            ]}
          />
        </window.TweakSection>

        <window.TweakSection title={lang === "tr" ? "Sayfa" : "Page"}>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 6 }}>
            {[
              ["index", t.nav.index],
              ["projects", t.nav.projects],
              ["shop", t.nav.shop],
              ["playlist", t.nav.playlist],
              ["journal", t.nav.journal],
              ["about", t.nav.about],
              ["contact", t.nav.contact],
            ].map(([k, label]) => (
              <button key={k} onClick={() => setPage({ name: k })}
                style={{
                  padding: "8px 10px", fontSize: 12,
                  background: page.name === k ? "#1a1a1a" : "#fff",
                  color: page.name === k ? "#fff" : "#1a1a1a",
                  border: "1px solid rgba(0,0,0,0.12)",
                  cursor: "pointer", fontFamily: "inherit",
                }}>
                {label}
              </button>
            ))}
          </div>
          <button onClick={() => {
            const idx = Math.floor(Math.random() * window.PROJECTS.length);
            setPage({ name: "project", slug: window.PROJECTS[idx].slug });
          }}
            style={{
              marginTop: 8, padding: "8px 10px", fontSize: 12, width: "100%",
              background: page.name === "project" ? "#1a1a1a" : "#fff",
              color: page.name === "project" ? "#fff" : "#1a1a1a",
              border: "1px solid rgba(0,0,0,0.12)", cursor: "pointer", fontFamily: "inherit",
            }}>
            {lang === "tr" ? "Rastgele proje detayı" : "Random project detail"} →
          </button>
        </window.TweakSection>
      </window.TweaksPanel>
    </React.Fragment>
  );
}

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<App />);
