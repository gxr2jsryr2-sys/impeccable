/* eslint-disable */
// Opening splash — Kelly Wearstler-style cinematic entrance
// Hero image with slow Ken Burns zoom, word-by-word title reveal,
// year/location ticker, vertical line draw, then curtain wipes up to reveal site.

function Splash({ palette, onDone, lang }) {
  const [stage, setStage] = React.useState("on"); // "on" → "wipe" → "off"

  React.useEffect(() => {
    const t1 = setTimeout(() => setStage("wipe"), 4200);
    const t2 = setTimeout(() => { setStage("off"); onDone && onDone(); }, 5400);
    return () => { clearTimeout(t1); clearTimeout(t2); };
  }, []);

  if (stage === "off") return null;

  // Background hero — uses Kei facade render (cinematic, dark, atmospheric)
  // For ocean palette use a different reference image if available
  const heroImg = "assets/projects/kei/01-hero-facade.jpg";

  const wordmark = palette === "stone" ? "assets/wordmark-charcoal.png"
    : palette === "ocean" ? "assets/wordmark-midnight.png"
    : "assets/wordmark-sky.png";

  // Curtain color matches splash palette
  const curtainBg = "var(--splash-bg)";

  // Title parts for word-by-word reveal
  const title = (lang === "tr"
    ? ["Mekân,", "kullanıldığında,", "değer", "kazanır."]
    : ["Space", "gains", "its", "value", "in", "use."]);

  return (
    <div style={{
      position: "fixed", inset: 0, zIndex: 10000,
      background: "#0a0a0c",
      overflow: "hidden",
      cursor: "pointer",
      transition: "opacity .9s cubic-bezier(.7,0,.3,1)",
      opacity: stage === "wipe" ? 1 : 1,
    }}
      onClick={() => { setStage("wipe"); setTimeout(() => { setStage("off"); onDone && onDone(); }, 900); }}>

      <style>{`
        @keyframes splash-kenburns {
          from { transform: scale(1.05) translate(0, 0); }
          to   { transform: scale(1.18) translate(-3%, -2%); }
        }
        @keyframes splash-dim {
          from { background-position: center; opacity: 0.55; }
          to   { background-position: center; opacity: 0.42; }
        }
        @keyframes splash-word {
          from { opacity: 0; transform: translateY(28px); filter: blur(8px); }
          to   { opacity: 1; transform: none; filter: none; }
        }
        @keyframes splash-fade {
          from { opacity: 0; }
          to   { opacity: 1; }
        }
        @keyframes splash-vline {
          from { transform: scaleY(0); transform-origin: top; }
          to   { transform: scaleY(1); transform-origin: top; }
        }
        @keyframes splash-meta-up {
          from { opacity: 0; transform: translateY(14px); }
          to   { opacity: 1; transform: none; }
        }
        @keyframes splash-counter {
          0%   { opacity: 0; transform: translateY(8px); }
          15%  { opacity: 1; transform: none; }
          80%  { opacity: 1; }
          100% { opacity: 0.5; }
        }
        @keyframes splash-wordmark-out {
          0% { opacity: 0; transform: translateY(20px); }
          100% { opacity: 1; transform: none; }
        }
        @keyframes splash-curtain {
          from { transform: translateY(100%); }
          to   { transform: translateY(0); }
        }
        .splash-bg {
          position: absolute; inset: 0;
          background-image: url(${JSON.stringify(heroImg)});
          background-size: cover;
          background-position: center;
          animation: splash-kenburns 8s cubic-bezier(.4,0,.2,1) both;
          will-change: transform;
        }
        .splash-overlay {
          position: absolute; inset: 0;
          background: linear-gradient(180deg, rgba(10,10,12,0.55) 0%, rgba(10,10,12,0.30) 35%, rgba(10,10,12,0.30) 65%, rgba(10,10,12,0.80) 100%);
          pointer-events: none;
        }
        .splash-vignette {
          position: absolute; inset: 0;
          background: radial-gradient(110% 80% at 50% 50%, transparent 50%, rgba(0,0,0,0.55) 100%);
          pointer-events: none;
        }
        .splash-grain {
          position: absolute; inset: 0; pointer-events: none; opacity: 0.18;
          background-image: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="180" height="180"><filter id="n"><feTurbulence type="fractalNoise" baseFrequency="0.85" numOctaves="2"/></filter><rect width="180" height="180" filter="url(%23n)" opacity="0.6"/></svg>');
          mix-blend-mode: overlay;
        }
        .splash-frame {
          position: absolute; inset: 32px;
          border: 1px solid rgba(245,238,225,0.18);
          pointer-events: none;
          animation: splash-fade 1.4s cubic-bezier(.2,.7,.1,1) 0.2s both;
        }
        .splash-corner {
          position: absolute; width: 18px; height: 18px;
          border-color: rgba(245,238,225,0.6);
          pointer-events: none;
          animation: splash-fade 1.4s cubic-bezier(.2,.7,.1,1) 0.4s both;
        }

        .splash-header {
          position: absolute; top: 56px; left: 56px; right: 56px;
          display: flex; justify-content: space-between; align-items: flex-start;
          color: rgba(245,238,225,0.9);
          font-family: var(--mono);
          font-size: 11px; letter-spacing: 0.22em; text-transform: uppercase;
          animation: splash-meta-up 1.1s cubic-bezier(.2,.7,.1,1) 0.5s both;
        }
        .splash-header .col { display: flex; flex-direction: column; gap: 6px; }
        .splash-header .col span:first-child { opacity: 0.55; }

        .splash-center {
          position: absolute; inset: 0;
          display: flex; flex-direction: column; align-items: center; justify-content: center;
          color: #f1e8d5; padding: 0 32px;
        }
        .splash-vert-line {
          position: absolute; top: 0; bottom: 0; left: 50%; width: 1px;
          background: rgba(245,238,225,0.18);
          animation: splash-vline 2.2s cubic-bezier(.5,.1,.5,1) 0.6s both;
        }
        .splash-eyebrow {
          font-family: var(--mono); font-size: 12px; letter-spacing: 0.32em;
          text-transform: uppercase; color: rgba(245,238,225,0.78);
          margin-bottom: 36px;
          animation: splash-word 1.1s cubic-bezier(.2,.7,.1,1) 0.9s both;
        }
        .splash-eyebrow span { display: inline-block; margin: 0 4px; }
        .splash-title {
          font-family: var(--display);
          font-weight: 400;
          font-size: clamp(58px, 8.4vw, 144px);
          line-height: 0.95; letter-spacing: -0.045em;
          text-align: center; max-width: 18ch;
          white-space: normal;
        }
        .splash-title .word {
          display: inline-block; margin: 0 0.16em;
          animation: splash-word 0.95s cubic-bezier(.2,.7,.1,1) both;
        }
        .splash-title .word.serif {
          font-family: var(--serif); font-style: italic;
        }
        .splash-wordmark {
          margin-top: 60px;
          animation: splash-wordmark-out 1.1s cubic-bezier(.2,.7,.1,1) 2.4s both;
          opacity: 0;
        }
        .splash-wordmark img { width: min(360px, 50vw); display: block; }

        .splash-foot {
          position: absolute; bottom: 56px; left: 56px; right: 56px;
          display: flex; justify-content: space-between; align-items: flex-end;
          color: rgba(245,238,225,0.78);
          font-family: var(--mono); font-size: 11px; letter-spacing: 0.22em;
          text-transform: uppercase;
        }
        .splash-counter {
          font-family: var(--display);
          font-size: 36px; letter-spacing: -0.02em;
          color: #f1e8d5;
          font-feature-settings: "tnum";
          animation: splash-counter 3.6s cubic-bezier(.2,.7,.1,1) 0.6s both;
        }
        .splash-skip {
          font-family: var(--mono); font-size: 10px; letter-spacing: 0.22em;
          text-transform: uppercase; color: rgba(245,238,225,0.5);
          animation: splash-fade 1s 3.0s both;
        }

        .splash-curtain {
          position: absolute; left: 0; right: 0; bottom: 0; top: 0;
          background: ${curtainBg};
          transform: translateY(100%);
          z-index: 5;
          ${stage === "wipe" ? "animation: splash-curtain 1.1s cubic-bezier(.65,0,.35,1) forwards;" : ""}
        }
      `}</style>

      <div className="splash-bg" />
      <div className="splash-overlay" />
      <div className="splash-vignette" />
      <div className="splash-grain" />

      {/* thin border frame + corner marks */}
      <div className="splash-frame" />
      {[
        { top: 24, left: 24, borderTop: "1px solid", borderLeft: "1px solid" },
        { top: 24, right: 24, borderTop: "1px solid", borderRight: "1px solid" },
        { bottom: 24, left: 24, borderBottom: "1px solid", borderLeft: "1px solid" },
        { bottom: 24, right: 24, borderBottom: "1px solid", borderRight: "1px solid" },
      ].map((s, i) => (
        <div key={i} className="splash-corner" style={s} />
      ))}

      {/* header meta */}
      <div className="splash-header">
        <div className="col">
          <span>Studio</span>
          <span>Line Interiors</span>
        </div>
        <div className="col" style={{ textAlign: "center" }}>
          <span>Est.</span>
          <span>2017 — Ankara</span>
        </div>
        <div className="col" style={{ textAlign: "right" }}>
          <span>Index</span>
          <span>{String(window.PROJECTS?.length || 32).padStart(2, "0")} Projects</span>
        </div>
      </div>

      {/* central vertical hairline */}
      <div className="splash-vert-line" />

      {/* centerpiece */}
      <div className="splash-center">
        <div className="splash-eyebrow">
          <span>İç</span> <span>·</span> <span>Mimarlık</span> <span>·</span> <span>Stüdyosu</span>
        </div>

        <h1 className="splash-title">
          {title.map((word, i) => {
            // make some words italic serif for editorial rhythm
            const isItalic = lang === "tr"
              ? (word === "kullanıldığında," || word === "kazanır.")
              : (word === "value" || word === "use.");
            return (
              <span key={i}
                className={`word ${isItalic ? "serif" : ""}`}
                style={{ animationDelay: `${0.9 + i * 0.18}s` }}>
                {word}
              </span>
            );
          })}
        </h1>

        <div className="splash-wordmark">
          <img src={wordmark} alt="Line Interiors" />
        </div>
      </div>

      {/* footer */}
      <div className="splash-foot">
        <div className="splash-counter">— 2026</div>
        <div style={{ textAlign: "center", lineHeight: 1.6 }}>
          {lang === "tr" ? "Çankaya · Ankara" : "Çankaya · Ankara"}<br />
          <span style={{ opacity: 0.55 }}>{lang === "tr" ? "Tasarım · Uygulama · Branding" : "Design · Build · Branding"}</span>
        </div>
        <div className="splash-skip" style={{ textAlign: "right", alignSelf: "flex-end" }}>
          {lang === "tr" ? "Atlamak için tıkla" : "Click to skip"} ↗
        </div>
      </div>

      {/* curtain wipe up */}
      <div className="splash-curtain" />
    </div>
  );
}

window.Splash = Splash;
