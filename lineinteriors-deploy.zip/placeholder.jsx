/* eslint-disable */
// Architectural render placeholders — abstract perspective interiors
// Each category gets a distinct composition; seeded by slug+idx for variety

function RenderImage({ slug, label, ratio = "4/3", style = {}, scale = 1, idx = 0, dark = false, category, withFigure }) {
  const [c1, c2] = window.paletteFor(slug || "x");
  let h = idx;
  for (let i = 0; i < (slug || "").length; i++) h = (h * 31 + slug.charCodeAt(i)) >>> 0;

  const cat = (category && (category.tr || category.en)) || category || "";
  const catKey = String(cat).toLowerCase();
  const figureSrc = window.__figureSrc || "assets/figures-charcoal.png";

  // Seeded random
  const rand = (n) => {
    let x = (h + n * 9301) % 233280;
    return (x / 233280);
  };

  // Color helpers
  const dark1 = shade(c1, -0.30);
  const dark2 = shade(c1, -0.55);
  const light1 = shade(c1, 0.18);
  const ink = c2;

  // Composition variants
  const variant = h % 4;
  const lightFrom = rand(1) > 0.5 ? "tr" : "tl";

  // Scene SVG per category
  const renderScene = () => {
    const W = 1600, H = 1000;
    // common: light through windows / ceiling
    const winX1 = lightFrom === "tr" ? 1000 : 0;
    const winX2 = lightFrom === "tr" ? 1600 : 600;

    // Restaurant — interior with banquette, pendant lights, table setting
    if (catKey.includes("restoran") || catKey.includes("restaurant")) {
      return (
        <g>
          {/* back wall */}
          <rect x="0" y="0" width={W} height="620" fill={dark1} />
          {/* floor */}
          <polygon points={`0,620 ${W},620 ${W},${H} 0,${H}`} fill={dark2} />
          {/* window / light slot */}
          <rect x={winX1 + 80} y="80" width={(winX2 - winX1) - 200} height="280" fill={light1} opacity="0.92" />
          <line x1={winX1 + 80} y1="220" x2={winX2 - 120} y2="220" stroke={dark1} strokeWidth="3" />
          {/* banquette back panel */}
          <rect x="80" y="380" width="900" height="240" fill={shade(c1, -0.12)} />
          {/* vertical reeded wood lines on banquette */}
          {Array.from({length: 36}).map((_, i) => (
            <line key={i} x1={80 + i * 25} y1="380" x2={80 + i * 25} y2="620"
              stroke={shade(c1, -0.25)} strokeWidth="1.2" opacity="0.55" />
          ))}
          {/* banquette seat shadow */}
          <rect x="80" y="608" width="900" height="20" fill="rgba(0,0,0,0.25)" />
          {/* pendant lights */}
          {[280, 520, 760].map((x, i) => (
            <g key={i}>
              <line x1={x} y1="0" x2={x} y2={180} stroke={ink} strokeWidth="1.6" opacity="0.7" />
              <ellipse cx={x} cy={210} rx={28} ry={36} fill={shade(c1, 0.10)} stroke={ink} strokeWidth="1.6" opacity="0.85" />
              <ellipse cx={x} cy={246} rx={26} ry={6} fill={c1} opacity="0.6" />
              {/* light pool on table */}
              <ellipse cx={x} cy={720} rx={140} ry={26} fill="rgba(255,235,200,0.18)" />
            </g>
          ))}
          {/* table */}
          <rect x="160" y="700" width="760" height="14" fill={shade(c1, -0.45)} />
          <rect x="160" y="714" width="760" height="6" fill="rgba(0,0,0,0.35)" />
          {/* table props — plates, glassware */}
          {[280, 520, 760].map((x, i) => (
            <g key={i}>
              <ellipse cx={x} cy={702} rx={36} ry={6} fill="rgba(255,255,255,0.7)" />
              <ellipse cx={x + 50} cy={696} rx={6} ry={14} fill="rgba(255,255,255,0.6)" />
              <ellipse cx={x + 50} cy={690} rx={8} ry={4} fill="rgba(255,255,255,0.85)" />
            </g>
          ))}
        </g>
      );
    }

    // Café — counter with stools, pendant lights
    if (catKey.includes("kafe") || catKey.includes("café") || catKey.includes("cafe")) {
      return (
        <g>
          <rect x="0" y="0" width={W} height="640" fill={dark1} />
          <polygon points={`0,640 ${W},640 ${W},${H} 0,${H}`} fill={dark2} />
          {/* large window */}
          <rect x="60" y="80" width="900" height="380" fill={light1} opacity="0.88" />
          <line x1="510" y1="80" x2="510" y2="460" stroke={dark1} strokeWidth="3" />
          <line x1="60" y1="260" x2="960" y2="260" stroke={dark1} strokeWidth="3" />
          {/* counter */}
          <rect x="1020" y="500" width="520" height="200" fill={shade(c1, -0.20)} />
          <rect x="1020" y="488" width="520" height="14" fill={shade(c1, -0.40)} />
          {/* tiles on counter front */}
          {Array.from({length: 10}).map((_, i) => (
            <line key={i} x1={1020 + i * 52} y1="502" x2={1020 + i * 52} y2="700"
              stroke={shade(c1, -0.30)} strokeWidth="1.4" opacity="0.6" />
          ))}
          {Array.from({length: 4}).map((_, i) => (
            <line key={"h"+i} x1="1020" y1={520 + i * 45} x2="1540" y2={520 + i * 45}
              stroke={shade(c1, -0.30)} strokeWidth="1" opacity="0.5" />
          ))}
          {/* espresso machine silhouette */}
          <rect x="1080" y="420" width="180" height="80" fill={shade(c1, -0.50)} />
          <rect x="1080" y="412" width="180" height="10" fill={shade(c1, -0.60)} />
          <circle cx="1140" cy="460" r="10" fill={ink} opacity="0.6" />
          <circle cx="1200" cy="460" r="10" fill={ink} opacity="0.6" />
          {/* shelf with cups */}
          <line x1="1020" y1="320" x2="1540" y2="320" stroke={ink} strokeWidth="2" opacity="0.6" />
          {[1060, 1110, 1160, 1210, 1260, 1310, 1360, 1410, 1460, 1510].map((x, i) => (
            <ellipse key={i} cx={x} cy="306" rx="16" ry="6" fill={shade(c1, 0.18)} opacity="0.75" />
          ))}
          {/* pendant lights */}
          {[1100, 1260, 1420].map((x, i) => (
            <g key={i}>
              <line x1={x} y1="0" x2={x} y2={120} stroke={ink} strokeWidth="1.6" opacity="0.7" />
              <path d={`M ${x-26} 120 L ${x+26} 120 L ${x+18} 168 L ${x-18} 168 Z`} fill={shade(c1, 0.05)} stroke={ink} strokeWidth="1.6" opacity="0.85" />
            </g>
          ))}
          {/* stools */}
          {[1100, 1260, 1420].map((x, i) => (
            <g key={"s"+i}>
              <rect x={x-22} y="720" width="44" height="14" fill={shade(c1, -0.35)} />
              <line x1={x} y1="734" x2={x} y2="900" stroke={shade(c1, -0.50)} strokeWidth="6" />
            </g>
          ))}
        </g>
      );
    }

    // Hotel / Hospitality — corridor with arches
    if (catKey.includes("konaklama") || catKey.includes("hospitality") || catKey.includes("otel") || catKey.includes("hotel")) {
      return (
        <g>
          {/* perspective walls */}
          <polygon points={`0,0 ${W},0 ${W*0.7},${H*0.5} ${W*0.3},${H*0.5}`} fill={dark1} />
          <polygon points={`0,0 0,${H} ${W*0.3},${H*0.7} ${W*0.3},${H*0.3}`} fill={dark2} />
          <polygon points={`${W},0 ${W},${H} ${W*0.7},${H*0.7} ${W*0.7},${H*0.3}`} fill={dark2} />
          <polygon points={`0,${H} ${W},${H} ${W*0.7},${H*0.7} ${W*0.3},${H*0.7}`} fill={shade(c1, -0.40)} />
          {/* end wall light */}
          <rect x={W*0.32} y={H*0.32} width={W*0.36} height={H*0.36} fill={light1} opacity="0.92" />
          {/* arched openings on side walls */}
          {[0.42, 0.55].map((t, i) => {
            const x1 = W * 0.3 + (W * 0.4) * (t - 0.3) / 0.4;
            const w = 40 + i * 8;
            const yTop = H * 0.34 + i * 10;
            const yBot = H * 0.66 - i * 10;
            return (
              <g key={i}>
                <path d={`M ${x1 - w} ${yBot} L ${x1 - w} ${yTop + 20} Q ${x1 - w} ${yTop} ${x1 - w + 20} ${yTop} L ${x1 + w - 20} ${yTop} Q ${x1 + w} ${yTop} ${x1 + w} ${yTop + 20} L ${x1 + w} ${yBot} Z`}
                  fill={shade(c1, -0.55)} opacity="0.92" />
                <path d={`M ${x1 - w} ${yBot} L ${x1 - w} ${yTop + 20} Q ${x1 - w} ${yTop} ${x1 - w + 20} ${yTop} L ${x1 + w - 20} ${yTop} Q ${x1 + w} ${yTop} ${x1 + w} ${yTop + 20} L ${x1 + w} ${yBot}`}
                  fill="none" stroke={ink} strokeWidth="1.5" opacity="0.5" />
              </g>
            );
          })}
          {/* mirror on right */}
          {[0.42, 0.55].map((t, i) => {
            const x1 = W * 0.7 - (W * 0.4) * (t - 0.3) / 0.4;
            const w = 40 + i * 8;
            const yTop = H * 0.34 + i * 10;
            const yBot = H * 0.66 - i * 10;
            return (
              <g key={"r"+i}>
                <path d={`M ${x1 - w} ${yBot} L ${x1 - w} ${yTop + 20} Q ${x1 - w} ${yTop} ${x1 - w + 20} ${yTop} L ${x1 + w - 20} ${yTop} Q ${x1 + w} ${yTop} ${x1 + w} ${yTop + 20} L ${x1 + w} ${yBot} Z`}
                  fill={shade(c1, -0.55)} opacity="0.92" />
              </g>
            );
          })}
          {/* floor tiles perspective */}
          {[0.75, 0.82, 0.88, 0.94].map((t, i) => (
            <line key={i} x1={W * (0.5 - 0.5 * (1 - t))} y1={H * t} x2={W * (0.5 + 0.5 * (1 - t))} y2={H * t}
              stroke={shade(c1, -0.50)} strokeWidth="1.5" opacity="0.5" />
          ))}
          {/* ceiling pendants */}
          <line x1={W*0.5} y1="0" x2={W*0.5} y2={H*0.18} stroke={ink} strokeWidth="1.6" opacity="0.6" />
          <circle cx={W*0.5} cy={H*0.20} r={18} fill={shade(c1, 0.20)} opacity="0.9" />
        </g>
      );
    }

    // Office — open desks with monitors, ceiling grid
    if (catKey.includes("ofis") || catKey.includes("office")) {
      return (
        <g>
          <rect x="0" y="0" width={W} height="720" fill={dark1} />
          <polygon points={`0,720 ${W},720 ${W},${H} 0,${H}`} fill={dark2} />
          {/* ceiling grid */}
          {Array.from({length: 8}).map((_, i) => (
            <line key={i} x1="0" y1={20 + i * 30} x2={W} y2={20 + i * 30}
              stroke={ink} strokeWidth="1" opacity="0.18" />
          ))}
          {Array.from({length: 16}).map((_, i) => (
            <line key={"v"+i} x1={i * 100} y1="0" x2={i * 100} y2="280"
              stroke={ink} strokeWidth="1" opacity="0.15" />
          ))}
          {/* linear ceiling lights */}
          {[180, 600, 1020].map((x, i) => (
            <rect key={i} x={x} y="50" width="400" height="16" fill={light1} opacity="0.95" />
          ))}
          {/* large window */}
          <rect x={winX1} y="280" width="600" height="380" fill={light1} opacity="0.9" />
          {[1, 2, 3, 4].map(j => (
            <line key={j} x1={winX1 + j * 120} y1="280" x2={winX1 + j * 120} y2="660" stroke={dark1} strokeWidth="3" />
          ))}
          {/* desks */}
          {[100, 500, 900].map((x, i) => (
            <g key={i}>
              <rect x={x} y="720" width="320" height="14" fill={shade(c1, -0.30)} />
              <rect x={x + 10} y="734" width="6" height="120" fill={shade(c1, -0.45)} />
              <rect x={x + 304} y="734" width="6" height="120" fill={shade(c1, -0.45)} />
              {/* monitor */}
              <rect x={x + 80} y="650" width="160" height="70" fill={shade(c1, -0.60)} />
              <rect x={x + 84} y="654" width="152" height="62" fill={ink} opacity="0.5" />
              <rect x={x + 148} y="720" width="24" height="14" fill={shade(c1, -0.50)} />
              {/* chair */}
              <rect x={x + 130} y="850" width="80" height="14" fill={shade(c1, -0.55)} />
              <line x1={x + 170} y1="864" x2={x + 170} y2={H} stroke={shade(c1, -0.55)} strokeWidth="6" />
            </g>
          ))}
        </g>
      );
    }

    // Retail — shelving + counter
    if (catKey.includes("mağaza") || catKey.includes("retail") || catKey.includes("magaza")) {
      return (
        <g>
          <rect x="0" y="0" width={W} height="700" fill={dark1} />
          <polygon points={`0,700 ${W},700 ${W},${H} 0,${H}`} fill={dark2} />
          {/* back wall shelving */}
          {Array.from({length: 6}).map((_, i) => (
            <line key={i} x1="120" y1={120 + i * 100} x2="1480" y2={120 + i * 100}
              stroke={shade(c1, -0.40)} strokeWidth="6" />
          ))}
          {/* side frames */}
          <rect x="116" y="120" width="8" height="500" fill={shade(c1, -0.45)} />
          <rect x="1476" y="120" width="8" height="500" fill={shade(c1, -0.45)} />
          {/* shelf objects (small products) */}
          {Array.from({length: 5}).map((_, row) =>
            Array.from({length: 14}).map((_, col) => {
              const ox = 160 + col * 96 + ((row * 13) % 30);
              const oy = 120 + row * 100 - 24 - (col % 3) * 6;
              const w = 18 + (col % 3) * 8;
              const hh = 24 + (col % 4) * 14;
              return <rect key={row+"-"+col} x={ox} y={oy} width={w} height={hh}
                fill={shade(c1, -0.30 - (col % 3) * 0.06)} opacity="0.9" />;
            })
          )}
          {/* central display island */}
          <rect x="600" y="780" width="400" height="120" fill={shade(c1, -0.25)} />
          <rect x="600" y="770" width="400" height="14" fill={shade(c1, -0.35)} />
          {/* spotlights from ceiling */}
          {[300, 800, 1300].map((x, i) => (
            <g key={i}>
              <rect x={x - 6} y="0" width="12" height="36" fill={ink} opacity="0.6" />
              <polygon points={`${x},36 ${x-180},${H*0.5} ${x+180},${H*0.5}`} fill="rgba(255,255,255,0.06)" />
            </g>
          ))}
        </g>
      );
    }

    // Residential — living room with sofa, window, art
    if (catKey.includes("konut") || catKey.includes("villa") || catKey.includes("residential")) {
      return (
        <g>
          <rect x="0" y="0" width={W} height="700" fill={dark1} />
          <polygon points={`0,700 ${W},700 ${W},${H} 0,${H}`} fill={dark2} />
          {/* large window */}
          <rect x="120" y="100" width="780" height="520" fill={light1} opacity="0.92" />
          <line x1="510" y1="100" x2="510" y2="620" stroke={dark1} strokeWidth="3" />
          <line x1="120" y1="360" x2="900" y2="360" stroke={dark1} strokeWidth="3" />
          {/* curtain on right */}
          <rect x="900" y="80" width="40" height="580" fill={shade(c1, -0.10)} opacity="0.95" />
          {Array.from({length: 10}).map((_, i) => (
            <line key={i} x1={900 + i * 4} y1="80" x2={900 + i * 4} y2="660"
              stroke={shade(c1, -0.25)} strokeWidth="1" opacity="0.7" />
          ))}
          {/* art on right wall */}
          <rect x="1080" y="180" width="220" height="280" fill={shade(c1, -0.50)} stroke={ink} strokeWidth="3" />
          <rect x="1100" y="200" width="180" height="240" fill={shade(c1, 0.10)} opacity="0.8" />
          {/* sofa */}
          <rect x="200" y="700" width="900" height="120" fill={shade(c1, -0.20)} />
          <rect x="200" y="690" width="900" height="20" fill={shade(c1, -0.30)} />
          {/* sofa cushions */}
          {[260, 460, 660, 860].map((x, i) => (
            <rect key={i} x={x} y="700" width="180" height="60" fill={shade(c1, -0.15)} />
          ))}
          {/* coffee table */}
          <rect x="380" y="880" width="540" height="14" fill={shade(c1, -0.45)} />
          <line x1="430" y1="894" x2="430" y2={H-20} stroke={shade(c1, -0.55)} strokeWidth="6" />
          <line x1="870" y1="894" x2="870" y2={H-20} stroke={shade(c1, -0.55)} strokeWidth="6" />
          {/* objects on table */}
          <ellipse cx="500" cy="876" rx="30" ry="8" fill={shade(c1, 0.15)} />
          <rect x="600" y="852" width="80" height="24" fill={shade(c1, 0.12)} />
          {/* floor lamp */}
          <line x1="1180" y1="700" x2="1180" y2={H-20} stroke={shade(c1, -0.55)} strokeWidth="4" />
          <path d={`M 1140 480 L 1220 480 L 1210 700 L 1150 700 Z`} fill={shade(c1, 0.18)} stroke={ink} strokeWidth="2" opacity="0.85" />
          {/* pendant */}
          <line x1={W*0.6} y1="0" x2={W*0.6} y2="160" stroke={ink} strokeWidth="1.6" opacity="0.6" />
          <circle cx={W*0.6} cy="180" r="24" fill={shade(c1, 0.18)} opacity="0.85" />
        </g>
      );
    }

    // Mixed-use / default — abstract perspective interior with archway
    return (
      <g>
        <rect x="0" y="0" width={W} height="640" fill={dark1} />
        <polygon points={`0,640 ${W},640 ${W},${H} 0,${H}`} fill={dark2} />
        {/* central archway */}
        <path d={`M ${W*0.35} ${H*0.85} L ${W*0.35} ${H*0.34} Q ${W*0.35} ${H*0.20} ${W*0.42} ${H*0.20} L ${W*0.58} ${H*0.20} Q ${W*0.65} ${H*0.20} ${W*0.65} ${H*0.34} L ${W*0.65} ${H*0.85} Z`}
          fill={light1} opacity="0.92" />
        <path d={`M ${W*0.35} ${H*0.85} L ${W*0.35} ${H*0.34} Q ${W*0.35} ${H*0.20} ${W*0.42} ${H*0.20} L ${W*0.58} ${H*0.20} Q ${W*0.65} ${H*0.20} ${W*0.65} ${H*0.34} L ${W*0.65} ${H*0.85}`}
          fill="none" stroke={ink} strokeWidth="2" opacity="0.5" />
        {/* wall art */}
        <rect x={W*0.08} y={H*0.25} width={W*0.18} height={H*0.32} fill={shade(c1, -0.45)} stroke={ink} strokeWidth="3" />
        <rect x={W*0.75} y={H*0.25} width={W*0.18} height={H*0.32} fill={shade(c1, -0.45)} stroke={ink} strokeWidth="3" />
        {/* bench */}
        <rect x={W*0.10} y={H*0.74} width={W*0.20} height="14" fill={shade(c1, -0.30)} />
        <rect x={W*0.70} y={H*0.74} width={W*0.20} height="14" fill={shade(c1, -0.30)} />
        {/* floor tiles */}
        {[0.78, 0.84, 0.90, 0.95].map((t, i) => (
          <line key={i} x1="0" y1={H * t} x2={W} y2={H * t}
            stroke={shade(c1, -0.50)} strokeWidth="1.5" opacity="0.5" />
        ))}
      </g>
    );
  };

  // Light direction overlay
  const lightOverlay = (
    <div style={{
      position: "absolute", inset: 0,
      background: lightFrom === "tr"
        ? "radial-gradient(110% 70% at 92% 18%, rgba(255,250,235,0.30), transparent 55%), linear-gradient(225deg, rgba(255,250,235,0.18) 0%, transparent 38%)"
        : "radial-gradient(110% 70% at 8% 18%, rgba(255,250,235,0.30), transparent 55%), linear-gradient(135deg, rgba(255,250,235,0.18) 0%, transparent 38%)",
      pointerEvents: "none",
      mixBlendMode: "screen",
    }} />
  );

  // Atmospheric grain (very subtle noise)
  const grainOverlay = (
    <div style={{
      position: "absolute", inset: 0,
      pointerEvents: "none",
      opacity: 0.10,
      backgroundImage: "url('data:image/svg+xml;utf8,<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"160\" height=\"160\"><filter id=\"n\"><feTurbulence type=\"fractalNoise\" baseFrequency=\"0.85\" numOctaves=\"2\"/></filter><rect width=\"160\" height=\"160\" filter=\"url(%23n)\" opacity=\"0.55\"/></svg>')",
      mixBlendMode: "multiply",
    }} />
  );

  // Whether to show animated figure walking across floor
  const showFigure = withFigure ?? ((h % 7) === 0);
  const direction = (h % 2 === 0) ? "ltr" : "rtl";

  // Figure parameters
  return (
    <div
      className="ph-img"
      style={{
        position: "relative",
        width: "100%",
        aspectRatio: ratio,
        overflow: "hidden",
        background: c1,
        ...style,
      }}
      data-slug={slug}
    >
      <svg viewBox="0 0 1600 1000" preserveAspectRatio="xMidYMid slice"
        width="100%" height="100%"
        style={{ position: "absolute", inset: 0, display: "block" }}>
        {renderScene()}
      </svg>
      {lightOverlay}
      {grainOverlay}

      {/* animated walking figure */}
      {showFigure && window.WalkingFigure && (
        <window.WalkingFigure
          src={figureSrc}
          height={120 * (scale || 1)}
          speed={26 + (h % 8) * 2}
          direction={direction}
          opacity={0.78}
          style={{ bottom: "6%" }}
        />
      )}

      {/* label */}
      {label !== false && (
        <div style={{
          position: "absolute",
          left: "1.1em",
          bottom: "1em",
          fontFamily: "var(--mono)",
          fontSize: `${0.65 * scale}rem`,
          letterSpacing: "0.08em",
          textTransform: "uppercase",
          color: dark ? "rgba(245,240,232,0.78)" : "rgba(40,30,22,0.62)",
          mixBlendMode: dark ? "screen" : "multiply",
          textShadow: dark ? "0 1px 2px rgba(0,0,0,0.5)" : "0 1px 2px rgba(255,255,255,0.5)",
        }}>
          {label || slug}
        </div>
      )}
    </div>
  );
}

function shade(hex, amt) {
  hex = hex.replace("#", "");
  const num = parseInt(hex, 16);
  let r = (num >> 16) & 0xff;
  let g = (num >> 8) & 0xff;
  let b = num & 0xff;
  if (amt < 0) {
    r = Math.max(0, Math.round(r * (1 + amt)));
    g = Math.max(0, Math.round(g * (1 + amt)));
    b = Math.max(0, Math.round(b * (1 + amt)));
  } else {
    r = Math.min(255, Math.round(r + (255 - r) * amt));
    g = Math.min(255, Math.round(g + (255 - g) * amt));
    b = Math.min(255, Math.round(b + (255 - b) * amt));
  }
  return "#" + [r, g, b].map(v => v.toString(16).padStart(2, "0")).join("");
}

// Re-export under existing name so all variations use the new renderer
window.Placeholder = RenderImage;
