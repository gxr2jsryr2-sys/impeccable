/* eslint-disable */
// Hand-drawn sketch map of Oran — based on the actual Google Maps layout
// Kuzu Effect AVM, Park Oran Konutları, Panora AVM, Turan Güneş Bulvarı

function OfficeSketchMap({ ink = "#38383c", paper = "#ece5dd", mid = "#57646c", lang = "tr", wordmark = "assets/wordmark-charcoal.png" }) {
  const sk = (key, props) => <path key={key} fill="none" stroke={ink} strokeLinecap="round" strokeLinejoin="round" {...props} />;
  const skMid = (key, props) => <path key={key} fill="none" stroke={mid} strokeLinecap="round" strokeLinejoin="round" {...props} />;

  return (
    <div style={{
      position: "relative",
      width: "100%",
      aspectRatio: "16/9",
      background: paper,
      overflow: "hidden",
      border: `1px solid ${ink}22`,
    }}>
      <svg width="100%" height="100%" viewBox="0 0 1600 900" preserveAspectRatio="xMidYMid slice"
        style={{ display: "block" }}>
        <defs>
          <filter id="m-wobble" x="-3%" y="-3%" width="106%" height="106%">
            <feTurbulence type="fractalNoise" baseFrequency="0.022" numOctaves="2" seed="9" />
            <feDisplacementMap in="SourceGraphic" scale="3.5" xChannelSelector="R" yChannelSelector="G" />
          </filter>
          <filter id="m-wobble-fine" x="-3%" y="-3%" width="106%" height="106%">
            <feTurbulence type="fractalNoise" baseFrequency="0.04" numOctaves="2" seed="3" />
            <feDisplacementMap in="SourceGraphic" scale="1.8" xChannelSelector="R" yChannelSelector="G" />
          </filter>
          <filter id="m-wobble-heavy" x="-3%" y="-3%" width="106%" height="106%">
            <feTurbulence type="fractalNoise" baseFrequency="0.018" numOctaves="3" seed="13" />
            <feDisplacementMap in="SourceGraphic" scale="5" xChannelSelector="R" yChannelSelector="G" />
          </filter>
        </defs>

        {/* Tracing-paper grid */}
        <g opacity="0.08">
          {Array.from({ length: 17 }).map((_, i) => (
            <line key={"vg" + i} x1={i * 100} y1="0" x2={i * 100} y2="900" stroke={ink} strokeWidth="0.6" />
          ))}
          {Array.from({ length: 10 }).map((_, i) => (
            <line key={"hg" + i} x1="0" y1={i * 100} x2="1600" y2={i * 100} stroke={ink} strokeWidth="0.6" />
          ))}
        </g>

        {/* === SOUTH GREEN — Hatıra Ormanı (large park south of Turan Güneş) === */}
        <g filter="url(#m-wobble-fine)">
          <path
            d="M -40 720 C 80 700, 240 705, 380 720 C 520 735, 660 720, 800 715 C 940 710, 1080 720, 1220 715 C 1360 710, 1500 720, 1640 715 L 1640 920 L -40 920 Z"
            fill={ink} opacity="0.06" stroke="none"
          />
          {sk("park-1", { d: "M -40 720 C 80 700, 240 705, 380 720 C 520 735, 660 720, 800 715 C 940 710, 1080 720, 1220 715 C 1360 710, 1500 720, 1640 715",
            strokeWidth: 1.4, strokeDasharray: "10 6", opacity: 0.55 })}
          {/* Park name */}
          <text x="240" y="820" fontFamily="var(--mono)" fontSize="13" fill={mid}
            letterSpacing="2.5" opacity="0.85">
            HATIRA ORMANI
          </text>
          {/* scattered tree scribbles */}
          {[[120, 780], [220, 850], [400, 800], [560, 830], [700, 810], [840, 850], [960, 820], [1120, 840], [1280, 810], [1420, 830], [1500, 870]].map(([x, y], i) => (
            <g key={"tr" + i} opacity="0.55">
              {sk("t" + i + "a", { d: `M ${x} ${y} q -4 -8 0 -14 q 4 -6 8 0 q 4 6 0 14 z`, strokeWidth: 0.9 })}
              {sk("t" + i + "b", { d: `M ${x + 4} ${y + 2} v 7`, strokeWidth: 0.7, opacity: 0.5 })}
            </g>
          ))}
        </g>

        {/* === TURAN GÜNEŞ BULVARI — divided highway, drawn as 3 parallel hand-drawn lines === */}
        <g filter="url(#m-wobble)">
          {/* North edge */}
          {sk("tg-n1", { d: "M -40 660 C 200 655, 480 650, 760 645 C 1040 640, 1320 635, 1640 625", strokeWidth: 1.8 })}
          {sk("tg-n2", { d: "M -40 662 C 200 658, 480 653, 760 648 C 1040 642, 1320 637, 1640 627", strokeWidth: 0.8, opacity: 0.6 })}
          {/* Median */}
          {sk("tg-m", { d: "M -40 685 C 200 680, 480 675, 760 670 C 1040 665, 1320 660, 1640 650",
            strokeWidth: 0.8, strokeDasharray: "14 8", opacity: 0.55 })}
          {/* South edge */}
          {sk("tg-s1", { d: "M -40 710 C 200 705, 480 700, 760 695 C 1040 690, 1320 685, 1640 675", strokeWidth: 1.8 })}
          {sk("tg-s2", { d: "M -40 712 C 200 707, 480 702, 760 697 C 1040 692, 1320 687, 1640 677", strokeWidth: 0.8, opacity: 0.6 })}
          {/* Bulvar label */}
        </g>
        <g filter="url(#m-wobble-fine)">
          <text x="780" y="755" fontFamily="var(--mono)" fontSize="14" fill={mid}
            letterSpacing="3.5" textAnchor="middle" opacity="0.95">
            TURAN GÜNEŞ BULVARI
          </text>
        </g>

        {/* === ZÜLFÜ TİĞREL CADDESİ — vertical street, our location === */}
        <g filter="url(#m-wobble)">
          {sk("zt-l", { d: "M 555 660 C 555 580, 560 480, 555 360 C 552 280, 548 200, 545 80", strokeWidth: 1.5 })}
          {sk("zt-r", { d: "M 590 660 C 590 580, 592 480, 589 360 C 587 280, 585 200, 582 80", strokeWidth: 1.5 })}
        </g>
        <g filter="url(#m-wobble-fine)">
          <text x="612" y="370" fontFamily="var(--mono)" fontSize="11" fill={mid}
            letterSpacing="2.5" transform="rotate(-90 612 370)" opacity="0.85">
            ZÜLFÜ TİĞREL CAD.
          </text>
        </g>

        {/* === KUDÜS CADDESİ — between Park Oran and Panora === */}
        <g filter="url(#m-wobble)">
          {sk("ku-1", { d: "M 1085 670 C 1085 600, 1088 510, 1085 420 C 1083 340, 1080 240, 1078 120", strokeWidth: 1.4 })}
          {sk("ku-2", { d: "M 1112 670 C 1112 600, 1115 510, 1112 420 C 1110 340, 1107 240, 1105 120", strokeWidth: 1.4 })}
        </g>
        <g filter="url(#m-wobble-fine)">
          <text x="1130" y="370" fontFamily="var(--mono)" fontSize="10" fill={mid}
            letterSpacing="2.5" transform="rotate(-90 1130 370)" opacity="0.8">
            KUDÜS CAD.
          </text>
        </g>

        {/* === ORAN-EYMIR YOLU — branches off to the right === */}
        <g filter="url(#m-wobble)">
          {sk("oe-1", { d: "M 1640 640 C 1500 660, 1440 700, 1410 770 C 1390 820, 1395 870, 1410 920", strokeWidth: 1.3, opacity: 0.85 })}
        </g>
        <g filter="url(#m-wobble-fine)">
          <text x="1455" y="800" fontFamily="var(--mono)" fontSize="10" fill={mid}
            letterSpacing="2.5" transform="rotate(72 1455 800)" opacity="0.8">
            ORAN-EYMIR YOLU
          </text>
        </g>

        {/* === Side streets — small ones north of main area === */}
        <g filter="url(#m-wobble)" opacity="0.65">
          {sk("ss-1", { d: "M -40 380 C 140 375, 320 360, 500 350 C 680 345, 860 340, 1040 330 C 1220 325, 1400 320, 1640 310", strokeWidth: 1.1 })}
          {sk("ss-2", { d: "M -40 240 C 140 235, 320 220, 500 210 C 680 205, 860 200, 1040 190 C 1220 185, 1400 180, 1640 170", strokeWidth: 1.0 })}
          {sk("ss-3", { d: "M -40 480 C 140 475, 320 470, 500 480 C 680 490, 860 488, 1040 485 C 1220 482, 1400 478, 1640 470", strokeWidth: 1.0 })}
          {/* small vertical connectors */}
          {sk("sv-1", { d: "M 180 240 C 175 320, 178 410, 175 510", strokeWidth: 0.9 })}
          {sk("sv-2", { d: "M 360 240 C 358 320, 360 410, 355 510", strokeWidth: 0.9 })}
          {sk("sv-3", { d: "M 740 240 C 742 320, 740 410, 738 510", strokeWidth: 0.9 })}
          {sk("sv-4", { d: "M 920 240 C 922 320, 920 410, 918 510", strokeWidth: 0.9 })}
          {sk("sv-5", { d: "M 1280 240 C 1282 320, 1280 410, 1278 510", strokeWidth: 0.9 })}
          {sk("sv-6", { d: "M 1480 240 C 1482 320, 1480 410, 1478 510", strokeWidth: 0.9 })}
        </g>

        {/* === PARK ORAN KONUTLARI — residential complex with private green === */}
        <g filter="url(#m-wobble-fine)">
          {/* Green park-ish area inside */}
          <path d="M 720 530 L 1060 530 L 1060 645 L 720 645 Z"
            fill={ink} opacity="0.04" />
          {sk("po-out", { d: "M 720 530 L 1060 530 L 1060 645 L 720 645 Z", strokeWidth: 1.6, strokeDasharray: "6 4", opacity: 0.7 })}
          {/* a few residential block hatchings */}
          {[[740, 540, 80, 40], [840, 540, 90, 40], [950, 540, 90, 40],
            [740, 590, 60, 35], [820, 590, 70, 35], [910, 590, 60, 35], [990, 590, 60, 35]].map(([x, y, w, h], i) => (
              <g key={"po-blk" + i} opacity="0.45">
                {sk("po-b" + i, { d: `M ${x} ${y} L ${x + w} ${y} L ${x + w} ${y + h} L ${x} ${y + h} Z`, strokeWidth: 1 })}
              </g>
            ))}
          {/* label */}
          <text x="890" y="630" fontFamily="var(--mono)" fontSize="11" fill={mid}
            letterSpacing="2.5" textAnchor="middle" opacity="0.85">
            PARK ORAN KONUTLARI
          </text>
        </g>

        {/* === PANORA AVM — east landmark, two-volume mall === */}
        <g filter="url(#m-wobble-fine)">
          {sk("pn-out", { d: "M 1170 470 L 1380 470 L 1380 625 L 1170 625 Z", strokeWidth: 2.2 })}
          {sk("pn-out2", { d: "M 1172 472 L 1378 470 L 1377 624 L 1170 622 Z", strokeWidth: 1.1, opacity: 0.6 })}
          {/* dense cross-hatch */}
          {[0.18, 0.36, 0.54, 0.72, 0.90].map((t, i) => (
            <line key={"pn-h" + i} x1="1170" y1={470 + 155 * t} x2="1380" y2={470 + 155 * t}
              stroke={ink} strokeWidth="0.5" opacity="0.4" />
          ))}
          {[0.20, 0.40, 0.60, 0.80].map((t, i) => (
            <line key={"pn-v" + i} x1={1170 + 210 * t} y1="470" x2={1170 + 210 * t} y2="625"
              stroke={ink} strokeWidth="0.5" opacity="0.4" />
          ))}
          {/* corner accents */}
          {[[1170, 470], [1380, 470], [1170, 625], [1380, 625]].map(([x, y], i) => (
            <circle key={"pn-c" + i} cx={x} cy={y} r="3" fill={ink} opacity="0.55" />
          ))}
          {/* label */}
          <text x="1275" y="540" fontFamily="var(--display)" fontSize="26" fill={ink}
            textAnchor="middle" fontStyle="italic">Panora</text>
          <text x="1275" y="565" fontFamily="var(--mono)" fontSize="10" fill={mid}
            textAnchor="middle" letterSpacing="3">AVM</text>
        </g>

        {/* === KUZU EFFECT AVM — our building, drawn heaviest === */}
        <g filter="url(#m-wobble-heavy)">
          {/* outline drawn 3 times for hand-drawn feel */}
          {sk("ke-1", { d: "M 410 510 L 660 510 L 660 645 L 410 645 Z", strokeWidth: 3 })}
          {sk("ke-2", { d: "M 412 512 L 662 510 L 658 647 L 410 643 Z", strokeWidth: 1.8, opacity: 0.65 })}
          {sk("ke-3", { d: "M 408 508 L 663 512 L 661 645 L 413 648 Z", strokeWidth: 1.2, opacity: 0.45 })}
          {/* internal hatching */}
          {[0.18, 0.36, 0.54, 0.72, 0.90].map((t, i) => (
            <line key={"ke-h" + i} x1="418" y1={510 + 135 * t} x2="652" y2={510 + 135 * t}
              stroke={ink} strokeWidth="0.7" opacity="0.4" />
          ))}
          {/* entrance mark */}
          {sk("ke-door", { d: "M 510 645 L 510 660 L 560 660 L 560 645", strokeWidth: 1.6 })}
        </g>

        {/* === Other small landmarks — minimal sketchy markers === */}
        <g filter="url(#m-wobble-fine)" opacity="0.45">
          {/* Hotel Monec */}
          <circle cx="620" cy="490" r="6" fill="none" stroke={ink} strokeWidth="1" />
          <text x="630" y="494" fontFamily="var(--mono)" fontSize="9" fill={mid} letterSpacing="1.5">Hotel Monec</text>
          {/* Kalbur Balık */}
          <circle cx="370" cy="490" r="4" fill={ink} opacity="0.7" />
          <text x="378" y="494" fontFamily="var(--mono)" fontSize="9" fill={mid} letterSpacing="1.5">Kalbur Balık</text>
          {/* 302 Mavi */}
          <circle cx="240" cy="555" r="4" fill={ink} opacity="0.7" />
          <text x="248" y="559" fontFamily="var(--mono)" fontSize="9" fill={mid} letterSpacing="1.5">302 Mavi</text>
          {/* Acıbadem hospital */}
          <path d="M 1450 538 L 1450 552 M 1443 545 L 1457 545" stroke={ink} strokeWidth="2" />
          <text x="1465" y="548" fontFamily="var(--mono)" fontSize="9" fill={mid} letterSpacing="1.5">Acıbadem Hast.</text>
        </g>

        {/* === LEADER LINE + LOGO CALLOUT === */}
        <g filter="url(#m-wobble-fine)">
          {sk("lead", { d: "M 535 530 C 460 460, 380 360, 320 260", strokeWidth: 1.5, strokeDasharray: "6 6" })}
          <polygon points="540,538 528,532 540,524" fill={ink} opacity="0.85" />
        </g>

        {/* X mark inside Kuzu Effect */}
        <g filter="url(#m-wobble-fine)">
          {sk("x1", { d: "M 515 555 L 555 595", strokeWidth: 3.5 })}
          {sk("x2", { d: "M 555 555 L 515 595", strokeWidth: 3.5 })}
          <circle cx="535" cy="575" r="30" fill="none" stroke={ink} strokeWidth="2.4" />
          <circle cx="537" cy="573" r="28" fill="none" stroke={ink} strokeWidth="1.2" opacity="0.55" />
        </g>

        {/* Logo callout — top-left of map */}
        <g transform="translate(70, 200)">
          <image href={wordmark} x="0" y="0" width="280" height="70" preserveAspectRatio="xMinYMid meet" />
          {sk("logo-u1", { d: "M 0 80 L 250 80", strokeWidth: 1.4, opacity: 0.7 })}
          {sk("logo-u2", { d: "M 4 84 L 245 82", strokeWidth: 0.9, opacity: 0.45 })}
          <text x="0" y="104" fontFamily="var(--mono)" fontSize="11" fill={mid} letterSpacing="2.4">
            KUZU EFFECT AVM · 4. KAT
          </text>
          <text x="0" y="122" fontFamily="var(--mono)" fontSize="11" fill={mid} letterSpacing="2.4">
            ZÜLFÜ TİĞREL CAD. · ORAN
          </text>
          <text x="0" y="140" fontFamily="var(--mono)" fontSize="11" fill={mid} letterSpacing="2.4">
            ÇANKAYA · ANKARA
          </text>
        </g>

        {/* === COMPASS — top right === */}
        <g transform="translate(1500, 90)" filter="url(#m-wobble-fine)">
          <circle cx="0" cy="0" r="36" fill="none" stroke={ink} strokeWidth="1.4" opacity="0.6" />
          <circle cx="1" cy="-1" r="35" fill="none" stroke={ink} strokeWidth="0.8" opacity="0.35" />
          <line x1="0" y1="-40" x2="0" y2="40" stroke={ink} strokeWidth="1.2" opacity="0.65" />
          <line x1="-36" y1="0" x2="36" y2="0" stroke={ink} strokeWidth="0.7" opacity="0.35" />
          <polygon points="0,-32 -6,-12 0,-18 6,-12" fill={ink} opacity="0.85" />
          <text x="0" y="-46" fontFamily="var(--mono)" fontSize="14" fill={ink}
            textAnchor="middle" fontWeight="600">N</text>
        </g>

        {/* === SCALE BAR === */}
        <g transform="translate(60, 850)" filter="url(#m-wobble-fine)">
          <line x1="0" y1="0" x2="180" y2="0" stroke={ink} strokeWidth="2.4" strokeLinecap="round" />
          <line x1="0" y1="-6" x2="0" y2="6" stroke={ink} strokeWidth="2" />
          <line x1="90" y1="-4" x2="90" y2="4" stroke={ink} strokeWidth="1.4" />
          <line x1="180" y1="-6" x2="180" y2="6" stroke={ink} strokeWidth="2" />
          <text x="0" y="-12" fontFamily="var(--mono)" fontSize="11" fill={mid} letterSpacing="1.5">0</text>
          <text x="90" y="-12" fontFamily="var(--mono)" fontSize="11" fill={mid} letterSpacing="1.5" textAnchor="middle">100m</text>
          <text x="180" y="-12" fontFamily="var(--mono)" fontSize="11" fill={mid} letterSpacing="1.5" textAnchor="middle">200m</text>
        </g>

        {/* corner caption */}
        <text x="60" y="80" fontFamily="var(--mono)" fontSize="12" fill={mid}
          letterSpacing="3">
          ORAN — ÇANKAYA · ANKARA
        </text>
        <text x="60" y="100" fontFamily="var(--mono)" fontSize="10" fill={mid}
          letterSpacing="2" opacity="0.7">
          {lang === "tr" ? "ELDE ÇIZILMIŞ · NOT TO SCALE" : "HAND-DRAWN · NOT TO SCALE"}
        </text>
      </svg>
    </div>
  );
}

window.OfficeSketchMap = OfficeSketchMap;
